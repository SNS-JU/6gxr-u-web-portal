import requests, jwt
from .models import myuser
from django.conf import settings
from rest_framework import status
from rest_framework.views import APIView
from django.contrib.auth.models import User
from rest_framework.response import Response
from django.shortcuts import  get_object_or_404
from home.models import SliceInfoForm, RunningSlice
from rest_framework.exceptions import PermissionDenied
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.contrib.auth import authenticate, login, get_user_model
from .serializer import MyUserSerializer, CustomTokenObtainPairSerializer,AlluserSerializer



class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer

User = get_user_model()
class LoginUserApiView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return Response({"message": "Logged in successfully."}, status=status.HTTP_200_OK)
        return Response({"message": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

class RegisterUserApiView(APIView):
    def post(self, request):
        request.body
        serializer = MyUserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.create(request.data)
            return Response("ok", status=status.HTTP_201_CREATED)
        errors = [error for sublist in serializer.errors.values() for error in sublist]
        return Response(errors, status=status.HTTP_400_BAD_REQUEST)

class LogoutUserApiView(APIView):
    def post(self, request):
        try:
            refreshtoken = request.data['refresh_token']
            token = RefreshToken(refreshtoken)
            token.blacklist()
            return Response({"message": "Logged out successfully."}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class EditUserApiView(APIView):
    def get(self, request):
        user = get_object_or_404(myuser, id=request.user.id)
        # Check if the requesting user has permission
        if request.user.id != request.user.id and not request.user.is_staff:  # Adjust `is_staff` for your admin role
            raise PermissionDenied("You are not allowed to view this user.")

        serializer = MyUserSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request):
        # user = request.user  # Get the currently authenticated user
        data = request.data
        token = request.data.get("token")  # Get token from request body
        if not token:
            return Response({"error": "Token is missing"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            # Decode the JWT manually
            decoded_token = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
            user_id = decoded_token.get("user_id")
            username = decoded_token.get("username")
            founduser = myuser.objects.filter(username=username).first()
            if founduser:
                try:
                    new_first_name = data["first_name"]
                    new_last_name = data["last_name"]
                    current_password = data["current_password"]
                    new_password = data["new_password"]
                    phone_number = data["phone"]
                except KeyError as e:
                    return Response({"message": f"Missing key {e}"}, status=status.HTTP_400_BAD_REQUEST)
                # Validate that both passwords are provided
                if current_password != "" and new_password != "":
                    if not founduser.check_password(current_password):
                        return Response({"error": "Current password is incorrect."},
                                        status=status.HTTP_400_BAD_REQUEST, )
                    else:
                        founduser.set_password(new_password)
                if new_first_name:
                    founduser.first_name = new_first_name
                if new_last_name:
                    founduser.last_name = new_last_name
                if phone_number:
                    founduser.phone_number = phone_number
                founduser.save()
                return Response({"message": "User profile updated successfully!"}, status=status.HTTP_200_OK)
            else:
                return Response({
                    "error": "No profile",
                }, status=status.HTTP_404_NOT_FOUND)

        except jwt.ExpiredSignatureError:
            return Response({"error": "Token has expired"}, status=status.HTTP_401_UNAUTHORIZED)
        except jwt.InvalidTokenError:
            return Response({"error": "Invalid token"}, status=status.HTTP_401_UNAUTHORIZED)
        except Exception as e:
            return Response({"error": "Unexpected server error"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class DeleteUserApiView(APIView):
    def post(self, request):
        token = request.data.get("token")  # Get token from request body
        if not token:
            return Response({"error": "Token is missing"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            # Decode the JWT manually
            decoded_token = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
            username = decoded_token.get("username")
            founduser = myuser.objects.filter(username=username).first()

            if founduser:
                NST = SliceInfoForm.objects.filter(user__username=founduser.username)
                for slice in NST:
                    try:
                        external_api_url = f"http://172.29.6.16:5000/experiment/1"
                        external_api_response = requests.delete(external_api_url)
                    except RunningSlice.DoesNotExist:
                        # No corresponding RunningSlice found; proceed to delete slice
                        pass
                    slice.delete()
                    deleteselected = SelectedFields.objects.filter(slice_info=NST)
                    for item in deleteselected:
                        item.delete()
                founduser.delete()
                return Response("user and experiments has beed deleted!", status=status.HTTP_200_OK)
            else:
                return Response({
                    "error": "No profile",
                }, status=status.HTTP_400_BAD_REQUEST)

        except jwt.ExpiredSignatureError:
            return Response({"error": "Token has expired"}, status=status.HTTP_401_UNAUTHORIZED)
        except jwt.InvalidTokenError:
            return Response({"error": "Invalid token"}, status=status.HTTP_401_UNAUTHORIZED)
            
class Userprofile(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            allprofile = myuser.objects.get(id=request.user.id)
            serializer = AlluserSerializer(allprofile)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except ObjectDoesNotExist:
            return Response({"message": "User does not exist."}, status=status.HTTP_404_NOT_FOUND)

class Passresetconfirmtion(APIView):
    def post(self, request):
        # Validate input data
        email = request.data.get('email')
        new_password = request.data.get("new_password")
        if not email or not new_password:
            return Response({"message": "Missing required fields (email, code, new_password)."},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            user = myuser.objects.get(email=email)
        except (User.DoesNotExist):
            return Response({"message": "User or reset code does not exist."}, status=status.HTTP_404_NOT_FOUND)
        if len(new_password) < 6:
            return Response({"message": "Password must be at least 6 characters long."},
                            status=status.HTTP_400_BAD_REQUEST)
        try:
            user.set_password(new_password)
            user.save()  # Save the updated password
            return Response({"message": "Password has been changed successfully."}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"message": f"Password change failed! Error: {str(e)}"},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)