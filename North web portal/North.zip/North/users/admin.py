from .models import myuser
from django.contrib import admin

admin.site.register(myuser)
