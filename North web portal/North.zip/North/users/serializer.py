from .models import myuser
from rest_framework import serializers
from django.contrib.auth.hashers import make_password


class MyUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    class Meta:
        model = myuser
        fields = ['id', 'username', 'email', 'first_name', 'last_name', 'phone_number', 'password', 'is_active', 'is_staff']

    def validate_username(self, value):
        """Custom validation for the username field."""
        if myuser.objects.filter(username=value).exists():
            raise serializers.ValidationError("This username is already taken. Please choose another.")
        if len(value) < 4:
            raise serializers.ValidationError("Username must be at least 4 characters long.")
        return value

    def validate_email(self, value):
        """Custom validation for the email field."""
        if myuser.objects.filter(email=value).exists():
            raise serializers.ValidationError("This email is already registered.")
        return value

    def create(self, validated_data):
        user = myuser.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', ''),
            phone_number=validated_data.get('phone_number', ''),
        )
        return user
class AlluserSerializer(serializers.ModelSerializer):
    class Meta:
        model = myuser
        fields = ("username","email","first_name","last_name","phone_number","id")
        
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        # Get the default token
        token = super().get_token(user)
        # Add custom claims
        token['username'] = user.username  # Add username to JWT payload
        return token



