from django.urls import path
from django.contrib import admin
from .views import Passresetconfirmtion,RegisterUserApiView,LoginUserApiView,LogoutUserApiView,EditUserApiView,DeleteUserApiView,CustomTokenObtainPairView,Userprofile

app_name = 'users'
urlpatterns = [

    path('admin/', admin.site.urls),
    path('api/users/profile/', Userprofile.as_view(), name='Userprofile'),
    path('api/Passresetconfirmtion/', Passresetconfirmtion.as_view(), name='Passresetconfirmtion'),
    path('api/users/register/', RegisterUserApiView.as_view(), name='register_user'),
    path('api/users/login/', LoginUserApiView.as_view(), name='login_user'),
    path('api/users/logout/', LogoutUserApiView.as_view(), name='logout_user'),
    path('api/users/edit/', EditUserApiView.as_view(), name='edit_user'),
    path('api/users/delete/', DeleteUserApiView.as_view(), name='DeleteUserApiView'),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
]
