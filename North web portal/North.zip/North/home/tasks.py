import requests, time
from celery import shared_task
from celery.result import AsyncResult
from datetime import datetime,timezone
from celery.exceptions import TaskRevokedError
from .models import SliceInfoForm, RunningSlice, DataRecord, DataRecord2, SelectedFields, APIResponse

@shared_task
def delete_nst_after_expiry(nst_id, user_id):
    try:
        nst = SliceInfoForm.objects.get(id=nst_id, user=user_id)
        nst_name = nst.name

        running_slice_entry = RunningSlice.objects.filter(nst_id=nst.id).first()
        if running_slice_entry:
            running_slice_entry.delete()

        DataRecord.objects.filter(nst_info=nst).delete()
        DataRecord2.objects.filter(nst_info=nst).delete()
        APIResponse.objects.all().delete()
        deleteselected = SelectedFields.objects.filter(slice_info=nst)
        for item in deleteselected:
            item.delete()
        nst.delete()

        try:
            external_api_response = requests.delete(f"http://172.29.6.16:5000/experiment/1", timeout=5)
            if external_api_response.status_code != 200:
                print(f"Failed to notify external API for slice {nst.id}. Status: {external_api_response.status_code}")
        except requests.RequestException as ex:
            print(f"External API error: {ex}")
        print(f"NST {nst_name} and related data deleted successfully.")
    except SliceInfoForm.DoesNotExist:
        print(f"NST {nst_id} not found or already deleted.")
        
@shared_task(bind=True)
def test(self, experiment_start_time_epoch, experiment_end_time_epoch, **kwargs):
    response = ""
    slice_info_id = kwargs["data"][1]["slice_info"]
    slice_info = SliceInfoForm.objects.get(id=slice_info_id)

    experiment_end_time_iso = datetime.fromisoformat(slice_info.end_date.isoformat())
    print(experiment_end_time_iso)
    print(datetime.now())

    task_id = self.request.id  # Get the current task ID
    while True:
        # Check if the task is revoked
        task_result = AsyncResult(task_id)
        if task_result.state == 'REVOKED':
            print("Task was revoked. Exiting gracefully.")
            raise TaskRevokedError("Task was terminated.")

        # Perform the task's main logic
        if datetime.now(timezone.utc) >= experiment_end_time_iso:
            response = "scan is over."
            return response

        for index, extracted_id in enumerate(kwargs["data"][0]["nst_id"]):  # Construct the URL for each ID
            query_url = f"http://172.29.12.66:8080/AverageResultsNoPaging?field=measDescriptionPartial&value={extracted_id}&after={experiment_start_time_epoch}&before={experiment_end_time_epoch}&sort=asc&limit=2000"
            print(query_url)
            response = requests.get(query_url)
            print(index,"\n")
            # print(response.text[0:200])
            # print("Full API Response:", response.json())
            if response.status_code == 200:
                try:
                    data_list = response.json()
                    # Ensure that data_list is a list of dictionaries
                    if not isinstance(data_list, list):
                        data_list = []
                        # If we are processing the first slice (slice1), save to DataRecord
                    if index == 0:
                        # Delete old data in DataRecord related to this slice_id
                        DataRecord.objects.all().delete()
                        # Save the extracted data to the DataRecord model
                        for item in data_list:
                            DataRecord.objects.create(
                                calcPeriod=item.get("calcPeriod"),
                                ctrlPkNum=item.get("ctrlPkNum"),
                                measDuration=item.get("measDuration"),
                                measurement=item.get("measurement"),
                                primAccuracy=item.get("primAccuracy"),
                                primAge=item.get("primAge"),
                                primAltitude=item.get("primAltitude"),
                                primCellId=item.get("primCellId"),
                                primDroppedPkIf=item.get("primDroppedPkIf"),
                                primDroppedPkIfTotal=item.get("primDroppedPkIfTotal"),
                                primDroppedPkPcap=item.get("primDroppedPkPcap"),
                                primDroppedPkPcapTotal=item.get("primDroppedPkPcapTotal"),
                                primHeading=item.get("primHeading"),
                                primLatitude=item.get("primLatitude"),
                                primLongitude=item.get("primLongitude"),
                                primMalformedPkts=item.get("primMalformedPkts"),
                                primMalformedPktsTotal=item.get("primMalformedPktsTotal"),
                                primNetworkType=item.get("primNetworkType"),
                                primPositionMode=item.get("primPositionMode"),
                                primRecBitsS=item.get("primRecBitsS"),
                                primRecBytes=item.get("primRecBytes"),
                                primRecBytesTotal=item.get("primRecBytesTotal"),
                                primRecDupl=item.get("primRecDupl"),
                                primRecDuplTotal=item.get("primRecDuplTotal"),
                                primRecPktSize=item.get("primRecPktSize"),
                                primRecPkts=item.get("primRecPkts"),
                                primRecPktsS=item.get("primRecPktsS"),
                                primRecPktsTotal=item.get("primRecPktsTotal"),
                                primRecProto=item.get("primRecProto"),
                                primSentBitsS=item.get("primSentBitsS"),
                                primSentBytes=item.get("primSentBytes"),
                                primSentBytesTotal=item.get("primSentBytesTotal"),
                                primSentDupl=item.get("primSentDupl"),
                                primSentDuplTotal=item.get("primSentDuplTotal"),
                                primSentPktSize=item.get("primSentPktSize"),
                                primSentPkts=item.get("primSentPkts"),
                                primSentPktsS=item.get("primSentPktsS"),
                                primSentPktsTotal=item.get("primSentPktsTotal"),
                                primSentProto=item.get("primSentProto"),
                                primShortPkts=item.get("primShortPkts"),
                                primShortPktsTotal=item.get("primShortPktsTotal"),
                                primSignalStrength=item.get("primSignalStrength"),
                                primSnr=item.get("primSnr"),
                                primSpeed=item.get("primSpeed"),
                                qmId=item.get("qmId"),
                                recCbc=item.get("recCbc"),
                                recCbdTime=item.get("recCbdTime"),
                                recCbl=item.get("recCbl"),
                                recCblTot=item.get("recCblTot"),
                                recCorrectQosPk=item.get("recCorrectQosPk"),
                                recCorrectQosPkTotal=item.get("recCorrectQosPkTotal"),
                                recDSamples=item.get("recDSamples"),
                                recDelayMax=item.get("recDelayMax"),
                                recDelayMin=item.get("recDelayMin"),
                                recDelayS=item.get("recDelayS"),
                                recJitter=item.get("recJitter"),
                                recJitterMa=item.get("recJitterMa"),
                                recJitterMax=item.get("recJitterMax"),
                                recLostQosPk=item.get("recLostQosPk"),
                                recLostQosPkTotal=item.get("recLostQosPkTotal"),
                                recMaxCb=item.get("recMaxCb"),
                                recNotfTotal=item.get("recNotfTotal"),
                                recPacketLoss=item.get("recPacketLoss"),
                                recPacketLossTotal=item.get("recPacketLossTotal"),
                                recQoe1=item.get("recQoe1"),
                                recQoe2=item.get("recQoe2"),
                                recSentNotf=item.get("recSentNotf"),
                                recThExceededDelayPkts=item.get("recThExceededDelayPkts"),
                                recThExceededDelayPktsTotal=item.get("recThExceededDelayPktsTotal"),
                                recThExceededJitterPkts=item.get("recThExceededJitterPkts"),
                                recThExceededJitterPktsTotal=item.get("recThExceededJitterPktsTotal"),
                                resultsType=item.get("resultsType"),
                                secAccuracy=item.get("secAccuracy"),
                                secAge=item.get("secAge"),
                                secAltitude=item.get("secAltitude"),
                                secCellId=item.get("secCellId"),
                                secDroppedPkIf=item.get("secDroppedPkIf"),
                                secDroppedPkIfTotal=item.get("secDroppedPkIfTotal"),
                                secDroppedPkPcap=item.get("secDroppedPkPcap"),
                                secDroppedPkPcapTotal=item.get("secDroppedPkPcapTotal"),
                                secHeading=item.get("secHeading"),
                                secLatitude=item.get("secLatitude"),
                                secLongitude=item.get("secLongitude"),
                                secMalformedPkts=item.get("secMalformedPkts"),
                                secMalformedPktsTotal=item.get("secMalformedPktsTotal"),
                                secNetworkType=item.get("secNetworkType"),
                                secPositionMode=item.get("secPositionMode"),
                                secRecBitsS=item.get("secRecBitsS"),
                                secRecBytes=item.get("secRecBytes"),
                                secRecBytesTotal=item.get("secRecBytesTotal"),
                                secRecDupl=item.get("secRecDupl"),
                                secRecDuplTotal=item.get("secRecDuplTotal"),
                                secRecPktSize=item.get("secRecPktSize"),
                                secRecPkts=item.get("secRecPkts"),
                                secRecPktsS=item.get("secRecPktsS"),
                                secRecPktsTotal=item.get("secRecPktsTotal"),
                                secRecProto=item.get("secRecProto"),
                                secSentBitsS=item.get("secSentBitsS"),
                                secSentBytes=item.get("secSentBytes"),
                                secSentBytesTotal=item.get("secSentBytesTotal"),
                                secSentDupl=item.get("secSentDupl"),
                                secSentDuplTotal=item.get("secSentDuplTotal"),
                                secSentPktSize=item.get("secSentPktSize"),
                                secSentPkts=item.get("secSentPkts"),
                                secSentPktsS=item.get("secSentPktsS"),
                                secSentPktsTotal=item.get("secSentPktsTotal"),
                                secSentProto=item.get("secSentProto"),
                                secShortPkts=item.get("secShortPkts"),
                                secShortPktsTotal=item.get("secShortPktsTotal"),
                                secSignalStrength=item.get("secSignalStrength"),
                                secSnr=item.get("secSnr"),
                                secSpeed=item.get("secSpeed"),
                                sentCbc=item.get("sentCbc"),
                                sentCbdTime=item.get("sentCbdTime"),
                                sentCbl=item.get("sentCbl"),
                                sentCblTot=item.get("sentCblTot"),
                                sentCorrectQosPk=item.get("sentCorrectQosPk"),
                                sentCorrectQosPkTotal=item.get("sentCorrectQosPkTotal"),
                                sentDSamples=item.get("sentDSamples"),
                                sentDelayMax=item.get("sentDelayMax"),
                                sentDelayMin=item.get("sentDelayMin"),
                                sentDelayS=item.get("sentDelayS"),
                                sentJitter=item.get("sentJitter"),
                                sentJitterMa=item.get("sentJitterMa"),
                                sentJitterMax=item.get("sentJitterMax"),
                                sentLostQosPk=item.get("sentLostQosPk"),
                                sentLostQosPkTotal=item.get("sentLostQosPkTotal"),
                                sentMaxCb=item.get("sentMaxCb"),
                                sentPacketLoss=item.get("sentPacketLoss"),
                                sentPacketLossTotal=item.get("sentPacketLossTotal"),
                                sentQoe1=item.get("sentQoe1"),
                                sentQoe2=item.get("sentQoe2"),
                                sentSentNotf=item.get("sentSentNotf"),
                                sentSentNotfTotal=item.get("sentSentNotfTotal"),
                                sentThExceededDelayPkts=item.get("sentThExceededDelayPkts"),
                                sentThExceededDelayPktsTotal=item.get("sentThExceededDelayPktsTotal"),
                                sentThExceededJitterPkts=item.get("sentThExceededJitterPkts"),
                                sentThExceededJitterPktsTotal=item.get("sentThExceededJitterPktsTotal"),
                                time=item.get("time"),
                                trPrimSignalRsrp=item.get("trPrimSignalRsrp"),
                                trPrimSignalRsrq=item.get("trPrimSignalRsrq"),
                                trSecSignalRsrp=item.get("trSecSignalRsrp"),
                                trSecSignalRsrq=item.get("trSecSignalRsrq"),
                                tsPrimHandoverEvents=item.get("tsPrimHandoverEvents"),
                                tsRecDelayEstS=item.get("tsRecDelayEstS"),
                                tsRecDelayType=item.get("tsRecDelayType"),
                                tsSecHandoverEvents=item.get("tsSecHandoverEvents"),
                                tsSentDelayEstS=item.get("tsSentDelayEstS"),
                                tsSentDelayType=item.get("tsSentDelayType"),
                                ttPrimMacAddress=item.get("ttPrimMacAddress"),
                                ttSecMacAddress=item.get("ttSecMacAddress"),
                                nst_info=slice_info
                            )
                    # If we are processing the second slice (slice2), save to DataRecord2
                    elif index == 1:
                        # Delete old data in DataRecord2 related to this slice_id
                        DataRecord2.objects.all().delete()

                        # Save the extracted data to the DataRecord2 model
                        for item in data_list:
                            DataRecord2.objects.create(
                                calcPeriod=item.get("calcPeriod"),
                                ctrlPkNum=item.get("ctrlPkNum"),
                                measDuration=item.get("measDuration"),
                                measurement=item.get("measurement"),
                                primAccuracy=item.get("primAccuracy"),
                                primAge=item.get("primAge"),
                                primAltitude=item.get("primAltitude"),
                                primCellId=item.get("primCellId"),
                                primDroppedPkIf=item.get("primDroppedPkIf"),
                                primDroppedPkIfTotal=item.get("primDroppedPkIfTotal"),
                                primDroppedPkPcap=item.get("primDroppedPkPcap"),
                                primDroppedPkPcapTotal=item.get("primDroppedPkPcapTotal"),
                                primHeading=item.get("primHeading"),
                                primLatitude=item.get("primLatitude"),
                                primLongitude=item.get("primLongitude"),
                                primMalformedPkts=item.get("primMalformedPkts"),
                                primMalformedPktsTotal=item.get("primMalformedPktsTotal"),
                                primNetworkType=item.get("primNetworkType"),
                                primPositionMode=item.get("primPositionMode"),
                                primRecBitsS=item.get("primRecBitsS"),
                                primRecBytes=item.get("primRecBytes"),
                                primRecBytesTotal=item.get("primRecBytesTotal"),
                                primRecDupl=item.get("primRecDupl"),
                                primRecDuplTotal=item.get("primRecDuplTotal"),
                                primRecPktSize=item.get("primRecPktSize"),
                                primRecPkts=item.get("primRecPkts"),
                                primRecPktsS=item.get("primRecPktsS"),
                                primRecPktsTotal=item.get("primRecPktsTotal"),
                                primRecProto=item.get("primRecProto"),
                                primSentBitsS=item.get("primSentBitsS"),
                                primSentBytes=item.get("primSentBytes"),
                                primSentBytesTotal=item.get("primSentBytesTotal"),
                                primSentDupl=item.get("primSentDupl"),
                                primSentDuplTotal=item.get("primSentDuplTotal"),
                                primSentPktSize=item.get("primSentPktSize"),
                                primSentPkts=item.get("primSentPkts"),
                                primSentPktsS=item.get("primSentPktsS"),
                                primSentPktsTotal=item.get("primSentPktsTotal"),
                                primSentProto=item.get("primSentProto"),
                                primShortPkts=item.get("primShortPkts"),
                                primShortPktsTotal=item.get("primShortPktsTotal"),
                                primSignalStrength=item.get("primSignalStrength"),
                                primSnr=item.get("primSnr"),
                                primSpeed=item.get("primSpeed"),
                                qmId=item.get("qmId"),
                                recCbc=item.get("recCbc"),
                                recCbdTime=item.get("recCbdTime"),
                                recCbl=item.get("recCbl"),
                                recCblTot=item.get("recCblTot"),
                                recCorrectQosPk=item.get("recCorrectQosPk"),
                                recCorrectQosPkTotal=item.get("recCorrectQosPkTotal"),
                                recDSamples=item.get("recDSamples"),
                                recDelayMax=item.get("recDelayMax"),
                                recDelayMin=item.get("recDelayMin"),
                                recDelayS=item.get("recDelayS"),
                                recJitter=item.get("recJitter"),
                                recJitterMa=item.get("recJitterMa"),
                                recJitterMax=item.get("recJitterMax"),
                                recLostQosPk=item.get("recLostQosPk"),
                                recLostQosPkTotal=item.get("recLostQosPkTotal"),
                                recMaxCb=item.get("recMaxCb"),
                                recNotfTotal=item.get("recNotfTotal"),
                                recPacketLoss=item.get("recPacketLoss"),
                                recPacketLossTotal=item.get("recPacketLossTotal"),
                                recQoe1=item.get("recQoe1"),
                                recQoe2=item.get("recQoe2"),
                                recSentNotf=item.get("recSentNotf"),
                                recThExceededDelayPkts=item.get("recThExceededDelayPkts"),
                                recThExceededDelayPktsTotal=item.get("recThExceededDelayPktsTotal"),
                                recThExceededJitterPkts=item.get("recThExceededJitterPkts"),
                                recThExceededJitterPktsTotal=item.get("recThExceededJitterPktsTotal"),
                                resultsType=item.get("resultsType"),
                                secAccuracy=item.get("secAccuracy"),
                                secAge=item.get("secAge"),
                                secAltitude=item.get("secAltitude"),
                                secCellId=item.get("secCellId"),
                                secDroppedPkIf=item.get("secDroppedPkIf"),
                                secDroppedPkIfTotal=item.get("secDroppedPkIfTotal"),
                                secDroppedPkPcap=item.get("secDroppedPkPcap"),
                                secDroppedPkPcapTotal=item.get("secDroppedPkPcapTotal"),
                                secHeading=item.get("secHeading"),
                                secLatitude=item.get("secLatitude"),
                                secLongitude=item.get("secLongitude"),
                                secMalformedPkts=item.get("secMalformedPkts"),
                                secMalformedPktsTotal=item.get("secMalformedPktsTotal"),
                                secNetworkType=item.get("secNetworkType"),
                                secPositionMode=item.get("secPositionMode"),
                                secRecBitsS=item.get("secRecBitsS"),
                                secRecBytes=item.get("secRecBytes"),
                                secRecBytesTotal=item.get("secRecBytesTotal"),
                                secRecDupl=item.get("secRecDupl"),
                                secRecDuplTotal=item.get("secRecDuplTotal"),
                                secRecPktSize=item.get("secRecPktSize"),
                                secRecPkts=item.get("secRecPkts"),
                                secRecPktsS=item.get("secRecPktsS"),
                                secRecPktsTotal=item.get("secRecPktsTotal"),
                                secRecProto=item.get("secRecProto"),
                                secSentBitsS=item.get("secSentBitsS"),
                                secSentBytes=item.get("secSentBytes"),
                                secSentBytesTotal=item.get("secSentBytesTotal"),
                                secSentDupl=item.get("secSentDupl"),
                                secSentDuplTotal=item.get("secSentDuplTotal"),
                                secSentPktSize=item.get("secSentPktSize"),
                                secSentPkts=item.get("secSentPkts"),
                                secSentPktsS=item.get("secSentPktsS"),
                                secSentPktsTotal=item.get("secSentPktsTotal"),
                                secSentProto=item.get("secSentProto"),
                                secShortPkts=item.get("secShortPkts"),
                                secShortPktsTotal=item.get("secShortPktsTotal"),
                                secSignalStrength=item.get("secSignalStrength"),
                                secSnr=item.get("secSnr"),
                                secSpeed=item.get("secSpeed"),
                                sentCbc=item.get("sentCbc"),
                                sentCbdTime=item.get("sentCbdTime"),
                                sentCbl=item.get("sentCbl"),
                                sentCblTot=item.get("sentCblTot"),
                                sentCorrectQosPk=item.get("sentCorrectQosPk"),
                                sentCorrectQosPkTotal=item.get("sentCorrectQosPkTotal"),
                                sentDSamples=item.get("sentDSamples"),
                                sentDelayMax=item.get("sentDelayMax"),
                                sentDelayMin=item.get("sentDelayMin"),
                                sentDelayS=item.get("sentDelayS"),
                                sentJitter=item.get("sentJitter"),
                                sentJitterMa=item.get("sentJitterMa"),
                                sentJitterMax=item.get("sentJitterMax"),
                                sentLostQosPk=item.get("sentLostQosPk"),
                                sentLostQosPkTotal=item.get("sentLostQosPkTotal"),
                                sentMaxCb=item.get("sentMaxCb"),
                                sentPacketLoss=item.get("sentPacketLoss"),
                                sentPacketLossTotal=item.get("sentPacketLossTotal"),
                                sentQoe1=item.get("sentQoe1"),
                                sentQoe2=item.get("sentQoe2"),
                                sentSentNotf=item.get("sentSentNotf"),
                                sentSentNotfTotal=item.get("sentSentNotfTotal"),
                                sentThExceededDelayPkts=item.get("sentThExceededDelayPkts"),
                                sentThExceededDelayPktsTotal=item.get("sentThExceededDelayPktsTotal"),
                                sentThExceededJitterPkts=item.get("sentThExceededJitterPkts"),
                                sentThExceededJitterPktsTotal=item.get("sentThExceededJitterPktsTotal"),
                                time=item.get("time"),
                                trPrimSignalRsrp=item.get("trPrimSignalRsrp"),
                                trPrimSignalRsrq=item.get("trPrimSignalRsrq"),
                                trSecSignalRsrp=item.get("trSecSignalRsrp"),
                                trSecSignalRsrq=item.get("trSecSignalRsrq"),
                                tsPrimHandoverEvents=item.get("tsPrimHandoverEvents"),
                                tsRecDelayEstS=item.get("tsRecDelayEstS"),
                                tsRecDelayType=item.get("tsRecDelayType"),
                                tsSecHandoverEvents=item.get("tsSecHandoverEvents"),
                                tsSentDelayEstS=item.get("tsSentDelayEstS"),
                                tsSentDelayType=item.get("tsSentDelayType"),
                                ttPrimMacAddress=item.get("ttPrimMacAddress"),
                                ttSecMacAddress=item.get("ttSecMacAddress"),
                                nst_info=slice_info
                            )

                except ValueError:
                    return "Failed to parse response data."
            else:
                return "ok."

        time.sleep(50)