import json, httpx, asyncio
from channels.generic.websocket import AsyncWebsocketConsumer

class checksocket(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
        self.shouldstop = False
        await self.senddatatoclient()

    async def disconnect(self, close_code):
        self.shouldstop = True
        await self.close()

    async def senddatatoclient(self):
        while not self.shouldstop:
            response=await self.getstatusfromNNA()
            await self.send(text_data=json.dumps({"message":response}))
            await asyncio.sleep(5)

    async def getstatusfromNNA(self):
        async with httpx.AsyncClient() as client:
            response=await client.get("http://172.29.6.16:5000/experiment/1")
            if response.status_code==200:
                return response.json()
            else:
                return "N/A"



