from django.contrib import admin
from .models import SliceInfoForm,DataRecord,RunningSlice,APIResponse,DataRecord2,SelectedFields

admin.site.register(SliceInfoForm)
admin.site.register(APIResponse)
admin.site.register(DataRecord)
admin.site.register(DataRecord2)
admin.site.register(RunningSlice)
admin.site.register(SelectedFields)
try:
    admin.site.unregister(SliceInfoForm)
except admin.sites.NotRegistered:
    pass
class OuluTrialAdmin(admin.ModelAdmin):
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return self.readonly_fields + ('targetFacility',)
        return self.readonly_fields

admin.site.register(SliceInfoForm, OuluTrialAdmin)