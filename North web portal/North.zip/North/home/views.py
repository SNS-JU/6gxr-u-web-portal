import json, datetime
from .tasks import test
from datetime import datetime
from datetime import timedelta
from rest_framework import status
from dateutil.parser import isoparse
from django.http import HttpResponse
from celery.result import AsyncResult
from rest_framework.views import APIView
from .tasks import delete_nst_after_expiry
import  requests, time, json, csv, logging
logging.basicConfig(level=logging.INFO)
from rest_framework.response import Response
from django.core.exceptions import ObjectDoesNotExist
from rest_framework.permissions import IsAuthenticated
from .serializers import NstSerializer, GETNstSerializer
from rest_framework.pagination import PageNumberPagination
from django.shortcuts import HttpResponse, get_object_or_404
from .models import SliceInfoForm, SelectedFields, RunningSlice, APIResponse, DataRecord, DataRecord2


class NstAPIView(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request, *args, **kwargs):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            request_data = request.data
            trial_id = request_data["trial_id"]
            outgoing_data = {
                "trial_id": trial_id,
            }
            response = requests.post("http://127.0.0.1:9000/home/api/checknstid/", outgoing_data)
            # response = requests.post("http://127.0.0.1:8000/home/api/checknstid/", outgoing_data)

            if response.status_code == 200:
                initial_start_date = request.data["start_date"]
                initial_end_date = request.data["end_date"]
                usertimezone = request.data["timezone"]
                applications = request.data["applications"]
                if initial_start_date >= initial_end_date:
                    return Response(
                        {"error": "end time must not be before the start time."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                start_datetime = datetime.fromisoformat(initial_start_date)
                end_datetime = datetime.fromisoformat(initial_end_date)
                from django.utils.timezone import make_aware
                from datetime import timezone
                utc = timezone.utc
                from zoneinfo import ZoneInfo 
                timezonecreation = ZoneInfo(usertimezone)
                localtime_start = make_aware(start_datetime, timezone=timezonecreation)
                localtime_end = make_aware(end_datetime, timezone=timezonecreation)
                starttoutctime = localtime_start.astimezone(utc)
                endtoutctime = localtime_end.astimezone(utc)

                request.data["start_date"] = starttoutctime.isoformat()
                request.data["end_date"] = endtoutctime.isoformat()

                serializer = NstSerializer(data=request.data)
                if serializer.is_valid():
                    saved_instance = serializer.save()
                    end_time_utc = isoparse(request.data["end_date"])
                    delete_time = end_time_utc + timedelta(minutes=10)

                    delete_nst_after_expiry.apply_async(
                        args=(saved_instance.id, request.user.id),
                        eta=delete_time
                    )
                    return Response(serializer.data, status=status.HTTP_201_CREATED)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            elif response.status_code == 423:
                return Response({"error": "trial has been expired"})
            else:
                return Response("There is no trial.", status=status.HTTP_404_NOT_FOUND)

    # PUT request: Update an existing record
    def put(self, request):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            request_data = request.data
            apps = request.data.get('applications', [])
            trial_id = request_data["trial_id"]
            outgoing_data = {
                "trial_id": trial_id,
            }
            testres = requests.post("http://127.0.0.1:9000/home/api/checknstid/", outgoing_data)
            # testres = requests.post("http://127.0.0.1:8000/home/api/checknstid/", outgoing_data)
            if testres.status_code == 200:
                try:
                    form = SliceInfoForm.objects.get(id=request.data["nst_id"], user=request.user.id)
                except ObjectDoesNotExist:
                    return Response({"error": "No form associated with this user."}, status=status.HTTP_404_NOT_FOUND)

                from django.utils.timezone import make_aware, is_naive
                from datetime import timezone
                from zoneinfo import ZoneInfo

                # Retrieve data from the request
                initial_start_date = request.data.get("start_date")
                initial_end_date = request.data.get("end_date")
                usertimezone = request.data.get("timezone")
                if initial_start_date >= initial_end_date:
                    return Response(
                        {"error": "end time must not be before the start time."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
                utc = timezone.utc

                # Only process start_date if it's provided
                if initial_start_date:
                    start_datetime = datetime.fromisoformat(initial_start_date)
                    timezonecreation = ZoneInfo(usertimezone)
                    if is_naive(start_datetime):
                        localtime_start = make_aware(start_datetime, timezone=timezonecreation)
                    else:
                        # If already aware, just convert to the specified timezone
                        localtime_start = start_datetime.astimezone(timezonecreation)
                    starttoutctime = localtime_start.astimezone(utc)
                    request.data["start_date"] = starttoutctime.isoformat()

                # Only process end_date if it's provided
                if initial_end_date:
                    end_datetime = datetime.fromisoformat(initial_end_date)
                    timezonecreation = ZoneInfo(usertimezone)
                    if is_naive(end_datetime):
                        localtime_end = make_aware(end_datetime, timezone=timezonecreation)
                    else:
                        # If already aware, just convert to the specified timezone
                        localtime_end = end_datetime.astimezone(timezonecreation)
                    endtoutctime = localtime_end.astimezone(utc)
                    request.data["end_date"] = endtoutctime.isoformat()
            
                # Serialize and validate the data
                if not isinstance(apps, list):
                    apps = [apps]

                if len(apps) < 2:
                    apps += [''] * (2 - len(apps))
                else:
                    apps = apps[:2]  # only first two if more than 2
                request.data['applications'] = apps
                print("KKKKKKK", apps)
                serializer = NstSerializer(form, data=request.data, partial=True)  # `partial=True` allows partial updates
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data, status=status.HTTP_200_OK)
                else:
                    print("GGGGGGGGG", serializer.errors)
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response("There is no Trial ID.")

    # DELETE request: Delete a record
    def delete(self, request):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            try:
                # Fetch the SliceInfoForm instance
                nst = SliceInfoForm.objects.get(id=request.data["nst_id"], user=request.user.id)
                nst_name = nst.name  # Save the name before deleting for message display
                # Check for related RunningSlice and delete
                running_slice_entry = RunningSlice.objects.filter(nst_id=nst.id).first()
                if running_slice_entry:
                    running_slice_entry.delete()
                # Delete the SliceInfoForm entry
                DataRecord.objects.filter(nst_info=nst).delete()
                DataRecord2.objects.filter(nst_info=nst).delete()
                APIResponse.objects.all().delete()

                deleteselected = SelectedFields.objects.filter(slice_info=nst)
                for item in deleteselected:
                    item.delete()
                # SelectedFields.delete()
                # Delete related entries in DataRecord and DataRecord2
                nst.delete()
                external_api_response = requests.delete(f"http://172.29.6.16:5000/experiment/1")
                if external_api_response.status_code != 200:
                    print(
                        f"Failed to notify external API for slice {nst.id}. Status: {external_api_response.status_code}")

                return Response({"message": f"Slice {nst_name} and related data deleted successfully."},
                                status=status.HTTP_200_OK)
            except SliceInfoForm.DoesNotExist:
                return Response({"error": "Slice not found."}, status=status.HTTP_404_NOT_FOUND)


class SubmitToAPI(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            # Fetch the SliceInfoForm instance
            nst_info = SliceInfoForm.objects.get(id=request.data["nst_id"], user=request.user.id)
            # Check if there is an active slice
            any_running_slice = RunningSlice.objects.first()
            if any_running_slice:
                active_nst_id = any_running_slice.nst_id
                active_trial_id = any_running_slice.trial_id
                return Response(
                    {
                        "error": f"An active slice (ID: {active_nst_id}) with trial ID {active_trial_id} "
                                 f"is already running in the system. Cannot proceed with the submission."
                    },
                    status=status.HTTP_400_BAD_REQUEST,
                )
            # Prepare the slices list, only including non-null slice types
            slices = []
            if nst_info.slice1_type:
                slices.append(nst_info.slice1_type)
            if nst_info.slice2_type:
                slices.append(nst_info.slice2_type)
            # Prepare the data to send to the API
            starttime = datetime.fromisoformat(nst_info.start_date.isoformat())
            endtime = datetime.fromisoformat(nst_info.end_date.isoformat())

            data = {
                "nst": json.dumps({
                    "trialId": nst_info.trial_id,
                    "startTime": starttime.strftime('%Y-%m-%dT%H:%M:%SZ'),
                    "stopTime": endtime.strftime('%Y-%m-%dT%H:%M:%SZ'),
                    "slices": slices,
                    "applications": nst_info.applications
                })
            }
            # Define the API endpoint and post data
            url = "http://172.29.6.16:5000/experiment"
            # Send the request
            response = requests.post(url, data=data)  # Pass `data` directly as a dictionary
            # Process the response
            if response.status_code == 200:  # Successful creation
                response_data = response.json()
                # Extract the 'id' and 'type' for each slice from the response
                slices_list = response_data.get("slices", [])
                default_nst_id = response_data.get("defaultSliceId")
                slice0_id = default_nst_id
                slice1_id, slice1_type = (slices_list[0]["id"], slices_list[0]["type"]) if len(slices_list) > 0 else (
                    None, None)
                slice2_id, slice2_type = (slices_list[1]["id"], slices_list[1]["type"]) if len(slices_list) > 1 else (
                    None, None)
                # Save the slice_id and trial_id to RunningSlice
                nst_id = SliceInfoForm.objects.get(id=request.data["nst_id"])
                RunningSlice.objects.create(nst_id=nst_id,
                                            trial_id=nst_info.trial_id,
                                            nst_name=nst_info.name,
                                            slices=slices
                                            )
                # Save the extracted slice data to the APIResponse table with separate fields
                APIResponse.objects.create(
                    nst_id=nst_id,
                    trial_id=nst_info.trial_id,
                    slice0_id=slice0_id,
                    slice1_id=slice1_id,
                    slice1_type=slice1_type,
                    slice2_id=slice2_id,
                    slice2_type=slice2_type,
                    slice_data=slices_list,
                    status_code=response.status_code
                )
                return Response({"message": "Data submitted successfully.", "response": response_data},
                                status=status.HTTP_201_CREATED)
            else:
                # If the API request fails
                return Response({"error": "Failed to submit data to the external API.", "details": response.text},
                                status=response.status_code)


class FetchOuluTrialsView(APIView):
    permission_classes = [IsAuthenticated]
    """
    API view to fetch trial IDs and names from an external API
    filtered by the facility name 'Oulu'.
    """

    def post(self, request):
        external_api_url = "http://127.0.0.1:9000/home/api/gettrialfornst/"
        # external_api_url = "http://127.0.0.1:8000/home/api/gettrialfornst/"
        try:
            # Fetch all trials from the external API
            response = requests.post(external_api_url, request.data)
            trials = response.json()
            # Filter trials for facility "Oulu"
            if request.data["trial_direction"] == "Oulu":
                oulu_trials = [
                    {"trial_id": trial["trial_id"], "name": trial["name"]}
                    for trial in trials
                    if trial.get("facility") == "Oulu"
                ]

            return Response(oulu_trials, status=status.HTTP_200_OK)
        except requests.exceptions.RequestException as e:
            return Response(
                {"error": "Failed to fetch trials from external API", "details": str(e)},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )


class checktrialid(APIView):
    def post(self, request, *args, **kwargs):
        request_data = request.data
        trial_id = request_data["trial_id"]
        outgoing_data = {
            "trial_id": trial_id,
        }
        testres = requests.post("http://127.0.0.1:9000/home/api/checknstid/", outgoing_data)
        return Response("done", status=status.HTTP_200_OK)

class NSTPagination(PageNumberPagination):
    page_size = 10 

class getnst(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = PageNumberPagination
    page_size = 10

    def paginate_queryset(self, queryset):
        paginator = self.pagination_class()
        paginator.page_size = self.page_size  
        return paginator.paginate_queryset(queryset, self.request)

    def post(self, request, format=None):
        trial_id = request.data.get('trial_id')
        nst_id = request.data.get('nst_id')

        if trial_id:
            trials_res = requests.post(
                'http://127.0.0.1:8000/home/api/gettrialstimefornst/', 
                {'trial_id': trial_id}
            )

            trials_data = trials_res.json()[0]
            start_time = trials_data.get('start_date')
            end_time = trials_data.get('end_date')

            trial = SliceInfoForm.objects.filter(user=request.user.id, trial_id=int(trial_id))
            paginator = NSTPagination()
            page = paginator.paginate_queryset(trial, request)

            if page is not None:
                serializer = GETNstSerializer(page, many=True)
                paginated_data = paginator.get_paginated_response(serializer.data).data

                paginated_data['unified_start_time'] = start_time
                paginated_data['unified_end_time'] = end_time

                return Response(paginated_data)

        elif nst_id:
            nst = SliceInfoForm.objects.get(user=request.user.id, id=nst_id)
            ser_nst = GETNstSerializer(nst)
            return Response(ser_nst.data, status=status.HTTP_200_OK)


class DeleteRelatedSlicesAPIView(APIView):
    def post(self, request):
        """
        Deletes NSTs and RunningSlice entries related to a Trial ID.
        """
        trial_id = request.data.get("trial_id")
        if not trial_id:
            return Response({"error": "Trial ID is required"}, status=status.HTTP_400_BAD_REQUEST)

        # Step 1: Delete all NSTs related to the Trial ID
        try:
            nst_entries = SliceInfoForm.objects.filter(trial_id=trial_id)
            if not nst_entries.exists():
                return Response({"message": f"No NSTs found for Trial ID {trial_id}"}, status=status.HTTP_200_OK)
            # Step 2: Delete DataRecord and DataRecord2 associated with each NST
            for nst in nst_entries:
                DataRecord.objects.filter(nst_info=nst).delete()
                DataRecord2.objects.filter(nst_info=nst).delete()
                deleteselected = SelectedFields.objects.filter(slice_info=nst.id)
                for item in deleteselected:
                    item.delete()
            nst_entries.delete()
            running_slices = RunningSlice.objects.filter(trial_id=trial_id)
            for item in running_slices:
                item.delete()
            external_api_url = f"http://172.29.6.16:5000/experiment/1"
            external_api_response = requests.delete(external_api_url)

            if external_api_response.status_code != 200 or external_api_response.status_code != 404 or external_api_response.status_code != 500:
                return Response({
                                    "error": f"Failed to delete trial in external API. Status: {external_api_response.status_code}, Response: {external_api_response.text}"},
                                status=external_api_response.status_code)

            return Response({"message": f"Successfully deleted Trial ID {trial_id} and related entries."},
                            status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": f"Failed to delete NSTs for Trial ID {trial_id}. Error: {str(e)}"},
                            status=status.HTTP_400_BAD_REQUEST)


class NstStatus(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            try:
                nststatus = RunningSlice.objects.first()
            except RunningSlice.DoesNotExist:
                return Response({"error": "No RunningSlice found"}, status=status.HTTP_400_BAD_REQUEST)

            if nststatus.nst_id.id == request.data['nst_id']:
                if nststatus.nst_id.user.id == request.data['user']:
                    try:
                        getfromNNA = requests.get('http://172.29.6.16:5000/experiment/1')

                        return Response({"data": getfromNNA.json()["state"]}, status=status.HTTP_200_OK)
                    except requests.RequestException as e:
                        return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                else:
                    return Response({"error": "You are not allowed to use this API"},
                                    status=status.HTTP_400_BAD_REQUEST)

            else:
                return Response({"error": "NST ID does not match"}, status=status.HTTP_400_BAD_REQUEST)


class runningnstmessage(APIView):
    permission_classes = [IsAuthenticated]
    def get(self, request):
        try:
            nstmessage = RunningSlice.objects.first()
            if nstmessage is None:
                return Response({"error": "No RunningSlice found"}, status=status.HTTP_400_BAD_REQUEST)
        except RunningSlice.DoesNotExist:
            pass
        start_time = nstmessage.nst_id.start_date
        end_time = nstmessage.nst_id.end_date
        if nstmessage.nst_id.user.id != request.user.id:
            return Response({
                                "message": f'Currently, an experiment is running from {start_time} to {end_time}. You cannot start a new experiment unless the current running experiment is completed or deleted by the user who created it. However, once the experiment ends, it will be automatically removed within 10 minutes, and you can then create your own experiment.'},
                            status=status.HTTP_200_OK)
        else:
            return Response({
                                "message": f'Hi! {nstmessage.nst_id.user.username}. Currently, experiment {nstmessage.nst_name} is running from {start_time} to {end_time}.You cannot start a new experiment unless the current running experiment is completed or deleted.'},
                            status=status.HTTP_200_OK)


class send_query(APIView):
    def post(self, request):
        # Get the slice information
        slice_id = request.data['slice_id']
        slice_info = get_object_or_404(SliceInfoForm, id=slice_id)
        # Extract the slice response data
        response_entry = APIResponse.objects.filter(nst_id=slice_id, trial_id=slice_info.trial_id).first()
        # Prepare extracted_ids list based on the availability of slice1_id and slice2_id
        extracted_ids = []
        if response_entry:
            # Always use slice1_id if it exists
            if response_entry.slice1_id:
                extracted_ids.append(response_entry.slice1_id)
            # If slice2_id exists, include it (ensures slice1 is always included when slice2 is present)
            if response_entry.slice2_id:
                extracted_ids.append(response_entry.slice2_id)
            # Fallback: use slice0_id if no slice1 or slice2 exist
            if not response_entry.slice1_id and not response_entry.slice2_id:
                extracted_ids.append(response_entry.slice0_id)
        # Extract the start and end times in ISO format
        experiment_start_time_iso = datetime.fromisoformat(slice_info.start_date.isoformat())
        experiment_end_time_iso = datetime.fromisoformat(slice_info.end_date.isoformat())

        experiment_start_time_epoch = int(experiment_start_time_iso.timestamp())*1000
        experiment_end_time_epoch = int(experiment_end_time_iso.timestamp())*1000
        task = test.apply_async(args=(experiment_start_time_epoch, experiment_end_time_epoch),
                                kwargs={"data": [{"nst_id": extracted_ids}, {"slice_info": slice_info.id}]})

        return Response(task.id)


class terminate(APIView):
    def delete(self, request, pk):
        try:
            taskresult = AsyncResult(pk)
            taskresult.revoke(terminate=True)
            time.sleep(1)
            updated_state = taskresult.state
            external_api_response = requests.delete(f"http://172.29.6.16:5000/experiment/1")
            if external_api_response.status_code == 200 or external_api_response.status_code == 404 :
                #RunningSlice.objects.all().delete()
                APIResponse.objects.all().delete()
                SelectedFields.objects.all().delete()
        except:
            return Response({"message": updated_state, "external_api_response": external_api_response.status_code})
        return Response({"message": updated_state})


global selected_fields
selected_fields = []
class grafana(APIView):
    def post(self, request):
        """
        POST request to dynamically set the fields.
        """
        # global selected_fields
        user = request.user  # Get the authenticated user
        slice_id = request.data.get('slice_id')  # Slice ID must be provided
        fields = request.data.get('fields', [])

        if not slice_id:
            return Response({"error": "Slice ID is required"}, status=400)

        if not fields:
            return Response({"error": "No fields provided"}, status=400)

        # Ensure 'time' is always included
        if 'time' not in fields:
            fields.append('time')

        try:
            # Get the slice instance
            slice_info = SliceInfoForm.objects.get(id=slice_id)

            # Save the selected fields to the database
            selected_fields_entry, created = SelectedFields.objects.update_or_create(
                user=user,
                slice_info=slice_info,
                defaults={'fields': fields}
            )
            selected_fields = fields

            return Response({"message": "Fields updated successfully", "fields": selected_fields_entry.fields},
                            status=200)

        except SliceInfoForm.DoesNotExist:
            return Response({"error": "Slice not found"}, status=404)

    def get(self, request, *args, **kwargs):
        # global selected_fields
        testquery = SelectedFields.objects.first()

        # Ensure 'time' field is included
        if 'time' not in selected_fields:
            selected_fields.append('time')

        # Fetch data from the database
        data = DataRecord.objects.values(*testquery.fields)
        # Replace null values with 0
        rows = []
        for row in data:
            row_list = [value if value is not None else 0 for value in row.values()]
            rows.append(row_list)

        # Prepare the response
        response = {
            "columns": [{"text": field, "type": "number" if field != "time" else "time"} for field in testquery.fields],
            "rows": rows,
            "type": "table",
        }

        return Response(response)


class grafana2(APIView):
    def get(self, request, *args, **kwargs):
        testquery = SelectedFields.objects.first()

        # Ensure 'time' field is included
        if 'time' not in selected_fields:
            selected_fields.append('time')

        # Fetch data from the database
        data = DataRecord2.objects.values(*testquery.fields)

        # Replace null values with 0
        rows = []
        for row in data:
            row_list = [value if value is not None else 0 for value in row.values()]
            rows.append(row_list)

        # Prepare the response
        response = {
            "columns": [{"text": field, "type": "number" if field != "time" else "time"} for field in testquery.fields],
            "rows": rows,
            "type": "table",
        }
        return Response(response)


class DownloadCSVView(APIView):
    def post(self, request):
        try:
            fields = SelectedFields.objects.first().fields
            if not fields or not isinstance(fields, list):
                return Response({"error": "No valid fields received from the Grafana API."},
                                status=status.HTTP_400_BAD_REQUEST)
        except requests.exceptions.RequestException as e:
            return Response({"error": "Failed to connect to the Grafana API."},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        try:
            data = DataRecord.objects.values(*fields)
        except Exception as e:
            return Response({"error": f"Invalid fields: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        # Create CSV response
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="data.csv"'

        writer = csv.DictWriter(response, fieldnames=fields)
        writer.writeheader()
        for row in data:
            writer.writerow({field: row.get(field, '') for field in fields})
        return response


class DownloadCSVView2(APIView):
    def post(self, request):
        try:
            fields = SelectedFields.objects.first().fields
            if not fields or not isinstance(fields, list):
                return Response({"error": "No valid fields received from the Grafana API."},
                                status=status.HTTP_400_BAD_REQUEST)
        except requests.exceptions.RequestException as e:
            return Response({"error": "Failed to connect to the Grafana API."},
                            status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        try:
            data = DataRecord2.objects.values(*fields)
        except Exception as e:
            return Response({"error": f"Invalid fields: {str(e)}"}, status=status.HTTP_400_BAD_REQUEST)
        # Create CSV response
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="data.csv"'

        writer = csv.DictWriter(response, fieldnames=fields)
        writer.writeheader()
        for row in data:
            writer.writerow({field: row.get(field, '') for field in fields})
        return response

class checkrunning(APIView):
    def get(self, request):
        running = RunningSlice.objects.first()
        if running is None:
            return Response("No running slice", status=status.HTTP_404_NOT_FOUND)
        else:
            return Response({'running': running.nst_id.id}, status=status.HTTP_200_OK)

