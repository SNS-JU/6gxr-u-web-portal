import pytz
from .models import SliceInfoForm
from rest_framework import serializers

class NstSerializer(serializers.ModelSerializer):
    applications = serializers.ListField(
        child=serializers.CharField(allow_blank=True, allow_null=True),
        required=False,
        allow_null=True
    )
    class Meta:
        model = SliceInfoForm
        fields = (
        "trial_id",
        "name",
        "start_date",
        "end_date",
        "targetNode",
        "targetFacility",
        'slice_option',
        'slice1_type',
        'slice2_type',
        'id',
        'user',
        'applications',
        )

        read_only_fields = (
        "targetNode",
        "targetFacility",
        )


    def validate(self, data):
        slice_option = data.get('slice_option')
        slice1_type = data.get('slice1_type')
        slice2_type = data.get('slice2_type')

        if slice_option == 'no_slice' and (slice1_type or slice2_type):
            raise serializers.ValidationError(
                "slice1_type and slice2_type must be null if slice_option is 'no_slices'."
            )
        if slice_option == 'one_slice' and not slice1_type:
            raise serializers.ValidationError(
                "slice1_type is required if slice_option is 'one_slice'."
            )
        if slice_option == 'two_slices' and (not slice1_type or not slice2_type):
            raise serializers.ValidationError(
                "slice1_type and slice2_type are required if slice_option is 'two_slices'."
            )
        return data

class GETNstSerializer(serializers.ModelSerializer):
    start_date=serializers.SerializerMethodField()
    end_date=serializers.SerializerMethodField()
    class Meta:
        model = SliceInfoForm
        fields = (
        "trial_id",
        "name",
        "start_date",
        "end_date",
        "targetNode",
        "targetFacility",
        'slice_option',
        'slice1_type',
        'slice2_type',
        'id',
        'user',
        'applications',
        )

        read_only_fields = (
        "targetNode",
        "targetFacility",
        )

    def get_start_date(self, obj):
        return self.convert_to_timezone(obj.start_date, "Europe/Helsinki")
    def get_end_date(self, obj):
        return self.convert_to_timezone(obj.end_date, "Europe/Helsinki")
    def convert_to_timezone(self, field, timezone_str):
        if field:
            helsinki_tz = pytz.timezone(timezone_str)
            localized_date = field.astimezone(helsinki_tz)
            return localized_date.strftime('%Y-%m-%d %H:%M:%S') 
        return None