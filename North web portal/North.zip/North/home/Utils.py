import requests
def fetch_trial_ids():
    response = requests.get('http://127.0.0.1:9000/home/api/trials/?facility=Oulu')
    if response.status_code == 200:
        trials = response.json()
        # Only include trials where the facility is 'Oulu'
        return [(trial['trial_id'], trial['name']) for trial in trials]
    return []