
from django.urls import path
from .views import checktrialid
from .views import SubmitToAPI,NstAPIView,FetchOuluTrialsView,terminate,DownloadCSVView,checkrunning, DeleteRelatedSlicesAPIView,grafana2,getnst,DeleteRelatedSlicesAPIView,NstStatus,runningnstmessage,send_query,grafana,DownloadCSVView2


app_name = 'home'
urlpatterns = [
    path('api/oulu-trials/', FetchOuluTrialsView.as_view(), name='fetch_oulu_trials'),
    path('api/nst/', NstAPIView.as_view(), name='nst'),
    path('api/submit/', SubmitToAPI.as_view(), name='submit-to-api'),
    path('api/checktrialid/', checktrialid.as_view(), name='checktrialid'),
    path('api/getnst/', getnst.as_view(), name='getnst'),
    path('api/delete_related_slices/', DeleteRelatedSlicesAPIView.as_view(), name='delete_related_slices'),
    path('api/NstStatus/', NstStatus.as_view(), name='NstStatus'),
    path('api/runningnstmessage/', runningnstmessage.as_view(), name='runningnstmessage'),
    path('api/sendquery/', send_query.as_view()),
    path('api/grafana/', grafana.as_view()),
    path('api/grafana2/', grafana2.as_view()),
    path('api/terminate/<str:pk>/', terminate.as_view()),
    path('api/downloadcsvview/', DownloadCSVView.as_view()),
    path('api/downloadcsvview2/', DownloadCSVView2.as_view()),
    path('api/checkrunning/', checkrunning.as_view()),
]
