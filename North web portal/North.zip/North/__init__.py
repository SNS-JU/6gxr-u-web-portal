from __future__ import absolute_import, unicode_literals

from .celery_app import app as celery_app

all = ('celery_app',)
