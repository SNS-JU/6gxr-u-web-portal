import 'src/global.css';

import { useEffect } from 'react';
import ThemeProvider from './theme/theme-provider';
import { usePathname } from 'src/routes/hooks';

import { UiSettingsProvider } from 'src/context/ui-settings';
import { LayoutStyleProvider } from 'src/context/layout-style';

type AppProps = {
  children: React.ReactNode;
};

export default function App({ children }: AppProps) {
  useScrollToTop();

  return (
    <ThemeProvider>
      <UiSettingsProvider>
        <LayoutStyleProvider>{children}</LayoutStyleProvider>
      </UiSettingsProvider>
    </ThemeProvider>
  );
}

function useScrollToTop() {
  const pathname = usePathname();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}
