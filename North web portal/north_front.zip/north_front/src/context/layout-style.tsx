import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

export type LayoutMode = 'grid' | 'list' | 'masonry';

export type LayoutStyleState = {
  mode: LayoutMode;
  columns: number; // 1..8
  gap: number; // MUI spacing unit integer (px = theme.spacing(gap))
  dense: boolean; // compact cards
  radius: number; // px
};

const DEFAULT_STATE: LayoutStyleState = {
  mode: 'grid',
  columns: 3,
  gap: 2, // theme.spacing(2) => 16px
  dense: false,
  radius: 12,
};

const STORAGE_KEY = 'layout-style:v1';

const Ctx = createContext<{
  style: LayoutStyleState;
  setStyle: React.Dispatch<React.SetStateAction<LayoutStyleState>>;
  applyQueryParam: () => void;
} | null>(null);

export function LayoutStyleProvider({ children }: { children: React.ReactNode }) {
  const [style, setStyle] = useState<LayoutStyleState>(() => {
    try {
      const v = localStorage.getItem(STORAGE_KEY);
      if (v) return JSON.parse(v);
    } catch {}
    return DEFAULT_STATE;
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(style));
    } catch {}
  }, [style]);

  const applyQueryParam = useCallback(() => {
    const url = new URL(window.location.href);
    const q = url.searchParams.get('layout'); // e.g. grid-4 | list | masonry-3
    if (!q) return;
    const [mode, n] = q.split('-');
    const cols = n ? Math.max(1, Math.min(8, parseInt(n))) : undefined;
    if (mode === 'grid' || mode === 'list' || mode === 'masonry') {
      setStyle((s) => ({ ...s, mode: mode as LayoutMode, ...(cols ? { columns: cols } : {}) }));
    }
  }, []);

  useEffect(() => {
    applyQueryParam();
  }, [applyQueryParam]);

  const value = useMemo(() => ({ style, setStyle, applyQueryParam }), [style]);

  // Expose CSS custom properties so you can use them in plain CSS if needed
  return (
    <Ctx.Provider value={value}>
      <div
        style={{
          ['--layout-radius' as any]: `${style.radius}px`,
          ['--layout-gap' as any]: `var(--mui-spacing, 8px)`,
        }}
      >
        {children}
      </div>
    </Ctx.Provider>
  );
}

export function useLayoutStyle() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error('useLayoutStyle must be used within LayoutStyleProvider');
  return ctx;
}
