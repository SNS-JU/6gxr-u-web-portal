import React, { createContext, useContext, useState, ReactNode } from 'react';
import Snackbar from '@mui/material/Snackbar';
import Alert, { AlertColor } from '@mui/material/Alert';
import Slide, { SlideProps } from '@mui/material/Slide';
import { useTheme } from '@mui/material/styles';

// ----------------------------------------------------------------------

function TransitionUp(props: SlideProps) {
  return <Slide {...props} direction="up" />;
}

interface Notification {
  id: number;
  message: string;
  severity: AlertColor;
}

interface NotificationContextType {
  showNotification: (message: string, severity: AlertColor) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider = ({ children }: { children: ReactNode }) => {
  const theme = useTheme();
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const showNotification = (newMessage: string, newSeverity: AlertColor) => {
    const id = Date.now();
    setNotifications((prev) => [...prev, { id, message: newMessage, severity: newSeverity }]);
  };

  const handleClose = (id: number) => {
    setNotifications((prev) => prev.filter((notif) => notif.id !== id));
  };

  return (
    <NotificationContext.Provider value={{ showNotification }}>
      {children}

      {notifications.map((notif, index) => (
        <Snackbar
          key={notif.id}
          open
          autoHideDuration={4000}
          onClose={() => handleClose(notif.id)}
          TransitionComponent={TransitionUp}
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          sx={{
            marginBottom: `${index * 60}px`,
          }}
        >
          <Alert
            onClose={() => handleClose(notif.id)}
            severity={notif.severity}
            variant="filled"
            sx={{
              width: '100%',
              boxShadow: theme.shadows[10],
              borderRadius: '8px',
            }}
          >
            {notif.message}
          </Alert>
        </Snackbar>
      ))}
    </NotificationContext.Provider>
  );
};
