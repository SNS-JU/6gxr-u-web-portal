export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://193.166.32.46:8080';
// export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8001';
export const ENDPOINTS = {
  token: '/users/api/token/',
  refresh: '/users/api/token/refresh/',
  register: '/users/api/users/register/',
  profile: '/users/api/users/profile/',
  profileUpdate: '/users/api/users/edit/',
  home: {
    nst: '/home/api/nst/',
    newNstUpdate: `/home/api/nst/`,
    newDeleteNst: `/home/api/nst/`,
    submit: '/home/api/submit/',
    sendQuery: '/home/api/sendquery/',
  },
  stats: {
    nstList: `/home/api/nst/`,
    nstListPost: `/home/api/getnst/`,
    trialList: `/home/api/oulu-trials/`,
  },

  auth: {
    changeReq: '/users/api/passresreq/',
    verifCode: '/users/api/codeverification/',
    changePass: '/users/api/Passresetconfirmtion/',
  },
};
