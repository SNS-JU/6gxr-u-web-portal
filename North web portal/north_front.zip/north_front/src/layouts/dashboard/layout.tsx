// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import { Link as RouterLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import DarkModeIcon from '@mui/icons-material/DarkMode';
import LightModeIcon from '@mui/icons-material/LightMode';

import MenuIcon from '@mui/icons-material/Menu';
import LogoutIcon from '@mui/icons-material/Logout';
import { DeleteSharp } from '@mui/icons-material';
import ListAltIcon from '@mui/icons-material/ListAlt';
import { styled, useTheme } from '@mui/material/styles';
import SettingsIcon from '@mui/icons-material/Settings';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import SpaceDashboardOutlinedIcon from '@mui/icons-material/SpaceDashboardOutlined'; // Rail
import ViewSidebarOutlinedIcon from '@mui/icons-material/ViewSidebarOutlined'; // Sidebar
import HorizontalSplitOutlinedIcon from '@mui/icons-material/HorizontalSplitOutlined'; // Top
import BlurOnOutlinedIcon from '@mui/icons-material/BlurOnOutlined'; // Integrate
import LayersOutlinedIcon from '@mui/icons-material/LayersOutlined'; // Apparent
import {
  AppBar,
  Avatar,
  Box,
  Button,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Paper,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
  useMediaQuery,
  ToggleButtonGroup,
  ToggleButton,
  Switch,
  FormControlLabel,
  Card,
  CardContent,
  CardHeader,
  Chip,
  Tabs,
  Tab,
  ButtonBase,
} from '@mui/material';

import { useThemeMode } from 'src/theme/theme-provider';
import { useAuthContext } from '../../auth/hooks/use-auth-context';
import { useUiSettings } from 'src/context/ui-settings';
import { useNotification } from 'src/context/notification-context';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import { paths } from 'src/routes/paths';

const DRAWER_WIDTH = 260;
const RAIL_WIDTH = 100;

const Main = styled('main')(({ theme }) => ({
  flexGrow: 1,
  minHeight: '100vh',
  background: theme.vars.palette.background.default,
  padding: theme.spacing(3),
}));

const NAV_ITEMS = [
  { label: 'Experiment', to: '/dashboard/nst-list', icon: <ListAltIcon /> },
  { label: 'User Guide', to: '/dashboard/about', icon: <InfoOutlinedIcon /> },
];

export function DashboardLayout({ children }: { children?: React.ReactNode }) {
  const theme = useTheme();
  const mdUp = useMediaQuery(theme.breakpoints.up('md'));
  const { settings } = useUiSettings();

  const [collapsed, setCollapsed] = React.useState(false);
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [right, setRight] = React.useState<null | 'settings' | 'profile'>(null);

  const isRail = settings.navLayout === 'rail';
  const isSidebar = settings.navLayout === 'sidebar';
  const isTop = settings.navLayout === 'top';
  const isRTL = settings.rtl;
  const navAnchor: 'left' | 'right' = isRTL ? 'right' : 'left';

  const drawerWidth = isRail ? RAIL_WIDTH : DRAWER_WIDTH;
  const showLeftPermanent = mdUp && (isRail || isSidebar);

  const appBarSx =
    settings.navColor === 'integrate'
      ? {
          borderBottom: '1px solid',
          borderColor: 'divider',
          bgcolor: 'transparent',
          boxShadow: 'none',
        }
      : { bgcolor: 'background.paper', boxShadow: theme.shadows[2] };

  const drawerPaperSx = (baseWidth: number, anchor: 'left' | 'right') => ({
    width: baseWidth,
    overflow: 'visible',
    boxSizing: 'border-box',
    ...(anchor === 'left'
      ? { borderRight: '1px solid', borderColor: 'divider' }
      : { borderLeft: '1px solid', borderColor: 'divider' }),
    transition: (t: any) =>
      t.transitions.create('width', { duration: t.transitions.duration.shorter }),
    ...(settings.navColor === 'integrate'
      ? {
          bgcolor: `rgba(${theme.vars.palette.background.paperChannel} / 0.72)`,
          backdropFilter: 'saturate(120%) blur(8px)',
          boxShadow: 'none',
        }
      : {
          bgcolor: theme.vars.palette.background.paper,
          boxShadow: theme.shadows[2],
        }),
  });

  const { showNotification } = useNotification();
  const handleLogout = () => {
    showNotification('Logged out successfully', 'info');
    setTimeout(() => {
      sessionStorage.removeItem('accessToken');
      sessionStorage.removeItem('accessToken.refresh');
      sessionStorage.removeItem('userId');
      window.location.reload();
    }, 2000);
  };

  return (
    <Box sx={{ display: 'flex' }}>
      {showLeftPermanent && (
        <Drawer
          variant="permanent"
          anchor={navAnchor}
          open
          sx={{
            order: isRTL ? 2 : 0,
            width: drawerWidth,
            flexShrink: 0,
            '& .MuiDrawer-paper': drawerPaperSx(drawerWidth, navAnchor),
          }}
        >
          <Sidebar collapsed={isRail ? true : collapsed} />
        </Drawer>
      )}

      <Drawer
        variant="temporary"
        anchor={navAnchor}
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': drawerPaperSx(DRAWER_WIDTH, navAnchor),
        }}
      >
        <Sidebar collapsed={false} onNavigate={() => setMobileOpen(false)} />
      </Drawer>

      {/* AppBar */}
      <AppBar color="inherit" elevation={0} position="fixed" sx={appBarSx}>
        <Toolbar>
          <Stack direction="row" alignItems="center" spacing={1} sx={{ flex: 1 }}>
          </Stack>

          <Stack direction="row" alignItems="center" spacing={1.5}>
            <IconButton
              size={settings.compact ? 'small' : 'medium'}
              onClick={() => setRight('settings')}
              aria-label="settings"
            >
              <SettingsIcon />
            </IconButton>
            <IconButton
              size={settings.compact ? 'small' : 'medium'}
              onClick={() => setRight('profile')}
              aria-label="profile"
            >
              <AccountCircleIcon />
            </IconButton>

            {isTop && (
              <>
                <Divider orientation="vertical" flexItem sx={{ mx: 1 }} />
                <Stack direction="row" alignItems="center" spacing={1}>
                  <ButtonBase
                    component="a"
                    href="https://www.linkedin.com/company/6g-xr/"
                    target="_blank"
                    rel="noopener noreferrer"
                    focusRipple
                    sx={{ borderRadius: 1.5, p: 0.5 }}
                  >
                    <Box
                      component="img"
                      src={LinkedinImage}
                      alt="LinkedIn"
                      sx={{ width: 24, height: 'auto' }}
                    />
                  </ButtonBase>

                  <ButtonBase
                    component="a"
                    href="https://twitter.com/6GXR_eu"
                    target="_blank"
                    rel="noopener noreferrer"
                    focusRipple
                    sx={{ borderRadius: 1.5, p: 0.5 }}
                  >
                    <Box component="img" src={XImage} alt="X" sx={{ width: 24, height: 'auto' }} />
                  </ButtonBase>

                  <ButtonBase
                    component="a"
                    href="https://6g-xr.eu/"
                    target="_blank"
                    rel="noopener noreferrer"
                    focusRipple
                    sx={{ borderRadius: 2, p: 0.5 }}
                  >
                    <Box
                      component="img"
                      src={LogoImage}
                      alt="Company"
                      sx={{ width: 36, height: 'auto' }}
                    />
                  </ButtonBase>

                  <Tooltip
                    title="Logout"
                    componentsProps={{
                      tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
                      arrow: { sx: { color: '#292929ff' } },
                    }}
                    arrow
                  >
                    <IconButton
                      color="error"
                      size={settings.compact ? 'small' : 'medium'}
                      onClick={handleLogout}
                    >
                      <LogoutIcon />
                    </IconButton>
                  </Tooltip>
                </Stack>
              </>
            )}
          </Stack>
        </Toolbar>
      </AppBar>

      {/* Main */}
      <Box sx={{ flexGrow: 1, order: 1, height: '100vh', overflow: 'hidden' }}>
        <Toolbar />
        <Main
          dir={settings.rtl ? 'rtl' : 'ltr'}
          style={settings.rtl ? { marginRight: 280 } : {}}
          sx={{
            height: 'calc(100vh - 164px)',
            overflow: 'auto',
          }}
        >
          {isTop && <TopNav />}
          {children ?? <Outlet />}
        </Main>
      </Box>

      <RightDrawer open={right === 'settings'} onClose={() => setRight(null)} title="Settings">
        <SettingsPanel />
      </RightDrawer>

      <RightDrawer open={right === 'profile'} onClose={() => setRight(null)} title="Profile">
        <ProfilePanel onClose={() => setRight(null)} />
      </RightDrawer>
    </Box>
  );
}

function TopNav() {
  const theme = useTheme();
  const { pathname } = useLocation();
  const { settings } = useUiSettings();
  const isLight = theme.palette.mode === 'light';

  const value = Math.max(
    0,
    NAV_ITEMS.findIndex((i) => pathname.startsWith(i.to))
  );

  return (
    <Paper
      variant="outlined"
      sx={{
        mb: 2,
        borderRadius: 2,
        position: 'sticky',
        top: -40,
        zIndex: 1100,
        px: 1,
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${
          isLight ? 0.72 : 0.5
        })`,

        backdropFilter: 'saturate(120%) blur(8px)',
      }}
    >
      <Tabs
        value={value}
        variant="scrollable"
        allowScrollButtonsMobile
        TabIndicatorProps={{ sx: { height: 3, borderRadius: 3 } }}
        sx={{
          minHeight: 48,
          '& .MuiTabs-flexContainer': { justifyContent: 'center' },
          '& .MuiTab-root': {
            minHeight: 48,
            textTransform: 'none',
            fontWeight: 700,
            alignItems: 'center',
            gap: 1,
          },
          '& .MuiTab-root.Mui-selected': {
            color: 'primary.main',
          },
        }}
      >
        {NAV_ITEMS.map((item, idx) => (
          <Tab
            key={item.to}
            icon={item.icon}
            iconPosition="start"
            label={item.label}
            component={RouterLink}
            to={item.to}
          />
        ))}
      </Tabs>
    </Paper>
  );
}

/* ---------- BrandHeader ---------- */
function BrandHeader({ collapsed }: { collapsed: boolean }) {
  const theme = useTheme();
  const { settings } = useUiSettings();
  const isRailLayout = settings.navLayout === 'rail';
  const mode = theme.palette.mode;

  const logoLight = '/logo22.png';

  const showTitle = !collapsed && !isRailLayout;
  const logoSize = isRailLayout ? 48 : collapsed ? 32 : 148;

  const [imgErr, setImgErr] = React.useState(false);

  return (
    <Box
      sx={{
        px: 2,
        py: 2,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 1.25,
        justifyContent: 'center',
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / 0.72)`,
        backdropFilter: 'saturate(120%) blur(8px)',
        minHeight: isRailLayout ? 72 : 'auto',
      }}
    >
      {!imgErr ? (
        <Box
          component="img"
          src={logoLight}
          alt="Company logo"
          sx={{ width: logoSize, height: 'auto', display: 'block' }}
        />
      ) : (
        <Box
          sx={{
            width: logoSize,
            height: logoSize,
            borderRadius: 2,
            fontWeight: 800,
            fontSize: isRailLayout ? 18 : 22,
            display: 'grid',
            placeItems: 'center',
            color: mode === 'dark' ? '#0B1220' : '#fff',
            backgroundImage: (t) =>
              `linear-gradient(135deg, rgba(${t.vars.palette.primary.mainChannel} / 0.95), rgba(${t.vars.palette.secondary.mainChannel} / 0.95))`,
          }}
        >
          UW
        </Box>
      )}

      {showTitle && (
        <Typography variant="subtitle2" color="text.secondary" fontWeight={800} noWrap>
          NORTH WEB PORTAL
        </Typography>
      )}
    </Box>
  );
}

import LinkedinImage from '../../../public/linkedin.png';
import XImage from '../../../public/x.png';
import LogoImage from '../../../public/logo22.png';
import axiosInstance from 'src/utils/axios';
import { STORAGE_KEY } from 'src/auth/context/jwt/constant';
import axios from 'axios';
/* ---------- Sidebar ---------- */

function Sidebar({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const theme = useTheme();
  const { settings, setNavLayout } = useUiSettings();
  const { pathname } = useLocation();
  const { showNotification } = useNotification();

  const isRTL = settings.rtl;
  const isRailLayout = settings.navLayout === 'rail';
  const showTextInline = !collapsed && !isRailLayout;
  const isActive = (to: string) => pathname.startsWith(to);

  const toggleLayoutMode = () => setNavLayout(isRailLayout ? 'sidebar' : 'rail');
  const EdgeChevron = () => {
    if (isRailLayout)
      return isRTL ? <ChevronLeftIcon fontSize="small" /> : <ChevronRightIcon fontSize="small" />;

    return isRTL ? <ChevronRightIcon fontSize="small" /> : <ChevronLeftIcon fontSize="small" />;
  };

  return (
    <Box
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        position: 'relative',
        overflow: 'visible',
      }}
    >
      <Tooltip
        title={isRailLayout ? 'Switch to Sidebar' : 'Switch to Rail'}
        componentsProps={{
          tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
          arrow: { sx: { color: '#292929ff' } },
        }}
        arrow
      >
        <IconButton
          onClick={toggleLayoutMode}
          size="small"
          aria-label="toggle rail/sidebar"
          sx={{
            position: 'absolute',
            top: '50%',
            transform: `translateY(-50%) translateX(${isRTL ? '-80%' : '80%'})`,
            insetInlineEnd: 6,
            zIndex: 10,
            width: 28,
            height: 56,
            borderRadius: 12,
            border: '1px solid',
            borderColor: 'divider',
            backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${
              theme.palette.mode === 'light' ? 0.82 : 0.58
            })`,
            backdropFilter: 'saturate(120%) blur(6px)',
            boxShadow:
              theme.palette.mode === 'light'
                ? '0 6px 18px rgba(15,23,42,0.08)'
                : '0 8px 24px rgba(0,0,0,0.36)',
            '&:hover': {
              backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${
                theme.palette.mode === 'light' ? 0.12 : 0.2
              })`,
            },
          }}
        >
          <EdgeChevron />
        </IconButton>
      </Tooltip>

      <BrandHeader collapsed={collapsed} />
      <Divider />

      <List sx={{ flex: 1, py: 1.25 }}>
        {NAV_ITEMS.map((item) => {
          const active = isActive(item.to);

          if (isRailLayout) {
            return (
              <Box key={item.to}>
                <ListItemButton
                  component={RouterLink}
                  to={item.to}
                  onClick={onNavigate}
                  selected={active}
                  sx={{
                    my: 0.5,
                    mx: 1,
                    py: 1,
                    mr: collapsed ? 0 : isRTL ? 0 : 2,
                    ml: collapsed ? 0 : isRTL ? 2 : 0,
                    minHeight: 64,
                    borderRadius: 2,
                    position: 'relative',
                    justifyContent: 'center',
                    px: 1,
                    '&:hover': {
                      backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.palette.mode === 'light' ? 0.08 : 0.12})`,
                    },
                    '&.Mui-selected, &.Mui-selected:hover': {
                      backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.palette.mode === 'light' ? 0.14 : 0.22})`,
                      color: 'primary.main',
                      '& .MuiListItemIcon-root': { color: 'primary.main' },
                    },
                  }}
                >
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: 0.5,
                      width: '100%',
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 0,
                        color: 'text.secondary',
                        mb: 0.25,
                        justifyContent: 'center',
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    <Typography
                      variant="caption"
                      sx={{ fontWeight: 700, lineHeight: 1.1, textAlign: 'center' }}
                      noWrap
                    >
                      {item.label}
                    </Typography>
                  </Box>
                </ListItemButton>
              </Box>
            );
          }

          const btn = (
            <ListItemButton
              key={item.to}
              component={RouterLink}
              to={item.to}
              onClick={onNavigate}
              selected={active}
              sx={{
                my: 0.5,
                mx: 1,
                mr: collapsed ? 0 : isRTL ? 0 : 2,
                ml: collapsed ? 0 : isRTL ? 2 : 0,
                minHeight: 44,
                borderRadius: 2,
                position: 'relative',
                justifyContent: collapsed ? 'center' : isRTL ? 'flex-end' : 'flex-start',
                px: collapsed ? 1 : 2,
                gap: collapsed ? 0 : 1.5,
                '&:hover': {
                  backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.palette.mode === 'light' ? 0.08 : 0.12})`,
                },
                '&.Mui-selected, &.Mui-selected:hover': {
                  backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${theme.palette.mode === 'light' ? 0.14 : 0.22})`,
                  color: 'primary.main',
                  '& .MuiListItemIcon-root': { color: 'primary.main' },
                },
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  color: 'text.secondary',
                  ...(isRTL ? { ml: collapsed ? 0 : 2 } : { mr: collapsed ? 0 : 2 }),
                  justifyContent: 'center',
                }}
              >
                {item.icon}
              </ListItemIcon>

              {showTextInline && (
                <ListItemText
                  primary={item.label}
                  primaryTypographyProps={{ fontWeight: 600 }}
                  sx={{ m: 0 }}
                />
              )}
            </ListItemButton>
          );

          return (
            <Box key={item.to}>
              {collapsed ? (
                <Tooltip title={item.label} placement="right">
                  <span>{btn}</span>
                </Tooltip>
              ) : (
                btn
              )}
            </Box>
          );
        })}
      </List>

      {!collapsed ? (
        <Box display="flex" alignItems="center" justifyContent="space-evenly" my={4}>
          <Tooltip
            title="LinkedIn"
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <ButtonBase
              component="a"
              href="https://www.linkedin.com/company/6g-xr/"
              target="_blank"
              rel="noopener noreferrer"
              onClick={onNavigate}
              focusRipple
              sx={{
                borderRadius: 1.5,
                p: 0.5,
                '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
              }}
            >
              <Box
                component="img"
                src={LinkedinImage}
                alt="LinkedIn"
                sx={{ width: 25, height: 'auto', display: 'block' }}
              />
            </ButtonBase>
          </Tooltip>

          <Tooltip
            title="X (Twitter)"
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <ButtonBase
              component="a"
              href="https://twitter.com/6GXR_eu"
              target="_blank"
              rel="noopener noreferrer"
              focusRipple
              sx={{
                borderRadius: 1.5,
                p: 0.5,
                '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
              }}
            >
              <Box
                component="img"
                src={XImage}
                alt="X (Twitter)"
                sx={{ width: 25, height: 'auto', display: 'block' }}
              />
            </ButtonBase>
          </Tooltip>

          <Tooltip
            title="6g-xr Home"
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <ButtonBase
              component="a"
              href="https://6g-xr.eu/"
              target="_blank"
              rel="noopener noreferrer"
              onClick={onNavigate}
              focusRipple
              sx={{
                borderRadius: 2,
                p: 0.5,
                '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
              }}
            >
              <Box
                component="img"
                src={LogoImage}
                alt="Company"
                sx={{ width: 50, height: 'auto', display: 'block' }}
              />
            </ButtonBase>
          </Tooltip>
        </Box>
      ) : (
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent="space-evenly"
          gap={4}
          my={3}
        >
          <ButtonBase
            component="a"
            href="https://www.linkedin.com/company/6g-xr/"
            target="_blank"
            rel="noopener noreferrer"
            onClick={onNavigate}
            focusRipple
            sx={{
              borderRadius: 1.5,
              p: 0.5,
              '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
            }}
          >
            <Box
              component="img"
              src={LinkedinImage}
              alt="LinkedIn"
              sx={{ width: 25, height: 'auto', display: 'block' }}
            />
          </ButtonBase>

          <ButtonBase
            component="a"
            href="https://twitter.com/6GXR_eu"
            target="_blank"
            rel="noopener noreferrer"
            focusRipple
            sx={{
              borderRadius: 1.5,
              p: 0.5,
              '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
            }}
          >
            <Box
              component="img"
              src={XImage}
              alt="X (Twitter)"
              sx={{ width: 25, height: 'auto', display: 'block' }}
            />
          </ButtonBase>

          <ButtonBase
            component="a"
            href="https://6g-xr.eu/"
            target="_blank"
            rel="noopener noreferrer"
            onClick={onNavigate}
            focusRipple
            sx={{
              borderRadius: 2,
              p: 0.5,
              '&:focus-visible': { outline: '2px solid', outlineColor: 'primary.main' },
            }}
          >
            <Box
              component="img"
              src={LogoImage}
              alt="Company"
              sx={{ width: 50, height: 'auto', display: 'block' }}
            />
          </ButtonBase>
        </Box>
      )}

      <Divider orientation="vertical" flexItem sx={{ mx: 0.5 }} />

      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          p: 2,
          backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / 0.6)`,
          borderTop: '1px solid',
          borderColor: 'divider',
        }}
      >
        {collapsed ? (
          <Tooltip
            title="Logout"
            placement={isRTL ? 'left' : 'right'}
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <IconButton
              color="error"
              component={RouterLink}
              to="#"
              size={settings.compact ? 'small' : 'medium'}
              onClick={() => {
                showNotification('Logged out successfully', 'info');
                setTimeout(() => {
                  sessionStorage.removeItem('accessToken');
                  sessionStorage.removeItem('accessToken.refresh');
                  sessionStorage.removeItem('userId');
                  window.location.reload();
                }, 2000);
              }}
            >
              <LogoutIcon />
            </IconButton>
          </Tooltip>
        ) : (
          <Button
            fullWidth
            variant="outlined"
            color="error"
            startIcon={
              <LogoutIcon
                style={{
                  marginLeft: settings.rtl ? 10 : 0,
                }}
              />
            }
            component={RouterLink}
            to="#"
            size={settings.compact ? 'small' : 'medium'}
            onClick={() => {
              showNotification('Logged out successfully', 'info');
              setTimeout(() => {
                sessionStorage.removeItem('accessToken');
                sessionStorage.removeItem('accessToken.refresh');
                sessionStorage.removeItem('userId');
                window.location.reload();
              }, 2000);
            }}
          >
            Logout
          </Button>
        )}
      </Box>
    </Box>
  );
}

function RightDrawer({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: React.ReactNode;
  children: React.ReactNode;
}) {
  const { settings } = useUiSettings();
  const anchor: 'left' | 'right' = settings.rtl ? 'left' : 'right';

  return (
    <Drawer
      anchor={anchor}
      open={open}
      onClose={onClose}
      ModalProps={{
        BackdropProps: {
          sx: {
            backgroundColor: 'rgba(255,255,255,0.02)',
            backdropFilter: 'blur(10px) saturate(120%)',
            WebkitBackdropFilter: 'blur(10px) saturate(120%)',
          },
        },
      }}
      PaperProps={{
        sx: (t) => ({
          width: { xs: '100%', sm: 420 },
          p: 2,
          boxSizing: 'border-box',
          flexShrink: 0,

          ...(anchor === 'right' ? { borderLeft: '1px solid' } : { borderRight: '1px solid' }),
          borderColor: 'divider',

          backgroundColor: `rgba(${t.vars.palette.background.paperChannel} / ${
            t.palette.mode === 'light' ? 0.32 : 0.24
          })`,
          backdropFilter: 'saturate(130%) blur(10px)',
          WebkitBackdropFilter: 'saturate(130%) blur(10px)',
          boxShadow: 'none',
        }),
      }}
    >
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}>
        <Typography variant="h6" fontWeight={700}>
          {title}
        </Typography>
        <IconButton onClick={onClose}>
          <MenuIcon sx={{ transform: 'rotate(90deg)' }} />
        </IconButton>
      </Stack>
      <Divider sx={{ mb: 2 }} />
      {children}
    </Drawer>
  );
}

export default function SettingsPanel() {
  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';

  const { settings, toggleRtl, toggleCompact, setNavLayout, setNavColor } = useUiSettings();
  const { mode, toggle, set } = useThemeMode();

  const GlassCard: React.FC<React.PropsWithChildren<{ title: string; sub?: string }>> = ({
    title,
    sub,
    children,
  }) => (
    <Card
      variant="outlined"
      sx={{
        borderRadius: 3,
        borderColor: 'divider',
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.72 : 0.5})`,
        backdropFilter: 'saturate(120%) blur(8px)',
        boxShadow: isLight ? '0 6px 24px rgba(15,23,42,0.06)' : '0 12px 32px rgba(0,0,0,0.35)',
      }}
    >
      <CardHeader
        titleTypographyProps={{ variant: 'subtitle1', fontWeight: 800 }}
        subheaderTypographyProps={{ variant: 'body2', color: 'text.secondary' }}
        title={title}
        subheader={sub}
        sx={{ pb: 0.5, '& .MuiCardHeader-content': { minWidth: 0 } }}
      />
      <CardContent sx={{ pt: 1.5 }}>{children}</CardContent>
    </Card>
  );

  return (
    <Stack spacing={2}>
      <GlassCard title="Appearance" sub="Theme & density">
        <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={2}>
          <Box>
            <Typography variant="body2" color="text.secondary">
              Theme mode
            </Typography>
            <Stack direction="row" alignItems="center" spacing={1} sx={{ mt: 0.5 }}>
              <ToggleButtonGroup
                size="small"
                exclusive
                value={mode}
                onChange={(_, v) => v && set(v)}
                sx={{ '& .MuiToggleButton-root': { px: 1.25, borderRadius: 2 } }}
              >
                <ToggleButton value="light">
                  <LightModeIcon fontSize="small" />
                </ToggleButton>
                <ToggleButton value="dark">
                  <DarkModeIcon fontSize="small" />
                </ToggleButton>
              </ToggleButtonGroup>
              <Tooltip title="Quick toggle">
                <Chip
                  size="small"
                  variant="outlined"
                  label={mode === 'light' ? 'Light' : 'Dark'}
                  onClick={toggle}
                />
              </Tooltip>
            </Stack>
          </Box>

          <Divider flexItem orientation="vertical" sx={{ mx: 1 }} />

          <Box>
            <Typography variant="body2" color="text.secondary">
              Density
            </Typography>
            <FormControlLabel
              sx={{ m: 0, mt: 0.5 }}
              control={<Switch checked={settings.compact} onChange={toggleCompact} />}
              label={settings.compact ? 'Compact' : 'Comfortable'}
            />
          </Box>
        </Stack>
      </GlassCard>

      <GlassCard title="Behavior" sub="Layout direction & basics">
        <FormControlLabel
          control={<Switch checked={settings.rtl} onChange={toggleRtl} />}
          label="Right-to-left (RTL)"
        />
      </GlassCard>

      <GlassCard title="Navigation" sub="Layout & style of the nav">
        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          Layout
        </Typography>
        <ToggleButtonGroup
          exclusive
          size="small"
          value={settings.navLayout}
          onChange={(_, v) => v && setNavLayout(v)}
          sx={{ '& .MuiToggleButton-root': { borderRadius: 2, px: 1.25, gap: 0.5 } }}
        >
          <ToggleButton value="rail">
            <SpaceDashboardOutlinedIcon fontSize="small" />
            Rail
          </ToggleButton>
          <ToggleButton value="sidebar">
            <ViewSidebarOutlinedIcon fontSize="small" />
            Sidebar
          </ToggleButton>
          <ToggleButton value="top">
            <HorizontalSplitOutlinedIcon fontSize="small" />
            Top
          </ToggleButton>
        </ToggleButtonGroup>

        <Divider sx={{ my: 2 }} />

        <Typography variant="subtitle2" sx={{ mb: 1 }}>
          Color
        </Typography>
        <ToggleButtonGroup
          exclusive
          size="small"
          value={settings.navColor}
          onChange={(_, v) => v && setNavColor(v)}
          sx={{ '& .MuiToggleButton-root': { borderRadius: 2, px: 1.25, gap: 0.5 } }}
        >
          <ToggleButton value="integrate">
            <BlurOnOutlinedIcon fontSize="small" />
            Integrate
          </ToggleButton>
          <ToggleButton value="apparent">
            <LayersOutlinedIcon fontSize="small" />
            Apparent
          </ToggleButton>
        </ToggleButtonGroup>
      </GlassCard>
    </Stack>
  );
}

function ProfilePanel({ onClose }: { onClose: () => void }) {
  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';
  const { settings } = useUiSettings();
  const [user, setUser] = React.useState({
    username: '',
    first_name: '',
    last_name: '',
    email: '',
  });

  const token = sessionStorage.getItem(STORAGE_KEY);

  React.useEffect(() => {
    profileUnified();
  }, []);

  const profileUnified = async () => {
    const res = await axios.post('http://193.166.32.46:8000/users/api/users/profile/', {
      token: token,
    });

    // const res = await axios.post('http://127.0.0.1:8000/users/api/users/profile/', {
    //   token: token,
    // });

    if (res) {
      setUser(res.data);
    }
  };

  const name = user?.username || 'User';
  const email = user?.email || '-';
  const role = (user as any)?.role || 'Member';
  const full_name = (user?.first_name || '') + ' ' + (user?.last_name || '');

  const [copied, setCopied] = React.useState(false);
  const copy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {}
  };
  const navigate = useNavigate();

  return (
    <Stack spacing={2}>
      <Paper
        variant="outlined"
        sx={(t) => ({
          p: 2,
          borderRadius: 3,
          borderColor: 'divider',
          backgroundColor: `rgba(${t.vars.palette.background.paperChannel} / ${
            t.palette.mode === 'light' ? 0.32 : 0.24
          })`,
          backdropFilter: 'saturate(130%) blur(10px)',
          WebkitBackdropFilter: 'saturate(130%) blur(10px)',
          boxShadow: 'none',
        })}
      >
        <Stack direction="row" spacing={2} alignItems="center">
          <Avatar
            sx={(t) => ({
              width: 56,
              height: 56,
              fontWeight: 800,
              color: isLight ? '#fff' : '#0B1220',
              backgroundImage: `linear-gradient(135deg, rgba(${t.vars.palette.primary.mainChannel} / 0.95), rgba(${t.vars.palette.secondary.mainChannel} / 0.95))`,
            })}
          >
            {name?.[0]?.toUpperCase() || 'U'}
          </Avatar>

          <Box sx={{ minWidth: 0 }}>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.25 }}>
              <Typography fontWeight={800} noWrap>
                {name}
              </Typography>
              <Chip size="small" label={role} sx={{ height: 22 }} />
            </Stack>

            <Stack direction="row" spacing={0.5} alignItems="center">
              <Typography variant="body2" color="text.secondary" noWrap title={email}>
                {email}
              </Typography>
              {email !== '-' && (
                <Tooltip title={copied ? 'Copied!' : 'Copy'}>
                  <IconButton size="small" onClick={() => copy(email)}>
                    {copied ? (
                      <CheckCircleIcon fontSize="inherit" />
                    ) : (
                      <ContentCopyIcon fontSize="inherit" />
                    )}
                  </IconButton>
                </Tooltip>
              )}
            </Stack>

            {full_name.trim() && (
              <Stack direction="row" spacing={0.5} alignItems="center">
                <Typography variant="body2" color="text.secondary" noWrap title={full_name}>
                  {full_name}
                </Typography>
              </Stack>
            )}
          </Box>
        </Stack>
      </Paper>

      <Stack direction="row" spacing={1}>
        <Button
          variant="outlined"
          color="primary"
          size={settings.compact ? 'small' : 'medium'}
          sx={{ borderRadius: 2, fontWeight: 700 }}
          fullWidth
          onClick={() => {
            navigate(paths.dashboard.profile);
            onClose();
          }}
        >
          View full profile
        </Button>
      </Stack>

      <Divider />
    </Stack>
  );
}
