import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import LinearProgress from '@mui/material/LinearProgress';
import { LoadingButton } from '@mui/lab';

type Props = {
  title: React.ReactNode;
  content?: React.ReactNode;
  open: boolean;
  onClose: VoidFunction;
  onConfirm: () => void | Promise<void>;
  loading?: boolean;
  confirmText?: string;
  cancelText?: string;
};

export default function ConfirmDialog({
  title,
  content,
  open,
  onClose,
  onConfirm,
  loading = false,
  confirmText = 'Delete',
  cancelText = 'Cancel',
}: Props) {
  return (
    <Dialog
      fullWidth
      maxWidth="xs"
      open={open}
      onClose={loading ? undefined : onClose}
      disableEscapeKeyDown={loading}
    >
      <DialogTitle>{title}</DialogTitle>

      {content && (
        <DialogContent sx={{ typography: 'body2' }}>
          {content}
        </DialogContent>
      )}

      {loading && <LinearProgress />}

      <DialogActions>
        <Button
          variant="outlined"
          color="inherit"
          onClick={onClose}
          disabled={loading}
        >
          {cancelText}
        </Button>

        <LoadingButton
          variant="contained"
          color="error"
          onClick={onConfirm}
          loading={loading}
          disabled={loading}
        >
          {confirmText}
        </LoadingButton>
      </DialogActions>
    </Dialog>
  );
}
