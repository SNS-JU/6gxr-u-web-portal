import * as React from 'react';
import {
  Box,
  Stack,
  Typography,
  Slider,
  ToggleButton,
  ToggleButtonGroup,
  FormControlLabel,
  Switch,
  IconButton,
  Divider,
} from '@mui/material';
import ViewModuleIcon from '@mui/icons-material/ViewModule';
import ViewListIcon from '@mui/icons-material/ViewList';
import ViewQuiltIcon from '@mui/icons-material/ViewQuilt';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import { useLayoutStyle } from 'src/context/layout-style';

export default function LayoutStyleControls() {
  const { style, setStyle } = useLayoutStyle();

  return (
    <Stack spacing={2} sx={{ width: '100%' }}>
      <Box>
        <Typography variant="subtitle2" gutterBottom>
          Layout mode
        </Typography>
        <ToggleButtonGroup
          exclusive
          size="small"
          value={style.mode}
          onChange={(_, v) => v && setStyle((s) => ({ ...s, mode: v }))}
        >
          <ToggleButton value="grid">
            <ViewModuleIcon fontSize="small" />
            &nbsp;Grid
          </ToggleButton>
          <ToggleButton value="list">
            <ViewListIcon fontSize="small" />
            &nbsp;List
          </ToggleButton>
          <ToggleButton value="masonry">
            <ViewQuiltIcon fontSize="small" />
            &nbsp;Masonry
          </ToggleButton>
        </ToggleButtonGroup>
      </Box>

      {style.mode !== 'list' && (
        <Box>
          <Typography variant="subtitle2" gutterBottom>
            Columns: {style.columns}
          </Typography>
          <Stack direction="row" spacing={1} alignItems="center">
            <IconButton
              size="small"
              onClick={() => setStyle((s) => ({ ...s, columns: Math.max(1, s.columns - 1) }))}
            >
              <RemoveIcon fontSize="small" />
            </IconButton>
            <Slider
              value={style.columns}
              min={1}
              max={8}
              step={1}
              onChange={(_, v) => setStyle((s) => ({ ...s, columns: v as number }))}
              sx={{ mx: 1 }}
            />
            <IconButton
              size="small"
              onClick={() => setStyle((s) => ({ ...s, columns: Math.min(8, s.columns + 1) }))}
            >
              <AddIcon fontSize="small" />
            </IconButton>
          </Stack>
        </Box>
      )}

      <Box>
        <Typography variant="subtitle2" gutterBottom>
          Gap (spacing): {style.gap}
        </Typography>
        <Slider
          value={style.gap}
          min={0}
          max={6}
          step={1}
          onChange={(_, v) => setStyle((s) => ({ ...s, gap: v as number }))}
        />
      </Box>

      <Box>
        <Typography variant="subtitle2" gutterBottom>
          Card radius: {style.radius}px
        </Typography>
        <Slider
          value={style.radius}
          min={0}
          max={24}
          step={2}
          onChange={(_, v) => setStyle((s) => ({ ...s, radius: v as number }))}
        />
      </Box>

      <Divider />
      <FormControlLabel
        control={
          <Switch
            checked={style.dense}
            onChange={(e) => setStyle((s) => ({ ...s, dense: e.target.checked }))}
          />
        }
        label={style.dense ? 'Compact density' : 'Comfortable density'}
      />
    </Stack>
  );
}
