// src/components/loading-screen.tsx

import Box from '@mui/material/Box';
import LinearProgress from '@mui/material/LinearProgress';

// ======================================================================

export default function LoadingScreen() {
  return (
    <Box
      sx={{
        position: 'fixed',
        width: 1,
        height: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Box sx={{ width: '50%', maxWidth: 360 }}>
        <LinearProgress />
      </Box>
    </Box>
  );
}