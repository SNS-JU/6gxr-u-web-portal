// src/auth/guard/auth-guard.tsx
import React, { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthContext } from '../hooks/use-auth-context';
import LoadingScreen from 'src/components/loading/loading-screen';
import { paths } from 'src/routes/paths';
import { STORAGE_KEY } from 'src/auth/context/jwt/constant';

type AuthGuardProps = { children: React.ReactNode };

function getStoredToken(): string | null {
  const key = STORAGE_KEY || 'accessToken';
  return (
    sessionStorage.getItem(key) ??
    localStorage.getItem(key) ??
    localStorage.getItem('accessToken') ??
    sessionStorage.getItem('accessToken') ??
    localStorage.getItem('token') ??
    sessionStorage.getItem('token')
  );
}

export default function AuthGuard({ children }: AuthGuardProps) {
  const { isAuthenticated, isInitialized } = useAuthContext();
  const { pathname } = useLocation();

  const [requestedLocation, setRequestedLocation] = useState<string | null>(null);

  useEffect(() => {
    if (!requestedLocation) setRequestedLocation(pathname);
  }, [pathname, requestedLocation]);

  const SIGN_IN = (paths as any)?.signIn || (paths as any)?.auth?.signIn || '/login';

  if (!isInitialized) return <LoadingScreen />;

  if (isAuthenticated) {
    if (requestedLocation && pathname !== requestedLocation) {
      const to = requestedLocation;
      setRequestedLocation(null);
      return <Navigate to={to} replace />;
    }
    return <>{children}</>;
  }

  const token = getStoredToken();
  if (token) {
    return <>{children}</>;
  }

  return <Navigate to={SIGN_IN} replace state={{ from: requestedLocation || pathname }} />;
}
