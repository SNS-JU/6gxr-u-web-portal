export type User = {
  id: string;
  name: string;
  email: string;
  // Add other user properties here
};

export type AuthState = {
  isAuthenticated: boolean;
  isInitialized: boolean;
  user: User | null;
};

export type AuthContextType = AuthState & {
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
};