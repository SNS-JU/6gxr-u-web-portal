export const STORAGE_KEY = 'accessToken';
