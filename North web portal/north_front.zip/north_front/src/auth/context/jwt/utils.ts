import axios from 'axios';
import { STORAGE_KEY } from './constant';

export const signInWithPassword = async ({ username, password }: Record<string, string>) => {
  const tokenRes = await axios.post('http://193.166.32.46:8080/users/api/token/', {
    username,
    password,
  });
  // const tokenRes = await axios.post('http://127.0.0.1:8001/users/api/token/', {
  //   username,
  //   password,
  // });
  const access = tokenRes.data?.access ?? tokenRes.data?.accessToken;
  const refresh = tokenRes.data?.refresh ?? tokenRes.data?.refreshToken;

  if (!access) {
    throw new Error('Token missing in response');
  }

  sessionStorage.setItem(STORAGE_KEY, access);
  if (refresh) sessionStorage.setItem(`${STORAGE_KEY}.refresh`, refresh);

  const profileRes = await axios.post('http://193.166.32.46:8000/users/api/users/profile/', {
    token: access,
  });
  // const profileRes = await axios.post('http://127.0.0.1:8000/users/api/users/profile/', {
  //   token: access,
  // });
  const user = profileRes.data;

  if (!user || !user.id) {
    throw new Error('Profile response is invalid');
  }

  sessionStorage.setItem('userId', user.id);
  return user;
};

export const signUp = async (data: Record<string, string>) => {
  const response = await axios.post('/api/auth/register', data);
  return response.data;
};
