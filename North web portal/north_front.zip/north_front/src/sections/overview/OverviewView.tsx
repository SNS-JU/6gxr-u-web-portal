// @ts-nocheck
import { useMemo } from 'react';
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Typography,
  Stack,
  Chip,
  Avatar,
  Divider,
  Button,
  useTheme,
} from '@mui/material';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import EventIcon from '@mui/icons-material/Event';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import PendingIcon from '@mui/icons-material/Pending';
import ReactApexChart from 'react-apexcharts';
import { useUiSettings } from 'src/context/ui-settings';
import Grid from '@mui/material/Grid';

type RecentItem = {
  id: number | string;
  name: string;
  start: string;
  end: string;
  facility?: string;
  status: 'running' | 'done' | 'pending';
};

export default function OverviewView() {
  const theme = useTheme();
  const { settings } = useUiSettings();

  const kpis = {
    total: 24,
    running: 8,
    done: 12,
    pending: 4,
    delta: +12,
  };

  const recent: RecentItem[] = [
    {
      id: 101,
      name: 'Oulu Outdoor',
      start: '2025-08-10 09:00',
      end: '2025-08-12 18:00',
      facility: 'Oulu',
      status: 'running',
    },
    {
      id: 102,
      name: '5G SA Core',
      start: '2025-08-08 08:00',
      end: '2025-08-09 20:00',
      facility: 'Oulu',
      status: 'done',
    },
    {
      id: 103,
      name: 'mmWave Test',
      start: '2025-08-12 10:00',
      end: '2025-08-13 16:00',
      facility: 'Oulu',
      status: 'pending',
    },
  ];

  // ---- Chart configs
  const areaSeries = useMemo(
    () => [{ name: 'Trials', data: [2, 3, 4, 6, 8, 7, 9, 12, 10, 11, 13, 15] }],
    []
  );

  const areaOptions: ApexCharts.ApexOptions = useMemo(
    () => ({
      chart: { type: 'area', toolbar: { show: false }, height: 280, sparkline: { enabled: false } },
      stroke: { width: 2, curve: 'smooth' },
      dataLabels: { enabled: false },
      markers: { size: 0 },
      colors: [theme.palette.primary.main],
      xaxis: {
        categories: [
          'Jan',
          'Feb',
          'Mar',
          'Apr',
          'May',
          'Jun',
          'Jul',
          'Aug',
          'Sep',
          'Oct',
          'Nov',
          'Dec',
        ],
        labels: { style: { colors: theme.palette.text.secondary } },
      },
      yaxis: { labels: { style: { colors: theme.palette.text.secondary } } },
      grid: { borderColor: theme.palette.divider },
      fill: {
        type: 'gradient',
        gradient: { shadeIntensity: 0.3, opacityFrom: 0.4, opacityTo: 0.05 },
      },
      tooltip: { theme: 'light' },
    }),
    [theme]
  );

  const donutSeries = useMemo(() => [kpis.running, kpis.done, kpis.pending], [kpis]);
  const donutOptions: ApexCharts.ApexOptions = useMemo(
    () => ({
      chart: { type: 'donut' },
      labels: ['Running', 'Done', 'Pending'],
      legend: { position: 'bottom' },
      colors: [theme.palette.info.main, theme.palette.success.main, theme.palette.warning.main],
      dataLabels: { enabled: false },
      stroke: { colors: [theme.palette.background.paper] },
    }),
    [theme]
  );

  const sizeProp = settings.compact ? 'small' : undefined;

  return (
    <Box>
      {/* KPI cards */}
      <Grid container spacing={settings.compact ? 2 : 3}>
        <Grid item xs={12} md={3}>
          <StatCard
            title="Total Trials"
            value={kpis.total}
            icon={<EventIcon />}
            help={`${kpis.delta > 0 ? '+' : ''}${kpis.delta}% vs last period`}
            color="primary"
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard
            title="Running"
            value={kpis.running}
            icon={<TrendingUpIcon />}
            chip="Live"
            chipColor="info"
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard
            title="Completed"
            value={kpis.done}
            icon={<DoneAllIcon />}
            chip="Done"
            chipColor="success"
          />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard
            title="Pending"
            value={kpis.pending}
            icon={<PendingIcon />}
            chip="Pending"
            chipColor="warning"
          />
        </Grid>
      </Grid>

      {/* Charts */}
      <Grid container spacing={settings.compact ? 2 : 3} sx={{ mt: settings.compact ? 2 : 3 }}>
        <Grid item xs={12} md={8}>
          <Card>
            <CardHeader title="Trials over time" />
            <CardContent>
              <ReactApexChart type="area" height={280} series={areaSeries} options={areaOptions} />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={4}>
          <Card>
            <CardHeader title="Status distribution" />
            <CardContent>
              <ReactApexChart
                type="donut"
                height={280}
                series={donutSeries}
                options={donutOptions}
              />
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      {/* Recent list */}
      <Grid container spacing={settings.compact ? 2 : 3} sx={{ mt: settings.compact ? 2 : 3 }}>
        <Grid item xs={12}>
          <Card>
            <CardHeader
              title="Recent experiments"
              action={
                <Button size={sizeProp} variant="contained">
                  View all
                </Button>
              }
            />
            <CardContent>
              <Stack divider={<Divider flexItem />} spacing={1}>
                {recent.map((r) => (
                  <Stack
                    key={r.id}
                    direction="row"
                    alignItems="center"
                    justifyContent="space-between"
                    sx={{ py: 1 }}
                  >
                    <Stack direction="row" spacing={2} alignItems="center">
                      <Avatar sx={{ width: 36, height: 36 }}>
                        {String(r.name).charAt(0).toUpperCase()}
                      </Avatar>
                      <Box>
                        <Typography fontWeight={600}>{r.name}</Typography>
                        <Typography variant="caption" color="text.secondary">
                          {r.start} — {r.end} {r.facility ? `• ${r.facility}` : ''}
                        </Typography>
                      </Box>
                    </Stack>
                    <Chip
                      size={sizeProp}
                      label={r.status}
                      color={
                        r.status === 'running'
                          ? 'info'
                          : r.status === 'done'
                            ? 'success'
                            : 'warning'
                      }
                      variant="filled"
                    />
                  </Stack>
                ))}
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}

function StatCard({
  title,
  value,
  icon,
  help,
  chip,
  chipColor,
}: {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  help?: string;
  chip?: string;
  chipColor?: 'default' | 'primary' | 'secondary' | 'success' | 'info' | 'warning' | 'error';
}) {
  return (
    <Card>
      <CardContent>
        <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
          <Stack spacing={0.5}>
            <Typography variant="overline" color="text.secondary">
              {title}
            </Typography>
            <Typography variant="h4">{value}</Typography>
            {help && (
              <Typography variant="caption" color="text.secondary">
                {help}
              </Typography>
            )}
          </Stack>
          <Avatar sx={{ bgcolor: 'primary.main', color: 'primary.contrastText' }}>{icon}</Avatar>
        </Stack>
        {chip && (
          <Box sx={{ mt: 1.5 }}>
            <Chip label={chip} color={chipColor} size="small" />
          </Box>
        )}
      </CardContent>
    </Card>
  );
}
