// @ts-nocheck
/* eslint-disable */

import * as React from 'react';
import Lottie from 'lottie-react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';

import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { useTheme } from '@mui/material/styles';

import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';
// eslint-disable-next-line import/no-unresolved
import animationData from 'src/lotties/cam-login.json';
import { useNotification } from 'src/context/notification-context';

export default function SignUpPage() {
  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';

  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const [showPassword, setShowPassword] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [values, setValues] = React.useState({
    first_name: '',
    last_name: '',
    email: '',
    phone_number: '',
    username: '',
    password: '',
  });

  const onChange = (field: keyof typeof values) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setValues((s) => ({ ...s, [field]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!values.username || values.password.length < 6) {
      showNotification('Username & 6+ char password required', 'warning');
      return;
    }
    try {
      setLoading(true);
      await axiosInstance.post(ENDPOINTS.register, {
        first_name: values.first_name || undefined,
        last_name: values.last_name || undefined,
        email: values.email || undefined,
        phone_number: values.phone_number || undefined,
        username: values.username,
        password: values.password,
      });
      showNotification('Account created successfully', 'success');
      navigate('/login', { replace: true });
    } catch (err: any) {
      const msg =
        err?.response?.data?.detail || err?.response?.data?.message || 'Registration failed';
      showNotification(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  const leftLogoSrc = '/logo22.png';

  return (
    <>
      <Box
        sx={{
          position: 'fixed',
          top: { xs: 12, md: 16 },
          left: { xs: 12, md: 16 },
          zIndex: (t) => t.zIndex.appBar + 1,
        }}
      >
        <Box
          component={RouterLink}
          to="/"
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            px: 1.25,
            py: 0.75,
            borderRadius: 2,
            textDecoration: 'none',
            border: '1px solid',
            borderColor: 'divider',
            backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.7 : 0.5})`,
            backdropFilter: 'saturate(120%) blur(6px)',
            boxShadow: isLight ? '0 6px 18px rgba(15,23,42,0.08)' : '0 8px 24px rgba(0,0,0,0.36)',
          }}
        >
          <Box
            component="img"
            src={leftLogoSrc}
            alt="Company"
            sx={{ height: { xs: 24, md: 28 }, display: 'block' }}
          />
        </Box>
      </Box>
      <Box
        sx={{
          position: 'fixed',
          top: { xs: 12, md: 16 },
          right: { xs: 12, md: 16 },
          zIndex: (t) => t.zIndex.appBar + 1,
        }}
      >
        <Box
          component="a"
          href="https://6g-xr.eu/"
          target="_blank"
          rel="noopener"
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            px: 1.25,
            py: 0.75,
            borderRadius: 2,
            textDecoration: 'none',
            border: '1px solid',
            borderColor: 'divider',
            backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.7 : 0.5})`,
            backdropFilter: 'saturate(120%) blur(6px)',
            boxShadow: isLight ? '0 6px 18px rgba(15,23,42,0.08)' : '0 8px 24px rgba(0,0,0,0.36)',
          }}
        >
          <Box alt="Partner" sx={{ fontSize: 19, color: 'black', height: 28, display: 'block' }}>
            6G-XR Home Page
          </Box>
        </Box>
      </Box>

      <Grid display={'flex'} flexDirection={'row'} sx={{ minHeight: '100vh' }}>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            px: { xs: 3, md: 6 },
            background: (t) =>
              t.palette.mode === 'light'
                ? 'linear-gradient(180deg,#F4F7FF, #faf7f0)'
                : 'linear-gradient(180deg,#0B1220, #0E1526)',
          }}
        >
          <Box sx={{ width: '100%', maxWidth: 520 }}>
            <Typography variant="h3" fontWeight={700} gutterBottom>
              Welcome to Unified Portal
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
              Experiment Management and Analysis
            </Typography>
            <Box sx={{ mx: 'auto' }}>
              <Lottie animationData={animationData as any} loop style={{ maxWidth: 420 }} />
            </Box>
          </Box>
        </Grid>

        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: {
              xs: 'center',
              md: 'center',
            },
            minWidth: '70%',
            p: { xs: 3, md: 8 },
          }}
        >
          <Box
            component={Paper}
            elevation={0}
            sx={{
              p: { xs: 2, md: 4 },
              width: '100%',
              maxWidth: 560,
              border: '1px solid',
              borderColor: 'divider',
              borderRadius: 3,
            }}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="baseline"
              sx={{ mb: 2 }}
            >
              <Typography variant="h5" fontWeight={700}>
                Let’s Get Started
              </Typography>
              <Typography variant="body2">
                Already have an account?{' '}
                <Typography component={RouterLink} to="/login" sx={{ textDecoration: 'underline' }}>
                  Sign in
                </Typography>
              </Typography>
            </Stack>

            <Box component="form" noValidate onSubmit={onSubmit}>
              <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
                <TextField
                  label="First name"
                  fullWidth
                  value={values.first_name}
                  onChange={onChange('first_name')}
                />
                <TextField
                  label="Last name"
                  fullWidth
                  value={values.last_name}
                  onChange={onChange('last_name')}
                />
              </Stack>

              <TextField
                label="Email address"
                fullWidth
                margin="normal"
                value={values.email}
                onChange={onChange('email')}
              />
              <TextField
                label="phone number"
                fullWidth
                margin="normal"
                value={values.phone_number}
                onChange={onChange('phone_number')}
              />
              <TextField
                label="Username"
                fullWidth
                margin="normal"
                value={values.username}
                onChange={onChange('username')}
              />

              <TextField
                label="Password"
                fullWidth
                margin="normal"
                type={showPassword ? 'text' : 'password'}
                value={values.password}
                onChange={onChange('password')}
                helperText="6+ characters"
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowPassword((s) => !s)}
                        edge="end"
                        aria-label="toggle password"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />

              <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }} disabled={loading}>
                {loading ? 'Creating…' : 'Create account'}
              </Button>

              <Typography
                variant="caption"
                color="text.secondary"
                sx={{ mt: 1.5, display: 'block' }}
              >
                By signing up, I agree to{' '}
                <RouterLink to="/terms">Terms of service and Privacy policy</RouterLink>
              </Typography>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}
