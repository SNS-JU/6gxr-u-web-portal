/* eslint-disable */

import { useEffect, useState, useRef, memo } from 'react';
import axiosInstance from 'src/utils/axios';

type Props = { id: number };

function StatusTxImpl({ id }: Props) {
  const [realtimeMessage, setRealtimeMessage] = useState<string | null>(null);
  const [initialStatus, setInitialStatus] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const socketRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    let mounted = true;

    const fetchInitialStatus = async () => {
      try {
        const response = await axiosInstance.post(`/home/api/NstStatus/`, {
          nst_id: id,
          user: Number(sessionStorage.getItem('userId')),
        });
        if (mounted) setInitialStatus(response.data?.data ?? 'N/A');
      } catch (error) {
        console.error('Failed to fetch initial status', error);
        if (mounted) setInitialStatus('N/A');
      } finally {
        if (mounted) setLoading(false);
      }
    };

    fetchInitialStatus();

    const socket = new WebSocket('ws://193.166.32.46:6060/ws/status/');
    socketRef.current = socket;

    socket.onopen = () => {

    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const payload = data?.message;
        const payloadId = payload?.core_id ?? payload?.nst_id ?? payload?.id;

        if (payloadId === id) {
          setRealtimeMessage(payload?.state ?? null);
        }
      } catch (e) {
        console.warn('WS parse error', e);
      }
    };

    socket.onclose = () => {
    };

    return () => {
      mounted = false;
      if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
        socketRef.current.close();
      }
    };
  }, [id]);

  if (loading) return <span>loading...</span>;

  return <span>{realtimeMessage ?? initialStatus ?? 'N/A'}</span>;
}

const StatusTx = memo(StatusTxImpl);
export default StatusTx;
