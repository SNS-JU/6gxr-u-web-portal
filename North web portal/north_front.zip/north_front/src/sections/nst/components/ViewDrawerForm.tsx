/* eslint-disable */

import * as React from 'react';
import type { DrawerProps } from '@mui/material/Drawer';
import {
  Box,
  Stack,
  Drawer,
  Button,
  Tooltip,
  IconButton,
  Typography,
  Divider,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

import { Iconify } from 'src/components/iconify';
import { useFetch } from 'src/hooks/use-fetch';
import { useNotification } from 'src/context/notification-context';
import type { NstList } from 'src/types/nst-list';
import { paths } from 'src/routes/paths';
import axiosInstance from 'src/utils/axios';

type Props = DrawerProps & {
  onClose: () => void;
  item: NstList | null;
};

export default function ViewDrawerForm({ open, onClose, item, ...other }: Props) {
  const navigate = useNavigate();
  const { showNotification } = useNotification();

  // const { data: checkRun, refetch } = useFetch<{ running: number | null }>(
  //   '/home/api/checkrunning/'
  // );
  const [runningid,setRunningid]=React.useState()
  const  fetchrunning=async()=>{
    const data=await axiosInstance('/home/api/checkrunning/')
    if (data){
      console.log("DDDDDDDDD",data)
      setRunningid(data.data?.running)
    }


  } 
  React.useEffect(() => {
    if (open) fetchrunning();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const apps = (item as any)?.applications ?? [];
  const fields = item
    ? [
        { title: 'Experiment Name', value: item.name || 'N/A' },
        { title: 'Trial ID', value: String(item.trial_id ?? 'N/A') },
        { title: 'Start Time', value: item.start_date || 'N/A' },
        { title: 'End Time', value: item.end_date || 'N/A' },
        { title: 'Node', value: (item as any).targetNode || 'N/A' },
        { title: 'Facility', value: (item as any).targetFacility || 'N/A' },
        { title: 'App1', value: apps?.[0] ?? 'N/A' },
        { title: 'App2', value: apps?.[1] ?? 'N/A' },
        { title: 'Slice Option', value: (item as any).slice_option || 'N/A' },
        { title: 'Slice 1', value: (item as any).slice1_type || 'N/A' },
        { title: 'Slice 2', value: (item as any).slice2_type || 'N/A' },
      ]
    : [];

  const handleAnalyze = async () => {
    if (!item) return;

    if (!runningid) {
      showNotification('No running experiment found', 'warning');
      return;
    }

    const coreId = (item as any).core_id ?? (item as any).id ?? item.trial_id;
    if (String(runningid) !== String(coreId)) {
      showNotification('You are not allowed (different running experiment)', 'error');
      return;
    }

    navigate(paths.dashboard.analyzeNst, {
      state: { slice_id: Number(runningid) },
    });
  };

return (
  <Drawer
    open={open}
    onClose={onClose}
    anchor="right"
    ModalProps={{
      BackdropProps: {
        sx: {
          backgroundColor: 'rgba(255,255,255,0.02)',
          backdropFilter: 'blur(10px) saturate(120%)',
          WebkitBackdropFilter: 'blur(10px) saturate(120%)',
        },
      },
    }}
    PaperProps={{
      sx: (t) => ({
        width: 380,
        maxWidth: '100vw',
        boxSizing: 'border-box',
        flexShrink: 0,

        borderLeft: '1px solid',
        borderColor: 'divider',

        backgroundColor: `rgba(${t.vars.palette.background.paperChannel} / ${
          t.palette.mode === 'light' ? 0.32 : 0.24
        })`,
        backdropFilter: 'saturate(130%) blur(10px)',
        WebkitBackdropFilter: 'saturate(130%) blur(10px)',
        boxShadow: 'none',
      }),
    }}
    {...other}
  >
    <Stack
      direction="row"
      alignItems="center"
      justifyContent="space-between"
      sx={{ p: 2.5, borderBottom: '1px dashed' }}
      borderColor="divider"
    >
      <Typography variant="h6" fontWeight={800}>
        Experiment Info
      </Typography>
      <IconButton onClick={onClose}>
        <Iconify icon="mingcute:close-line" />
      </IconButton>
    </Stack>

    <Stack spacing={2} sx={{ p: 2.5 }}>
      {item ? (
        <>
          <Stack spacing={1.5} direction="row" useFlexGap flexWrap="wrap" alignItems="center">
            {fields.map((el) => (
              <Box key={el.title} sx={{ width: '48%' }}>
                <Typography variant="caption" sx={{ color: 'text.secondary' }}>
                  {el.title}
                </Typography>
                <Typography variant="body2" color="text.primary" noWrap title={String(el.value)}>
                  {String(el.value)}
                </Typography>
              </Box>
            ))}
          </Stack>

          <Divider sx={{ my: 1.5 }} />

          <Tooltip
            title="Go to the experiment analysis"
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow:   { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <Button onClick={handleAnalyze} fullWidth variant="contained" color="primary">
              Analyze Results
            </Button>
          </Tooltip>
        </>
      ) : (
        <Typography variant="body2" color="text.secondary">
          Select an experiment to preview details.
        </Typography>
      )}
    </Stack>
  </Drawer>
);
}
