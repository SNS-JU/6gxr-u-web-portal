/* eslint-disable */

import { useNavigate } from 'react-router-dom';
import { Box, Button, Typography } from '@mui/material';

type Props = {
  title: string;
  addRoute: string;
};

export default function HeaderListPages({ title, addRoute }: Props) {
  const navigate = useNavigate();
  const now_time = new Date();
  const uniEndStr = sessionStorage.getItem('uni_end');
  const uni_end_time = uniEndStr ? new Date(uniEndStr) : null;
  const isDisabled = uni_end_time ? now_time > uni_end_time : false;

  return (
    <Box
      display="flex"
      sx={{ flexDirection: { xs: 'column', md: 'row' }, gap: { xs: 2, md: 0 }, mb: 5 }}
      justifyContent="space-between"
      alignItems="center"
    >
      <Typography variant="h4">{title}</Typography>
      <Button variant="contained" color="primary" disabled={isDisabled} onClick={() => navigate(addRoute)}>
        Add New Experiment
      </Button>
    </Box>
  );
}