// @ts-nocheck
/* eslint-disable */

import * as React from 'react';
import { Controller, useForm } from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigate } from 'react-router-dom';
import dayjs, { Dayjs } from 'dayjs';

import {
  Container,
  Card,
  CardHeader,
  CardContent,
  TextField,
  MenuItem,
  Divider,
  Typography,
  Box,
  Stack,
  IconButton,
  InputAdornment,
  RadioGroup,
  FormControlLabel,
  Radio,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import EventIcon from '@mui/icons-material/Event';
import { LoadingButton } from '@mui/lab';

import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { MobileDatePicker } from '@mui/x-date-pickers/MobileDatePicker';
import { MobileTimePicker } from '@mui/x-date-pickers/MobileTimePicker';

import axiosInstance from 'src/utils/axios';
import { useNotification } from 'src/context/notification-context';
import { useUiSettings } from 'src/context/ui-settings';
import { paths } from 'src/routes/paths';
import { ENDPOINTS } from 'src/config';
import ClearIcon from '@mui/icons-material/Clear';


// ---------- Enums / Types ----------
const SLICE_OPTIONS_ENUM = {
  NoSlice: 'no_slice',
  OneSlice: 'one_slice',
  TwoSlice: 'two_slices',
} as const;
type SliceOption = (typeof SLICE_OPTIONS_ENUM)[keyof typeof SLICE_OPTIONS_ENUM];

const SLICE_TYPES = [
  { label: 'uRLLC', value: 'uRLLC' },
  { label: 'eMBB', value: 'eMBB' },
];

type FormValues = {
  name: string;
  start_date: Dayjs | null;
  end_date: Dayjs | null;
  targetNode: string;
  targetFacility: string;
  slice_option: SliceOption;
  slice1_type: string | null;
  slice2_type: string | null;
  Application_1?: string;
  Application_2?: string;
  description?: string;
};

type TrialItem = { trial_id: number | string; name: string };

const toApiLocalNoTZ = (d: Dayjs | null) =>
  d ? dayjs(d).format('YYYY-MM-DDTHH:mm:ss') + '.000000' : '';

const displayFmt = (d: Dayjs | null) => (d ? d.format('M/D/YYYY h:mm A') : '');

const clientTZ = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Helsinki';

// ---------- Validation ----------
const schema: yup.Schema<FormValues> = yup
  .object({
    name: yup.string().min(2).required('Name is required'),
    start_date: yup
      .mixed<Dayjs | null>()
      .required('Start time is required')
      .test('valid-start', 'Invalid start time', (v) => !!v && dayjs.isDayjs(v) && v.isValid()),
    end_date: yup
      .mixed<Dayjs | null>()
      .required('End time is required')
      .test('valid-end', 'Invalid end time', (v) => !!v && dayjs.isDayjs(v) && v.isValid())
      .test('after-start', 'End time must be after start time', function (val) {
        const s = this.parent.start_date as Dayjs | null;
        return !!val && !!s && dayjs(val).isAfter(s);
      }),
    targetNode: yup.string().required(),
    targetFacility: yup.string().required(),
    slice_option: yup.mixed<SliceOption>().oneOf(Object.values(SLICE_OPTIONS_ENUM)).required(),
    slice1_type: yup
      .string()
      .nullable()
      .when('slice_option', {
        is: (v: SliceOption) =>
          v === SLICE_OPTIONS_ENUM.OneSlice || v === SLICE_OPTIONS_ENUM.TwoSlice,
        then: (s) => s.required('Slice 1 is required'),
        otherwise: (s) => s.nullable(),
      }),
    slice2_type: yup
      .string()
      .nullable()
      .when('slice_option', {
        is: (v: SliceOption) => v === SLICE_OPTIONS_ENUM.TwoSlice,
        then: (s) => s.required('Slice 2 is required'),
        otherwise: (s) => s.nullable(),
      }),
    Application_1: yup.string().optional(),
    Application_2: yup.string().optional(),
    // description: yup.string().optional(),
  })
  .required();

// ---------- Two-step DateTime ----------
function TwoStepDateTimeField({
  label,
  value,
  onChange,
  size = 'medium',
  error,
  helperText,
  minDateTime,
  disablePast = false,
  sx,
}: {
  label: string;
  value: Dayjs | null;
  onChange: (v: Dayjs | null) => void;
  size?: 'small' | 'medium';
  error?: boolean;
  helperText?: React.ReactNode;
  minDateTime?: Dayjs | null;
  disablePast?: boolean;
  sx?: any;
}) {
  const [openDate, setOpenDate] = React.useState(false);
  const [openTime, setOpenTime] = React.useState(false);
  const [dateDraft, setDateDraft] = React.useState<Dayjs | null>(null);
  const [timeDraft, setTimeDraft] = React.useState<Dayjs | null>(null);
  const { settings } = useUiSettings();

  const maxDayjs = (...vals: Array<Dayjs | undefined>) => {
    const arr = vals.filter(Boolean) as Dayjs[];
    if (!arr.length) return undefined;
    return arr.reduce((a, b) => (a.isAfter(b) ? a : b));
  };

  const now = dayjs();
  const baseForLimits = dateDraft ?? value ?? null;

  const effectiveMinDate =
    maxDayjs(
      disablePast ? now.startOf('day') : undefined,
      minDateTime ? minDateTime.startOf('day') : undefined
    ) || undefined;

  const effectiveMinTime =
    baseForLimits &&
    maxDayjs(
      disablePast && baseForLimits.isSame(now, 'day') ? now : undefined,
      minDateTime && baseForLimits.isSame(minDateTime, 'day') ? minDateTime : undefined
    ) || undefined;

  const startFlow = () => {
    setDateDraft(value ?? dayjs());
    setOpenDate(true);
  };
  const acceptDate = () => {
    if (!dateDraft) return setOpenDate(false);
    setOpenDate(false);
    setOpenTime(true);
  };
  const acceptTime = () => {
    if (!dateDraft && !timeDraft) return setOpenTime(false);
    const baseDate = dateDraft ?? value ?? dayjs();
    const srcTime = timeDraft ?? value ?? dayjs();
    let final = baseDate.hour(srcTime.hour()).minute(srcTime.minute()).second(0).millisecond(0);

    if (effectiveMinTime && final.isBefore(effectiveMinTime)) {
      final = effectiveMinTime.second(0).millisecond(0);
    }
    onChange(final);
    setOpenTime(false);
    setDateDraft(null);
    setTimeDraft(null);
  };

  const sameDayAsMin =
    !!effectiveMinDate && !!dateDraft && dateDraft.isSame(effectiveMinDate, 'day');

  return (
    <>
      <TextField
        fullWidth
        size={size}
        label={label}
        value={displayFmt(value)}
        onClick={startFlow}
        InputProps={{
          readOnly: true,
          endAdornment: (
            <InputAdornment position="end">
              {value && (
                <IconButton
                  size={size}
                  onClick={(e) => {
                    e.stopPropagation();
                    onChange(null);
                  }}
                >
                  <ClearIcon />
                </IconButton>
              )}
              <IconButton size={size} onClick={startFlow}>
                <EventIcon />
              </IconButton>
            </InputAdornment>
          ),
        }}
        error={!!error}
        helperText={helperText}
        sx={sx}
      />
      <MobileDatePicker
        open={openDate}
        onClose={() => setOpenDate(false)}
        value={dateDraft}
        onChange={(d) => setDateDraft(d)}
        onAccept={acceptDate}
        minDate={effectiveMinDate ?? undefined}
        slotProps={{
          textField: { sx: { display: 'none' } },
          actionBar: { actions: ['cancel', 'accept'] },
        }}
      />
      <MobileTimePicker
        open={openTime}
        onClose={() => setOpenTime(false)}
        value={timeDraft ?? value ?? dayjs()}
        onChange={(t) => setTimeDraft(t)}
        onAccept={acceptTime}
        ampm
        ampmInClock
        minutesStep={1}
        views={['hours', 'minutes']}
        minTime={effectiveMinTime ?? (sameDayAsMin ? effectiveMinDate : undefined)}
        slotProps={{
          textField: { sx: { display: 'none' } },
          actionBar: { actions: ['cancel', 'accept'] },
        }}
      />
    </>
  );
}

// ---------- Component ----------
export default function NstAddView() {
  const { settings } = useUiSettings();
  const size = settings.compact ? 'small' : 'medium';
  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const trialId = React.useMemo(
    () => sessionStorage.getItem('trial') || sessionStorage.getItem('trialId') || '',
    []
  );
  const [trialName, setTrialName] = React.useState<string>('');

  React.useEffect(() => {
    let active = true;
    (async () => {
      try {
        const res = await axiosInstance.post<TrialItem[]>(ENDPOINTS.stats.trialList, {
          trial_direction: 'Oulu',
        });
        if (!active) return;
        const list = res?.data || [];
        const matched = list.find((it) => String(it.trial_id) === String(trialId));
        setTrialName(matched?.name || '');
      } catch (e) {
        setTrialName('');
      }
    })();
    return () => {
      active = false;
    };
  }, [trialId]);

  const methods = useForm<FormValues>({
    resolver: yupResolver(schema),
    mode: 'onBlur',
    defaultValues: {
      name: '',
      start_date: null,
      end_date: null,
      targetNode: 'North',
      targetFacility: 'Oulu',
      slice_option: SLICE_OPTIONS_ENUM.NoSlice,
      slice1_type: null,
      slice2_type: null,
      Application_1: '',
      Application_2: '',
      // description: '',
    },
  });

  const {
    control,
    handleSubmit,
    watch,
    formState: { isSubmitting },
  } = methods;

  const startVal = watch('start_date');
  const sliceOption = watch('slice_option');

  const fieldSx = { '& .MuiOutlinedInput-root': { height: 56 } };

  const onSubmit = handleSubmit(async (values) => {
    const applications: string[] = [];
    if (values.Application_1?.trim()) applications.push(values.Application_1.trim());
    if (values.Application_2?.trim()) applications.push(values.Application_2.trim());

    const startStr = toApiLocalNoTZ(values.start_date);
    const endStr = toApiLocalNoTZ(values.end_date);

    const uniEndStr = sessionStorage.getItem('uni_end');
    const uniStartStr = sessionStorage.getItem('uni_str');

    const startDate = values.start_date ? dayjs(values.start_date).toDate() : null;
    const endDate = values.end_date ? dayjs(values.end_date).toDate() : null;
    const uniEndDate = uniEndStr ? new Date(uniEndStr) : null;
    const uniStartDate = uniStartStr ? new Date(uniStartStr) : null;

    if (
      startDate &&
      endDate &&
      uniStartDate &&
      uniEndDate &&
      (startDate < uniStartDate || endDate > uniEndDate)
    ) {
      showNotification("Experiment times must be within trial's time range.", 'error');
      return;
    }

    if (!trialId) {
      showNotification('Missing trial_id', 'error');
      return;
    }

    const payload = {
      trial_id: trialId,
      name: values.name,
      start_date: startStr,
      end_date: endStr,
      targetNode: values.targetNode,
      targetFacility: values.targetFacility,
      slice_option: values.slice_option,
      slice1_type: values.slice1_type,
      slice2_type: values.slice2_type,
      applications,
      user: Number(sessionStorage.getItem('userId')),
      timezone: clientTZ,
      ...(values.description ? { description: values.description } : {}),
    };

    try {
      await axiosInstance.post(ENDPOINTS.home.nst, payload);
      showNotification('Experiment created successfully', 'success');
      navigate(paths.dashboard.nstList, { replace: true, state: { refresh: Date.now() } });
    } catch (err: any) {
      console.log('0000000000000000000000 \n', err);
      showNotification(err?.response?.data?.name[0] || err?.response?.data, 'error');
    }
  });

  return (
    <Container maxWidth="lg" sx={{ pb: 6 }}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>
          Create a New Experiment
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Define time window, slice configuration and optional applications.
        </Typography>
      </Box>

      <Card
        sx={{
          p: 4,
          borderRadius: 1,
          overflow: 'hidden',
          border: '1px solid',
          borderColor: 'divider',
          boxShadow: (t) => t.shadows[settings.navColor === 'apparent' ? 2 : 1],
        }}
      >
        <CardHeader
          avatar={
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '50%',
                display: 'grid',
                placeItems: 'center',
                bgcolor: (t) => t.palette.primary.light,
                color: (t) => t.palette.primary.contrastText,
                marginLeft: settings.rtl ? 2 : 0,
              }}
            >
              <AddCircleOutlineIcon fontSize="small" />
            </Box>
          }
          title="New Experiment"
          subheader={`Trial: ${trialName || trialId || '-'}`}
          sx={{
            '& .MuiCardHeader-title': { fontWeight: 700 },
            '& .MuiCardHeader-subheader': { color: 'text.secondary' },
            py: 2,
          }}
        />

        <Divider />

        <CardContent sx={{ p: { xs: 2, md: 3 } }}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Box component="form" noValidate onSubmit={onSubmit}>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                  gap: { xs: 2, md: 2.5 },
                  alignItems: 'center',
                }}
              >
                {/* Trial name (read-only) */}
                <TextField
                  value={trialName || ''}
                  label="Trial Name"
                  fullWidth
                  size={size}
                  sx={fieldSx}
                  InputProps={{ readOnly: true }}
                  disabled
                />

                <Controller
                  control={control}
                  name="name"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Experiment Name"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />

                {/* Date/Time pickers */}
                <Controller
                  control={control}
                  name="start_date"
                  render={({ field, fieldState }) => (
                    <TwoStepDateTimeField
                      label="Start Time"
                      value={field.value}
                      onChange={field.onChange}
                      size={size}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      disablePast
                      sx={fieldSx}
                    />
                  )}
                />
                <Controller
                  control={control}
                  name="end_date"
                  render={({ field, fieldState }) => (
                    <TwoStepDateTimeField
                      label="End Time"
                      value={field.value}
                      onChange={field.onChange}
                      size={size}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      minDateTime={startVal ?? undefined}
                      disablePast
                      sx={fieldSx}
                    />
                  )}
                />

                {/* Node & Facility (disabled) */}
                <Controller
                  control={control}
                  name="targetNode"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Target Node"
                      disabled
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />
                <Controller
                  control={control}
                  name="targetFacility"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Facility"
                      disabled
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />

                {/* Applications (optional) */}
                <Controller
                  control={control}
                  name="Application_1"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Application 1 (optional)"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />
                <Controller
                  control={control}
                  name="Application_2"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Application 2 (optional)"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />

                {/* Slice Option */}
                <Controller
                  control={control}
                  name="slice_option"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      select
                      size={size}
                      label="Slice Option"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    >
                      {Object.values(SLICE_OPTIONS_ENUM).map((opt) => (
                        <MenuItem key={opt} value={opt}>
                          {opt}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />

                {/* Description (optional) */}
                {/* <Controller
                  control={control}
                  name="description"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      label="Description"
                      size={size}
                      fullWidth
                      sx={{ ...fieldSx, gridColumn: '1 / -1' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                    />
                  )}
                /> */}
              </Box>

              {/* Slice types (conditional) */}
              {sliceOption !== SLICE_OPTIONS_ENUM.NoSlice && (
                <Box
                  sx={{
                    mt: 2,
                    display: 'grid',
                    gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                    gap: { xs: 2, md: 2.5 },
                  }}
                >
                  <Controller
                    control={control}
                    name="slice1_type"
                    render={({ field, fieldState }) => (
                      <Box>
                        <Typography variant="subtitle2" sx={{ mb: 1 }}>
                          Slice 1
                        </Typography>
                        <RadioGroup
                          row
                          value={field.value ?? ''}
                          onChange={(e) => field.onChange(e.target.value)}
                        >
                          {SLICE_TYPES.map((opt) => (
                            <FormControlLabel
                              key={opt.value}
                              value={opt.value}
                              control={<Radio />}
                              label={opt.label}
                            />
                          ))}
                        </RadioGroup>
                        {fieldState.error && (
                          <Typography variant="caption" color="error">
                            {fieldState.error.message}
                          </Typography>
                        )}
                      </Box>
                    )}
                  />

                  {sliceOption === SLICE_OPTIONS_ENUM.TwoSlice && (
                    <Controller
                      control={control}
                      name="slice2_type"
                      render={({ field, fieldState }) => (
                        <Box>
                          <Typography variant="subtitle2" sx={{ mb: 1 }}>
                            Slice 2
                          </Typography>
                          <RadioGroup
                            row
                            value={field.value ?? ''}
                            onChange={(e) => field.onChange(e.target.value)}
                          >
                            {SLICE_TYPES.map((opt) => (
                              <FormControlLabel
                                key={opt.value}
                                value={opt.value}
                                control={<Radio />}
                                label={opt.label}
                              />
                            ))}
                          </RadioGroup>
                          {fieldState.error && (
                            <Typography variant="caption" color="error">
                              {fieldState.error.message}
                            </Typography>
                          )}
                        </Box>
                      )}
                    />
                  )}
                </Box>
              )}

              <Stack alignItems="flex-end" sx={{ mt: 3 }}>
                <LoadingButton type="submit" variant="contained" loading={isSubmitting} size={size}>
                  Create Experiment
                </LoadingButton>
              </Stack>
            </Box>
          </LocalizationProvider>
        </CardContent>
      </Card>
    </Container>
  );
}
