// @ts-nocheck
/* eslint-disable */
/* eslint-disable consistent-return */

import * as React from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';

import {
  Box,
  Card,
  CardHeader,
  CardContent,
  Chip,
  Button,
  TextField,
  Typography,
  Stack,
} from '@mui/material';
import Autocomplete from '@mui/material/Autocomplete';

import { useNotification } from 'src/context/notification-context';
import { DashboardContent } from 'src/layouts/dashboard';
import { paths } from 'src/routes/paths';
import axiosInstance from 'src/utils/axios';

import { grafanaFields } from 'src/constant/grafanOptions';

function BlockCard(props: { title: string; children: React.ReactNode; sx?: any }) {
  return (
    <Card sx={{ ...props.sx }}>
      <CardHeader title={props.title} />
      <CardContent>{props.children}</CardContent>
    </Card>
  );
}

export default function AnalyzeNstView() {
  const { showNotification } = useNotification();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();

  const stateSliceId = (location.state as any)?.slice_id;         // number
  const queryNumericId = searchParams.get('id');                  // string of number
  const sliceId = Number(stateSliceId ?? queryNumericId);

  const runId = (location.state as any)?.run_id ?? searchParams.get('run'); // UUID string

  const [fields, setFields] = React.useState<{ title: string; value: string }[]>([]);
  const [showChart, setShowChart] = React.useState(false);

  React.useEffect(() => {
    if (!Number.isFinite(sliceId)) {
      showNotification('Invalid slice_id (must be a number)', 'error');
    }
  }, [sliceId, showNotification]);


  const getGrafana = async () => {
  if (fields.length !== 4) {
    showNotification('you have to choose exactly 4 fields', 'warning');
    return;
  }
  if (!sliceId) {
    showNotification('Missing slice_id', 'error');
    return;
  }

  const payload = {
    slice_id: sliceId,
    fields: fields.map((f) => f.value),
  };

  try {
    await axiosInstance.post('/home/api/grafana/', payload);
    showNotification('fetch was successful', 'success');
    setShowChart(true);
  } catch (err: any) {
    const res = err?.response?.data;
    const msg =
      res?.details || res?.error || res?.message || err?.message || 'Grafana prep failed';
    console.error('GRAFANA_PREP_ERROR:', res || err);
    showNotification(String(msg), 'error');
  }
};

  const terminateNst = async () => {
    const idInQuery = searchParams.get('id');
    if (!idInQuery && !sliceId) {
      showNotification('Missing slice id', 'error');
      return;
    }
    const idForApi = idInQuery ?? String(sliceId);
    try {
      await axiosInstance.delete(`/home/api/terminate/${idForApi}/`);
      showNotification('The Experiment Is No Longer Running', 'success');
      navigate(paths.dashboard.nstList);
    } catch (err: any) {
      showNotification(err?.message || 'Terminate failed', 'error');
    }
  };

  const handleDownload = async (isOne: boolean) => {
    const url = `/home/api/downloadcsvview${isOne ? '' : '2'}/`;
    if (!sliceId) {
      showNotification('Missing slice_id for CSV download', 'error');
      return;
    }

    const requestData = {
      slice_id: sliceId,
      fields: fields.map((f) => f.value),
    };

    try {
      const response = await axiosInstance.post(url, requestData, {
        responseType: 'blob',
      });

      const blob = new Blob([response.data], { type: 'text/csv' });
      const downloadUrl = window.URL.createObjectURL(blob);

      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `output${isOne ? '' : '2'}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      showNotification('CSV file downloaded successfully', 'success');
    } catch (error: any) {
      showNotification(error?.message || 'Error downloading the CSV file', 'error');
    }
  };

  const downloadCsv1 = () => handleDownload(true);
  const downloadCsv2 = () => handleDownload(false);

  return (
    <DashboardContent maxWidth="xl">
      {/* Header */}
      <Box
        display="flex"
        sx={{ flexDirection: { xs: 'column', md: 'row' }, gap: { xs: 1, md: 0 }, mb: 3 }}
        justifyContent="space-between"
        alignItems="center"
      >
        <Box>
          <Typography variant="h4">Experiment Analysis Number: {sliceId ?? '-'}</Typography>
          <Typography component="p" sx={{ fontSize: 14, color: 'GrayText' }}>
            Please select exactly 4 KPIs to proceed.
          </Typography>
        </Box>

        <Button onClick={terminateNst} variant="contained" size="small" color="error">
          Terminate the Running Experiment
        </Button>
      </Box>

      {/* Selector */}
      {!showChart && (
        <>
          <BlockCard title="Select Fields for Analysis">
            <Autocomplete
              onChange={(e, val) => {
                if (val.length <= 4) {
                  setFields(val);
                } else {
                  showNotification("you can't choose more than 4 fields", 'warning');
                }
              }}
              value={fields}
              fullWidth
              multiple
              limitTags={4}
              options={grafanaFields}
              getOptionLabel={(option) => option.title}
              renderInput={(params) => (
                <TextField {...params} label="Multiple Select" placeholder="analyze field" />
              )}
              renderOption={(props, option) => (
                <li {...props} key={option.value}>
                  {option.title}
                </li>
              )}
              renderTags={() =>
                fields.map((opt, idx) => (
                  <Chip key={opt.value} label={opt.title} size="small" sx={{ mr: 0.5 }} />
                ))
              }
            />
          </BlockCard>

          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'end', mt: 2 }}>
            <Button onClick={getGrafana} variant="contained" size="medium" color="primary">
              Submit
            </Button>
          </Box>
        </>
      )}

      {/* Charts */}
      {showChart && (
        <>
          <Typography sx={{ display: 'flex', gap: '6px', mt: 1 }} variant="body2" color="primary">
            These Fields Are Now Being Monitored:{' '}
            <Stack direction="row" spacing={0.5} component="span">
              {fields.map((el) => (
                <span key={el.value}>{el.value} |</span>
              ))}
            </Stack>
          </Typography>
<Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'end', mt: 2 }}>
            <Button onClick={downloadCsv1} variant="contained" size="medium" color="primary">
              Download Slice 1 Results
            </Button>
          </Box>
          <BlockCard sx={{ mt: 3, height: '55vh', p: 0.5 }} title="Slice1 chart">
            <iframe
              src="http://193.166.32.46:3000/d/ee7bsv9kgyl8ga/slice1-result?orgId=1&timezone=browser&refresh=10s&theme=light&kiosk"
              width="100%"
              height="400rem"
              frameBorder={0}
            />
          </BlockCard>
          
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'end', mt: 2 }}>
            <Button onClick={downloadCsv2} variant="contained" size="medium" color="primary">
              Download Slice 2 Results
            </Button>
          </Box>
          <BlockCard sx={{ mt: 3, height: '55vh', p: 0.5 }} title="Slice2 chart">
            <iframe
              src="http://193.166.32.46:3000/d/de905ji9nysjkf/slice2-result?orgId=1&timezone=browser&refresh=10s&theme=light&kiosk"
             
              width="100%"
              height="400rem"
              frameBorder={0}
            />
          </BlockCard>

        </>
      )}
    </DashboardContent>
  );
}
