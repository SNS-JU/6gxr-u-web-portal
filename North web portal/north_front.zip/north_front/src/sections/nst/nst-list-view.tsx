// src/sections/nst/nst-list-view.tsx
/* eslint-disable prefer-const */
/* eslint-disable no-unsafe-optional-chaining */
// @ts-nocheck
/* eslint-disable */


import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Theme } from '@mui/material/styles';

import {
  Container,
  Card,
  Alert,
  Button,
  Tooltip,
  IconButton,
  Stack,
  Box,
  LinearProgress,
  Divider,
  Chip,
} from '@mui/material';
import { ArrowLeftRounded, ArrowRightRounded } from '@mui/icons-material';
import { DataGrid, type GridColDef } from '@mui/x-data-grid';

import { paths } from 'src/routes/paths';
import type { NstList } from 'src/types/nst-list';

import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';
import { useNotification } from 'src/context/notification-context';
import { useUiSettings } from 'src/context/ui-settings';

import HeaderListPages from './components/HeaderListPages';
import ViewDrawerForm from './components/ViewDrawerForm';
import StatusTx from './components/StatusTx';
import { Iconify } from 'src/components/iconify';
import ConfirmDialog from 'src/layouts/components/confirm-dialog/ConfirmDialog';

import {
  fetchNstListExternal,
  fetchRunningMessage,
  type TrialsResponse,
} from 'src/services/trial-external';

export default function NstListView() {
  const { settings } = useUiSettings();
  const { showNotification } = useNotification();
  const navigate = useNavigate();
  const location = useLocation();

  const trial_id = sessionStorage.getItem('trial') || sessionStorage.getItem('trialId');

  const [page, setPage] = useState(1);
  const [reload, setReload] = useState(false);

  const [data, setData] = useState<TrialsResponse>({
    previous: null,
    next: null,
    count: 0,
    results: [],
  });

  const [message, setMessage] = useState<{ message: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerData, setDrawerData] = useState<NstList | null>(null);

  // --- Confirm dialog states ---
  const [openConfirm, setOpenConfirm] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<NstList | null>(null);
  const [isdeleting, setisdeleting] = useState<boolean>(false);
  const gridSx = (theme: Theme) => {
    const isLight = theme.palette.mode === 'light';
    return {
      '--DataGrid-rowBorderColor': 'transparent',
      '--DataGrid-hoveredRowBackground': `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.1})`,
      '--DataGrid-selectedRowBackground': `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.12 : 0.2})`,
      '--DataGrid-headerColor': theme.vars
        ? theme.vars.palette.text.primary
        : theme.palette.text.primary,
      border: '1px solid',
      borderColor: 'divider',
      borderRadius: 2,
      overflow: 'hidden',
      '& .MuiDataGrid-columnHeaders': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.14})`,
        color: theme.vars ? theme.vars.palette.text.primary : theme.palette.text.primary,
        fontWeight: 700,
        borderBottom: '1px solid',
        borderColor: 'divider',
        backdropFilter: 'saturate(120%) blur(6px)',
      },
      '& .MuiDataGrid-columnHeader, & .MuiDataGrid-columnHeaderTitle, & .MuiDataGrid-columnHeaderTitleContainer':
      {
        color: theme.vars ? theme.vars.palette.text.primary : theme.palette.text.primary,
        fontWeight: 700,
      },
      '& .MuiDataGrid-columnSeparator': { display: 'none' },
      '& .MuiDataGrid-cell': {
        outline: 'none !important',
        borderBottom: '1px solid',
        borderColor: 'divider',
      },
      '& .MuiDataGrid-row:hover': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.1})`,
      },
      '& .MuiDataGrid-row.Mui-selected': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.12 : 0.2})`,
        '&:hover': {
          backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.14 : 0.24})`,
        },
      },
      '& .MuiDataGrid-virtualScroller': { backgroundColor: theme.vars.palette.background.paper },
      '& .MuiDataGrid-footerContainer': {
        borderTop: '1px solid',
        borderColor: 'divider',
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / 0.72)`,
        backdropFilter: 'saturate(120%) blur(6px)',
      },
      '& .MuiDataGrid-sortIcon, & .MuiDataGrid-iconSeparator, & .MuiDataGrid-menuIcon': {
        color: theme.vars ? theme.vars.palette.text.secondary : theme.palette.text.secondary,
      },
    };
  };

  const fetchAll = useCallback(async () => {
    if (!trial_id) {
      showNotification('Missing trial_id', 'error');
      setData({ previous: null, next: null, count: 0, results: [] });
      return;
    }
    setLoading(true);
    try {
      const res = await fetchNstListExternal(page, trial_id);
      const { unified_end_time, unified_start_time } = res || {};
      if (unified_end_time) sessionStorage.setItem('uni_end', unified_end_time || '');
      if (unified_start_time) sessionStorage.setItem('uni_str', unified_start_time || '');

      const results = (res.results ?? []).map((el: any) => ({
        ...el,
        core_id: el.id,
      }));

      setData({
        previous: res.previous ?? null,
        next: res.next ?? null,
        count: res.count ?? 0,
        results,
        unified_end_time,
        unified_start_time,
      });

      // const msg = await fetchRunningMessage();
      // setMessage(msg ?? null);
    } catch (err: any) {
      console.error('Fetch NST failed:', err?.message || err);
      showNotification('No trial exists. Please return to the Unified Web Portal to create a new trial.', 'error');
      setData({ previous: null, next: null, count: 0, results: [] });
    } finally {
      setLoading(false);
    }
  }, [page, trial_id]);

  const [runningMessage, setRunningMessage] = useState<{
    message: string;
  }>({
    message: '',
  });

  useEffect(() => {
    const fetchRunningSlice = async () => {
      const res = await axiosInstance.get('/home/api/runningnstmessage/');
      if (res.status === 204) {
        setRunningMessage({ message: res.data.message });
      } else if (res) {
        setRunningMessage(res.data);
      } else {
        setRunningMessage({ message: '' });
      }
    };

    fetchRunningSlice();
    if ((location.state as any)?.refresh) {
      fetchAll();
      navigate(location.pathname, { replace: true, state: {} });
    }
    fetchAll();
  }, [location.state, navigate, location.pathname, fetchAll, reload]);

  const handleOpenConfirm = (row: NstList) => {
    setDeleteTarget(row);
    setOpenConfirm(true);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      setisdeleting(true)
      const resp = await axiosInstance.delete(ENDPOINTS.home.newDeleteNst, {
        data: {
          nst_id: Number((deleteTarget as any).core_id),
          user: Number(sessionStorage.getItem('userId')),
        },
      });
      if (resp) {
        showNotification('Experiment deleted successfully', 'success');
        setReload((p) => !p);
        setMessage(null);
      }
    } catch (error: any) {
      console.warn('External service error ignored:', error?.message || error);
      showNotification('Deleted locally, but external sync failed', 'warning');
      setReload((p) => !p);
      setMessage(null);
    } finally {
      setOpenConfirm(false);
      setDeleteTarget(null);
      setisdeleting(false)

    }
  };

  const runHandler = async (id: string) => {
    const userId = Number(sessionStorage.getItem('userId'));
    if (!id) {
      showNotification('Missing nst_id', 'error');
      return;
    }
    if (!userId || Number.isNaN(userId)) {
      showNotification('Missing or invalid userId', 'error');
      return;
    }

    try {
      showNotification('Submitting experiment…', 'info');

      // --- Step 1: Submit ---
      let submitResp;
      try {
        submitResp = await axiosInstance.post(ENDPOINTS.home.submit, {
          nst_id: Number(id),
          user: userId,
        });
      } catch (err: any) {
        const res = err?.response?.data;
        const msg =
          res?.details ||
          res?.error ||
          res?.message ||
          err?.message ||
          'Failed to submit experiment';
        console.error('Submit error:', err?.response || err);
        showNotification(String(msg), 'error');
        return;
      }

      if (!(submitResp && submitResp.status >= 200 && submitResp.status < 300)) {
        showNotification('Unexpected submit response', 'error');
        return;
      }

      // --- Step 2: Send Query ---
      let queryResp;
      try {
        queryResp = await axiosInstance.post(ENDPOINTS.home.sendQuery, {
          slice_id: Number(id),
        });
      } catch (err: any) {
        const res = err?.response?.data;
        const msg =
          res?.details ||
          res?.error ||
          res?.message ||
          err?.message ||
          'Failed to submit data to the external API';
        console.error('sendQuery error:', err?.response || err);
        showNotification(String(msg), 'error');
        return;
      }

      if (!(queryResp && queryResp.status >= 200 && queryResp.status < 300)) {
        showNotification('Unexpected external API response', 'error');
        return;
      }

      showNotification('Experiment started successfully', 'success');
      navigate(`${paths.dashboard.analyze}?run=${queryResp.data}&id=${id}`, {
        state: { slice_id: Number(id), run_id: String(queryResp.data) },
      });
    } catch (error: any) {
      const res = error?.response?.data;
      const msg =
        res?.details || res?.error || res?.message || error?.message || 'An error occurred';
      console.error('RUN_HANDLER_FATAL:', res || error);
      showNotification(String(msg), 'error');
    }
  };


  const columns = useMemo<GridColDef<NstList>[]>(() => {
    return [
      {
        field: 'trial_id',
        width: 70,
        headerName: 'Trial ID',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'name',
        width: 120,
        headerName: 'Experiment',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'start_date',
        width: 200,
        headerName: 'Start Time',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'end_date',
        width: 200,
        headerName: 'End Time',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'targetNode',
        width: 70,
        headerName: 'Node',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'slice_option',
        width: 120,
        headerName: 'Slice Option',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'slice1_type',
        width: 70,
        headerName: 'Slice 1',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'slice2_type',
        width: 70,
        headerName: 'Slice 2',
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'app1',
        headerName: 'App1',
        width: 100,
        align: 'center',
        headerAlign: 'center',
        renderCell: ({ row }) => <div>{(row as any).applications?.[0] ?? ''}</div>,
        sortable: false,
        filterable: false,
      },
      {
        field: 'app2',
        headerName: 'App2',
        width: 100,
        align: 'center',
        headerAlign: 'center',
        renderCell: ({ row }) => <div>{(row as any).applications?.[1] ?? ''}</div>,
        sortable: false,
        filterable: false,
      },
      {
        field: 'status',
        width: 70,
        headerName: 'Status',
        align: 'center',
        headerAlign: 'center',
        renderCell: ({ row }) => {
          const rowId = row.core_id ?? row.id;
          return <StatusTx key={rowId} id={rowId} />;
        },
        sortable: false,
        filterable: false,
      },
      {
        field: 'actions',
        width: 220,
        headerName: 'Actions',
        align: 'center',
        headerAlign: 'center',
        renderCell: ({ row }) => {
          const now_time = new Date();
          const uniEndStr = sessionStorage.getItem('uni_end');
          const uni_end_time = uniEndStr ? new Date(uniEndStr) : null;
          const isDisabled = uni_end_time ? now_time > uni_end_time : false;

          return (
            <>
              <Tooltip
                title="Send experiment to North Node Adapter"
                placement="top-start"
                componentsProps={{
                  tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
                  arrow: { sx: { color: '#292929ff' } },
                }}
                arrow
              >
                <IconButton
                  disabled={isDisabled}
                  onClick={() => runHandler(String((row as any).core_id))}
                >
                  <Iconify icon="fluent:play-16-filled" />
                </IconButton>
              </Tooltip>

              <Tooltip
                title="Edit the experiment"
                placement="top-start"
                componentsProps={{
                  tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
                  arrow: { sx: { color: '#292929ff' } },
                }}
                arrow
              >
                <IconButton
                  disabled={isDisabled}
                  onClick={() =>
                    navigate(paths.dashboard.editNst, {
                      state: { nstID: (row as any).id },
                    })
                  }
                >
                  <Iconify icon="solar:pen-bold" />
                </IconButton>
              </Tooltip>

              <Tooltip
                title="Explore Your Analysis"
                placement="top-start"
                componentsProps={{
                  tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
                  arrow: { sx: { color: '#292929ff' } },
                }}
                arrow
              >
                <IconButton
                  disabled={isDisabled}
                  onClick={() => {
                    setDrawerData({ ...(row as any), core_id: (row as any).core_id });
                    setDrawerOpen(true);
                  }}
                >
                  <Iconify icon="hugeicons:view" />
                </IconButton>
              </Tooltip>

              <Tooltip
                title="Delete the experiment"
                placement="top-start"
                componentsProps={{
                  tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
                  arrow: { sx: { color: '#292929ff' } },
                }}
                arrow
              >
                <IconButton onClick={() => handleOpenConfirm(row as any)}>
                  <Iconify icon="ic:round-delete" />
                </IconButton>
              </Tooltip>
            </>
          );
        },
        sortable: false,
        filterable: false,
      },
    ];
  }, [navigate]);

  return (
    <Container maxWidth="xl">
      <HeaderListPages title="My Experiments" addRoute={paths.dashboard.addNst} />

      {runningMessage.message != '' ? (
        <Alert sx={{ my: 2 }} severity="info">
          {runningMessage?.message}
        </Alert>
      ) : null}

      <Card>
        {loading && <LinearProgress />}
        <Box sx={{ p: settings.compact ? 1 : 2 }}>
          <DataGrid
            rows={data.results}
            getRowId={(r) => (r as any).id ?? (r as any).trial_id ?? (r as any).core_id}
            columns={columns}
            autoHeight
            loading={loading}
            disableRowSelectionOnClick
            disableColumnMenu
            density={settings.compact ? 'compact' : 'standard'}
            rowHeight={settings.compact ? 40 : 48}
            columnHeaderHeight={settings.compact ? 44 : 56}
            sx={gridSx}
            hideFooter
          />
        </Box>

        <Divider />
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ px: 2, py: 1.5 }}
        >
          <Button
            startIcon={<ArrowLeftRounded />}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={!data.previous}
            size={settings.compact ? 'small' : 'medium'}
          >
            previous
          </Button>

          <Chip
            size="small"
            label={`page: ${page} | ${data.results?.length ?? 0} - ${data.count ?? 0}`}
            variant="outlined"
          />

          <Button
            endIcon={<ArrowRightRounded />}
            onClick={() => setPage((p) => p + 1)}
            disabled={!data.next}
            size={settings.compact ? 'small' : 'medium'}
          >
            next
          </Button>
        </Stack>
      </Card>

      <ViewDrawerForm item={drawerData} open={drawerOpen} onClose={() => setDrawerOpen(false)} />

      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        open={openConfirm}
        loading={isdeleting}
        onClose={() => {
          if (isdeleting) return;
          setOpenConfirm(false);
          setDeleteTarget(null);
        }}
        onConfirm={handleDelete}
        title="Delete Experiment"
        content="Are you sure you want to delete this experiment?"
      />
    </Container>
  );
}
