/* eslint-disable */
import * as React from 'react';
import {
  CssVarsProvider,
  extendTheme,
  useColorScheme,
  type CssVarsThemeOptions,
  type Theme,
  type PaletteOptions,
  type Components,
} from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';

import '@mui/x-data-grid/themeAugmentation';

// ---- mode persistence helpers (cookie + localStorage) ----
const COOKIE_KEYS = ['THEME_MODE', 'app-color-scheme'] as const;
const LS_KEYS = ['mui-mode', 'app-color-scheme'] as const;

function getCookie(key: string): string | null {
  const m = document.cookie.match(new RegExp('(?:^|; )' + key + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]) : null;
}
function setCookie(key: string, value: string, days = 365) {
  const d = new Date();
  d.setTime(d.getTime() + days * 86400000);
  document.cookie = `${key}=${encodeURIComponent(value)}; expires=${d.toUTCString()}; path=/`;
}
function sanitizeMode(raw?: string | null): 'light' | 'dark' | null {
  if (!raw) return null;
  const val = raw.toLowerCase().replace(/[^\w-]/g, '');
  if (val.includes('light')) return 'light';
  if (val.includes('dark')) return 'dark';
  return null;
}
function readPersistedMode(): 'light' | 'dark' | null {
  // 1) cookies
  for (const k of COOKIE_KEYS) {
    const v = sanitizeMode(getCookie(k));
    if (v) return v;
  }
  // 2) localStorage
  try {
    for (const k of LS_KEYS) {
      const v = sanitizeMode(localStorage.getItem(k));
      if (v) return v;
    }
  } catch {}
  return null;
}
function writePersistedMode(mode: 'light' | 'dark') {
  // cookies
  for (const k of COOKIE_KEYS) setCookie(k, mode);
  // localStorage
  try {
    for (const k of LS_KEYS) localStorage.setItem(k, mode);
  } catch {}
}

// ---------- Palettes ----------
const lightPalette: PaletteOptions = {
  primary: { main: '#2563EB', light: '#5B8CFF', dark: '#1E4FD6', contrastText: '#fff' },
  secondary: { main: '#7C3AED', light: '#9F67F3', dark: '#5B27C2', contrastText: '#fff' },
  success: { main: '#22C55E' },
  warning: { main: '#F59E0B' },
  error: { main: '#EF4444' },
  info: { main: '#0EA5E9' },
  divider: 'rgba(15, 23, 42, 0.08)',
  text: { primary: '#0F172A', secondary: 'rgba(15,23,42,0.64)' },
  background: { default: '#F7F8FB', paper: '#FFFFFF' },
};

const darkPalette: PaletteOptions = {
  primary: { main: '#7AA2FF', light: '#A3BEFF', dark: '#5E86F5', contrastText: '#0B1220' },
  secondary: { main: '#B78BFA', light: '#C8A7FD', dark: '#9E6CF3', contrastText: '#0B1220' },

  success: { main: '#34D399' },
  warning: { main: '#FBBF24' },
  error: { main: '#F87171' },
  info: { main: '#60A5FA' },

  divider: 'rgba(255,255,255,0.12)',

  text: { primary: '#E8EDF4', secondary: 'rgba(232,237,244,0.64)' },
  background: {
    default: '#0B1220',
    paper: '#121A2B',
  },
};

// ---------- Component overrides ----------
const components: Components<Theme> = {
  MuiCssBaseline: {
    styleOverrides: {
      '*, *::before, *::after': { boxSizing: 'border-box' },
      body: { WebkitFontSmoothing: 'antialiased', MozOsxFontSmoothing: 'grayscale' },
      ':root': { '--header-blur': '10px' as any },
    },
  },
  MuiAppBar: {
    styleOverrides: {
      root: ({ theme }: { theme: Theme }) => ({
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / 0.72)`,
        backdropFilter: 'saturate(120%) blur(10px)',
        borderBottom: '1px solid',
        borderColor: theme.palette.divider,
        boxShadow:
          theme.palette.mode === 'light'
            ? '0 1px 0 0 rgba(15, 23, 42, 0.06)'
            : '0 1px 0 0 rgba(0, 0, 0, 0.5)',
      }),
    },
  },
  MuiPaper: {
    defaultProps: { elevation: 0 },
    styleOverrides: {
      root: ({ theme }: { theme: Theme }) => ({
        borderRadius: 16,
        backgroundImage: 'none',
        border: `1px solid ${theme.palette.divider}`,
      }),
    },
  },
  MuiCard: {
    styleOverrides: {
      root: ({ theme }: { theme: Theme }) => ({
        borderRadius: 16,
        border: `1px solid ${theme.palette.divider}`,
        boxShadow:
          theme.palette.mode === 'light'
            ? '0 4px 24px rgba(15,23,42,0.06)'
            : '0 8px 32px rgba(0,0,0,0.35)',
      }),
    },
  },
  MuiButton: {
    defaultProps: { disableElevation: true },
    styleOverrides: {
      root: {
        borderRadius: 12,
        textTransform: 'none',
        fontWeight: 700,
      },
      containedPrimary: {
        boxShadow: '0 6px 18px rgba(37,99,235,0.22)',
      },
    },
  },
  MuiIconButton: { styleOverrides: { root: { borderRadius: 12 } } },
  MuiTextField: { defaultProps: { size: 'medium' } },
  MuiOutlinedInput: {
    styleOverrides: {
      root: ({ theme }: { theme: Theme }) => ({
        borderRadius: 12,
        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
          borderColor: theme.palette.primary.main,
          boxShadow:
            theme.palette.mode === 'light'
              ? '0 0 0 3px rgba(37,99,235,0.15)'
              : '0 0 0 3px rgba(138,180,255,0.22)',
        },
      }),
    },
  },
  MuiChip: { styleOverrides: { root: { borderRadius: 10, fontWeight: 600 } } },
  MuiTooltip: {
    styleOverrides: { tooltip: { borderRadius: 10, fontSize: 12, padding: '6px 10px' } },
  },

  MuiDataGrid: {
    styleOverrides: {
      root: ({ theme }: { theme: Theme }) => ({
        borderRadius: 12,
        border: `1px solid ${theme.palette.divider}`,
        backgroundColor: theme.palette.background.paper,
        '--DataGrid-rowBorderColor': 'transparent' as any,
      }),
      columnHeaders: ({ theme }: { theme: Theme }) => ({
        background: theme.palette.mode === 'light' ? '#F3F6FD' : 'rgba(255,255,255,0.06)',
        color: theme.palette.mode === 'light' ? '#0F172A' : theme.palette.text.primary,
        fontWeight: 700,
        borderBottom: `1px solid ${theme.palette.divider}`,
      }),
      cell: { outline: 'none !important' },
      row: ({ theme }: { theme: Theme }) => ({
        '&:hover': {
          background:
            theme.palette.mode === 'light' ? 'rgba(37,99,235,0.035)' : 'rgba(138,180,255,0.08)',
        },
      }),
    },
  },
};

const themeOptions: CssVarsThemeOptions = {
  colorSchemeSelector: 'data',
  colorSchemes: { light: { palette: lightPalette }, dark: { palette: darkPalette } },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily:
      '"DM Sans Variable", "Barlow", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
    h1: { fontSize: 36, fontWeight: 800 },
    h2: { fontSize: 28, fontWeight: 800 },
    h3: { fontSize: 22, fontWeight: 800 },
    h4: { fontSize: 20, fontWeight: 800 },
    h5: { fontSize: 18, fontWeight: 700 },
    h6: { fontSize: 16, fontWeight: 700 },
    subtitle1: { fontWeight: 700 },
    button: { fontWeight: 700, letterSpacing: 0.2 },
  },
  components,
};

const theme = extendTheme(themeOptions);

export function useThemeMode() {
  const { mode = 'light', setMode } = useColorScheme();
  const toggle = React.useCallback(
    () => setMode(mode === 'light' ? 'dark' : 'light'),
    [mode, setMode]
  );
  return { mode, toggle, set: setMode };
}

type Props = { children: React.ReactNode };
export default function ThemeProvider({ children }: Props) {
  return (
    <CssVarsProvider theme={theme} defaultMode="light" disableTransitionOnChange>
      <CssBaseline />
      {children}
    </CssVarsProvider>
  );
}
