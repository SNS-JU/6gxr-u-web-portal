import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { createBrowserRouter, Outlet, RouterProvider } from 'react-router';

import App from './app';
import { routesSection } from './routes/sections';
import { ErrorBoundary } from './routes/components';
import { AuthProvider } from './auth/context/auth-provider';
import { NotificationProvider } from './context/notification-context';

import InitColorSchemeScript from '@mui/material/InitColorSchemeScript'; // 👈

// ----------------------------------------------------------------------

const router = createBrowserRouter([
  {
    Component: () => (
      <NotificationProvider>
        <AuthProvider>
          <App>
            <Outlet />
          </App>
        </AuthProvider>
      </NotificationProvider>
    ),
    errorElement: <ErrorBoundary />,
    children: routesSection,
  },
]);

const root = createRoot(document.getElementById('root')!);

root.render(
  <StrictMode>
    <InitColorSchemeScript /> 
    <RouterProvider router={router} />
  </StrictMode>
);
