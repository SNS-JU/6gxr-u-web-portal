import { useState, useEffect, useCallback, useRef } from 'react';
import axios from 'axios';

interface FetchState<T> {
  data: T | null;
  loading: boolean;
  error: Error | null;
}

interface UseFetchReturn<T> extends FetchState<T> {
  refetch: () => Promise<FetchState<T>>;
}

export function useFetch<T = any>(url: string): UseFetchReturn<T> {
  const [state, setState] = useState<FetchState<T>>({
    data: null,
    loading: true,
    error: null,
  });

  const controllerRef = useRef<AbortController | null>(null);

  const doFetch = useCallback(async (): Promise<FetchState<T>> => {
    setState((prev) => ({ ...prev, loading: true }));

    controllerRef.current?.abort();
    controllerRef.current = new AbortController();

    try {
      const token =
        sessionStorage.getItem('accessToken') || localStorage.getItem('accessToken') || '';

      const response = await axios.get<T>(url, {
        headers: token ? { Authorization: `Bearer ${token}` } : undefined,
        signal: controllerRef.current.signal,
      });

      const next: FetchState<T> = { data: response.data, loading: false, error: null };
      setState(next);
      return next;
    } catch (error: any) {
      if (axios.isCancel?.(error)) {
        return state;
      }
      const next: FetchState<T> = { data: null, loading: false, error };
      setState(next);
      return next;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url]);

  useEffect(() => {
    doFetch();
    return () => controllerRef.current?.abort();
  }, [doFetch]);

  return { ...state, refetch: doFetch };
}
