
import { CONFIG } from 'src/config-global';
import { DashboardContent } from 'src/layouts/dashboard';

import { AboutContent } from './content-about';

// ----------------------------------------------------------------------

const metadata = { title: `Stats - ${CONFIG.appName}` };

export default function AboutPage() {
  return (
    <>
      <DashboardContent maxWidth="xl">
        <AboutContent />
      </DashboardContent>
    </>
  );
}
