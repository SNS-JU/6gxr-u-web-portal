import SignUpView from '../sections/auth/sign-up-view';

export default function SignUpPage() {
  return <SignUpView />;
}
