// @ts-nocheck
/* eslint-disable */

import * as React from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Stack,
  Typography,
  Avatar,
  Chip,
  Divider,
  Button,
  Paper,
  Box,
  Alert,
  LinearProgress,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';

import { z as zod } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';

import { useAuthContext } from 'src/auth/hooks/use-auth-context';

// RHF helpers of your project
import FormProvider from 'src/components/hook-form/form-provider';
import RHFTextField from 'src/components/hook-form/rhf-text-field';

// Optional loading screen you have
import LoadingScreen from 'src/components/loading/loading-screen';
import axios from 'axios';

// ---------------- Types & Schema ----------------

type ProfileFormValues = {
  first_name: string;
  last_name: string;
  phone: string;
};

const ProfileSchema = zod.object({
  first_name: zod.string().min(1, { message: 'please fulfill the input' }),
  last_name: zod.string().min(1, { message: 'please fulfill the input' }),
  phone: zod.string().min(1, { message: 'please fulfill the input' }),
});

export default function ProfilePage() {
  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';
  const { user } = useAuthContext();

  const name = user?.username || 'User';
  const email = user?.email || '-';
  const role = (user as any)?.role || 'Member';
  const joinedAt = (user as any)?.joinedAt || '-';

  const PROFILE_GET_URL = (ENDPOINTS as any)?.profile;

  const PROFILE_UPDATE_URL = (ENDPOINTS as any)?.profileUpdate;

  const methods = useForm<ProfileFormValues>({
    mode: 'all',
    resolver: zodResolver(ProfileSchema),
    defaultValues: {
      first_name: '',
      last_name: '',
      phone: '',
    },
  });

  const {
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = methods;

  const [loading, setLoading] = React.useState(true);
  const [loadError, setLoadError] = React.useState<string | null>(null);
  const [successMsg, setSuccessMsg] = React.useState<string | null>(null);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);
  const token = sessionStorage.getItem('accessToken');
  const [profile, setProfile] = React.useState({
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
  });

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setLoadError(null);
      try {
        // const res = await axios.post('http://127.0.0.1:8000/users/api/users/profile/', { token });
        const res = await axios.post('http://193.166.32.46:8000/users/api/users/profile/', {
          token,
        });
        const data = res?.data || {};
        const first_name = data.first_name ?? data.firstname ?? '';
        const last_name = data.last_name ?? data.lastname ?? '';
        const phone = data.phone ?? data.phone_number ?? data.mobile ?? '';
        const email = data.email ?? '';
        setProfile({
          first_name,
          last_name,
          phone,
          email,
        });
        if (mounted) {
          reset({
            first_name,
            last_name,
            phone,
          });
        }
      } catch (err: any) {
        if (mounted) setLoadError(err?.message || 'Failed to load profile');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [PROFILE_GET_URL, reset]);

  // ---- Submit

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <Container maxWidth="lg" sx={{ py: 3 }}>
      {loadError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {loadError}
        </Alert>
      )}

      {/* Hero */}
      <Grid display={'flex'} flexDirection={'column'} gap={5}>
        <Grid width={400}>
          <Paper
            variant="outlined"
            sx={{
              p: { xs: 2, md: 3 },
              borderRadius: 1,
              borderColor: 'divider',
              backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.72 : 0.5})`,
              backdropFilter: 'saturate(120%) blur(10px)',
            }}
          >
            <Stack direction="row" spacing={2} alignItems="center">
              <Avatar
                sx={(t) => ({
                  width: 72,
                  height: 72,
                  fontWeight: 800,
                  color: isLight ? '#fff' : '#0B1220',
                  backgroundImage: `linear-gradient(135deg, rgba(${t.vars.palette.primary.mainChannel} / 0.95), rgba(${t.vars.palette.secondary.mainChannel} / 0.95))`,
                })}
              >
                {profile.first_name[0]?.toUpperCase() || 'U'}
              </Avatar>

              <Box sx={{ minWidth: 0, flex: 1 }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.25 }}>
                  <Typography variant="h5" fontWeight={800} noWrap>
                    {profile.first_name + ' ' + profile.last_name}
                  </Typography>
                  <Chip size="small" label={role} sx={{ height: 22 }} />
                </Stack>
                <Typography variant="body2" color="text.secondary" noWrap title={email}>
                  {profile.email}
                </Typography>
              </Box>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Card variant="outlined" sx={{ borderRadius: 1 }}>
            <CardHeader titleTypographyProps={{ fontWeight: 800 }} title=" Profile" />
            <CardContent>
              <FormProvider methods={methods}>
                <Grid
                  display={'flex'}
                  flexDirection={'row'}
                  gap={5}
                  // sx={{ backgroundColor: 'red' }}
                  justifyContent={'space-evenly'}
                >
                  <Grid width={300}>
                    <RHFTextField name="first_name" label="First Name" disabled />
                  </Grid>
                  <Grid width={300}>
                    <RHFTextField name="last_name" label="Last Name" disabled />
                  </Grid>
                  <Grid width={300}>
                    <RHFTextField name="phone" label="Phone" disabled />
                  </Grid>
                </Grid>
              </FormProvider>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}
