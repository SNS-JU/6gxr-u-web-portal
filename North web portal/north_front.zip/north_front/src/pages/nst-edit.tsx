import NstEditView from '../sections/nst/nst-edit-view';

export default function NstEditPage() {
  return <NstEditView />;
}
