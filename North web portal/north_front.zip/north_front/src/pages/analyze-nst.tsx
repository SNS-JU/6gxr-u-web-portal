import * as React from 'react';
import AnalyzeNstView from 'src/sections/nst/analyze-nst-view';

export default function AnalyzeNstPage() {
  return <AnalyzeNstView />;
}
