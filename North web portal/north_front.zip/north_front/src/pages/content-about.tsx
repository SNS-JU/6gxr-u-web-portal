/* eslint-disable */

import PlayCircleOutlineIcon from '@mui/icons-material/PlayCircleOutline';
import VisibilityIcon from '@mui/icons-material/Visibility';
import React, { useState } from 'react';

import {
  Box,
  Container,
  Typography,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const AboutContent: React.FC = () => {
  const [expanded, setExpanded] = useState<string | false>(false);

  const handleChange = (panel: string) => (_event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false);
  };

  const renderBullets = (items: string[]) => (
    <List>
      {items.map((item, index) => (
        <ListItem key={index} alignItems="flex-start">
          <ListItemIcon>
            <CheckCircleIcon color="primary" />
          </ListItemIcon>
          <ListItemText primary={<span>{item}</span>} />
        </ListItem>
      ))}
    </List>
  );

  return (
    <Container maxWidth="md" sx={{ paddingY: 4 }}>
      <Box sx={{ marginTop: 4 }}>
        <Typography variant="h4" gutterBottom>
          North Portal Overview
        </Typography>

        <Accordion
          expanded={expanded === 'panel1'}
          onChange={handleChange('panel1')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">System Overview</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1">
              In the North Portal, experimenter can create their experiments based on selected slice
              types such as eMBB and URLLC. After initiating the experiment, experimenters can
              monitor the resulting data through the integrated dashboard and perform evaluations
              based on the observed outcomes within the North web portal. The primary purpose of
              this portal is to enable the creation of experiments and the visualization of related
              performance results in a clear and structured manner.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel2'}
          onChange={handleChange('panel2')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">User Functionality in the North Portal</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'Once an experimenter registers in the Unified Portal, their account is automatically created in the North Portal as well.',
              'In the North portal, the experimenter is permitted to view only their profile.',
              'All user-related actions, such as registration, account editing, deletion, and password recovery, are handled exclusively through the Unified Portal. Experimenters must return to the Unified Portal to perform any of these operations.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel3'}
          onChange={handleChange('panel3')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Create an Experiment</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              Upon accessing the dashboard of the North Portal, the experimenter can view a list of
              existing experiments or choose to create a new one. If the trial period has expired,
              the user will no longer be able to create new experiments. Additionally, any
              experiment must be created within the valid duration of the associated trial. To
              create an experiment, the experimenter must provide the following information:
            </Typography>
            {renderBullets([
              'Experiment Name',
              'Start Time',
              'End Time',
              'Slice Type: either URLLC, eMBB, or No Slice',
            ])}
            <Typography variant="body1" paragraph>
              Specific fields, such as Trial Name, Facility, and Node, are predefined and fixed. The
              Trial Name is automatically imported from the Unified Portal, establishing a clear
              link between each experiment and its corresponding trial. After successfully creating
              an experiment, the experimenter is redirected to the experiment list page, where all
              created experiments can be viewed and managed.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel4'}
          onChange={handleChange('panel4')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Experiment List Page</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              On this page, experimenters can view a list of all created experiments. Each
              experiment entry provides options to view, edit, delete, and send the experiment to
              the NNA (North Node Adapter).
              <br />
              <strong>Important:</strong> After creating an experiment, the experimenter must first
              send it to NNA. Only then can the results of the experiment be viewed.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel5'}
          onChange={handleChange('panel5')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Experiment Results Visualization</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              A details page opens by clicking the "View" (eye icon). This includes:
            </Typography>
            {renderBullets([
              'Experiment information',
              'A button to proceed to the Grafana dashboard for monitoring results',
            ])}
            <Typography variant="body1" paragraph>
              Access Restrictions:
            </Typography>
            {renderBullets([
              'The experimenter cannot enter the Grafana dashboard if the experiment has already ended.',
              'If the current system time is later than the experiment’s start time, and the experiment has not yet been sent to NNA, the experimenter will be blocked from accessing the dashboard.',
              'In such cases, the experimenter must create a new experiment with a valid future start time.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel6'}
          onChange={handleChange('panel6')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Selecting KPIs</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'The experimenter can select 4 KPIs from the provided list.',
              'After submitting the selected KPIs, the system will wait for the experiment to start.',
              'If the experiment has already started, results will be shown immediately. Otherwise, the experimenter must wait until the scheduled start time.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel7'}
          onChange={handleChange('panel7')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Grafana Dashboard</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'The experimenter is redirected to the Grafana dashboard to view real-time results.',
              'Grafana provides options such as time range adjustments and panel settings.',
              'Experimenters can download results anytime or wait until the experiment ends to access more complete data.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel8'}
          onChange={handleChange('panel8')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Terminating an Experiment</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'The experimenter can terminate an experiment at any time, whether it is currently running or not.',
              'The experimenter can also reselect KPIs and resubmit them to see updated results.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel9'}
          onChange={handleChange('panel9')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Concurrent Experiment Rule</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'Only one experiment can be active at a time.',
              'If there is already an active experiment, a warning message will appear at the top of the experiment list.',
              'The experimenter must either wait for it to finish or delete the current active experiment (if they created it) to start a new one.',
              'After the experiment is completed, it will remain in the system for only 10 minutes before being deleted. Users must review the information and download their results within this 10-minute window.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel10'}
          onChange={handleChange('panel10')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Summary Flow</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {renderBullets([
              'Create an experiment with a valid future time.',
              'Send the experiment to NNA.',
              'Go to the Grafana dashboard',
              'Select and submit 4 KPIs.',
              'Wait for the start time (or view results if already started).',
              'Monitor on the Grafana dashboard.',
              'Download results or terminate the experiment as needed.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel11'}
          onChange={handleChange('panel11')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Additional Interface Components</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              In the top-left corner of the application, the experimenter can find the main
              navigation tabs. One of these tabs is the "User Guide" section, which provides general
              information and guidance on how to use the system. In the top-right corner, there is
              an experimenter menu. By clicking on it, experimenters can view their personal
              information. (Editing is not available in the North Portal)
            </Typography>
            {renderBullets([
              'Switching between light and dark themes',
              'Adjusting page layout sizes',
              'Aligning the interface left-to-right or right-to-left',
            ])}
            <Typography variant="body1">
              Finally, at the bottom left of the interface, experimenters can log out of the system
              or access external links related to the 6G-XR project.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel12'}
          onChange={handleChange('panel12')}
          sx={{ backgroundColor: '#ccf1ff', border: '1px solid #66cfff', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Contact Info / Support</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1">
              If you encounter any issues or conflicts while using the system, please contact Mahdi
              Salmani, the person responsible for the Unified and North portals:
              <br />
              mohammad.salmani@oulu.fi
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Box>
    </Container>
  );
};

export { AboutContent };
