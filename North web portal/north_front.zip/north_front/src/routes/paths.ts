export const paths = {
  dashboard: {
    nstList: '/dashboard/nst-list',
    addNst: '/dashboard/nst-add',
    editNst: `/dashboard/nst/edit`,
    about: '/dashboard/about',
    profile: '/dashboard/profile',
    analyzeNst: '/dashboard/analyze-nst',
    analyze: '/dashboard/analyze',
  },
  auth: {
    login: '/login',
    register: '/register',
    profile: '/users/api/users/profile/',
    forgot: '/forgot-password',
  },
};
