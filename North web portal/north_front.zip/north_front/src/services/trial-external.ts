// src/services/nst-external.ts
import axios from 'axios';
import { STORAGE_KEY } from 'src/auth/context/jwt/constant';

export type TrialsResponse = {
  previous?: string | null;
  next?: string | null;
  count: number;
  results: any[];
  unified_end_time?: string;
  unified_start_time?: string;
};

const NST_BASE = import.meta.env.VITE_NST_BASE_URL || 'http://193.166.32.46:8080';
const EMPTY_TRIALS: TrialsResponse = { previous: null, next: null, count: 0, results: [] };

function hardLogoutRedirect() {
  try {
    sessionStorage.clear();
    localStorage.clear?.();
  } catch {}
  window.location.replace('/login');
}

function getAccessToken(): string | null {
  return (
    sessionStorage.getItem(STORAGE_KEY) ||
    sessionStorage.getItem('accessToken') ||
    null
  );
}

export async function fetchNstListExternal(page: number, trialId: string) {
  const access = getAccessToken();
  if (!trialId) {
    return EMPTY_TRIALS;
  }
  if (!access) {
    hardLogoutRedirect();
    return EMPTY_TRIALS;
  }

  try {
    const res = await axios.post(
      `${NST_BASE}/home/api/getnst/?page=${page}`,
      { trial_id: trialId },
      { headers: { Authorization: `Bearer ${access}` } }
    );
    return res.data as TrialsResponse;
  } catch (err: any) {
    const status = err?.response?.status;
    if (status === 401) {
      hardLogoutRedirect();
      return EMPTY_TRIALS;
    }
    throw err;
  }
}

export async function fetchRunningMessage() {
  const access = getAccessToken();
  if (!access) {
    return null;
  }

  try {
    const res = await axios.get(`${NST_BASE}/home/api/runningnstmessage/`, {
      headers: { Authorization: `Bearer ${access}` },
    });
    return res.data as { message: string };
  } catch (err: any) {
    if (err?.response?.status === 401) {
      hardLogoutRedirect();
      return null;
    }
    throw err;
  }
}
