import { apiFetch } from './http';
import { ENDPOINTS } from '../config';
import { tokenStorage } from './tokenStorage';

export type Session = {
  access: string;
  refresh: string;
  username?: string;
};

function decodeJwt<T = any>(token: string): T | null {
  try {
    const payload = token.split('.')[1];
    const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
    return JSON.parse(decodeURIComponent(escape(json)));
  } catch {
    return null;
  }
}

export async function signIn(username: string, password: string): Promise<Session> {
  const res = await apiFetch(ENDPOINTS.token, {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    const msg = (data?.detail || 'Invalid credentials') as string;
    throw new Error(msg);
  }
  const data = (await res.json()) as { access: string; refresh: string };
  tokenStorage.set(data.access, data.refresh);
  const payload = decodeJwt<any>(data.access);
  return { access: data.access, refresh: data.refresh, username: payload?.username || username };
}

export function signOut() {
  tokenStorage.clear();
}

export function isAuthenticated() {
  return !!tokenStorage.getAccess();
}

export type RegisterPayload = {
  first_name?: string;
  last_name?: string;
  email?: string;
  phone_number?: string;
  username: string;
  password: string;
};

export async function registerUser(payload: RegisterPayload): Promise<void> {
  const res = await apiFetch(ENDPOINTS.register, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    throw new Error(data?.detail || 'Registration failed');
  }
}
