import {API_BASE, ENDPOINTS} from "../config";
import { tokenStorage } from './tokenStorage'

async function refreshAccess() {
    const refresh = tokenStorage.getRefresh()
    if (!refresh) return false
    const r = await fetch(API_BASE + ENDPOINTS.refresh, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh })
    })
    if (!r.ok) return false
    const data = await r.json() 
    if (data.access) {
        tokenStorage.set(data.access, refresh)
        return true
    }
    return false
}

export async function apiFetch(input: string, init: RequestInit = {}) {
    const access = tokenStorage.getAccess()
    const headers = new Headers(init.headers || {})
    if (access) headers.set('Authorization', `Bearer ${access}`)
    if (!headers.has('Content-Type')) headers.set('Content-Type', 'application/json')

    let res = await fetch(API_BASE + input, { ...init, headers })

    if (res.status === 401 && await refreshAccess()) {
        const h2 = new Headers(init.headers || {})
        const acc2 = tokenStorage.getAccess()
        h2.set('Authorization', `Bearer ${acc2}`)
        if (!h2.has('Content-Type')) h2.set('Content-Type', 'application/json')
        res = await fetch(API_BASE + input, { ...init, headers: h2 })
    }
    return res
}
