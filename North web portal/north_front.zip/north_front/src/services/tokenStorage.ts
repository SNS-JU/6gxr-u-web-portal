const ACCESS_KEY = 'auth.access';
const REFRESH_KEY = 'auth.refresh';

export const tokenStorage = {
  set(access: string, refresh: string) {
    localStorage.setItem(ACCESS_KEY, access);
    localStorage.setItem(REFRESH_KEY, refresh);
  },
  getAccess() {
    return localStorage.getItem(ACCESS_KEY) || '';
  },
  getRefresh() {
    return localStorage.getItem(REFRESH_KEY) || '';
  },
  clear() {
    localStorage.removeItem(ACCESS_KEY);
    localStorage.removeItem(REFRESH_KEY);
  },
};
