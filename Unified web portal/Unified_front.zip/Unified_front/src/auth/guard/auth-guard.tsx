/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import React, { useState, useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';

// The hook we created earlier
import { useAuthContext } from '../hooks/use-auth-context';

// A loading screen component from the "open" project
import LoadingScreen from 'src/components/loading/loading-screen';
// ----------------------------------------------------------------------

type AuthGuardProps = {
  children: React.ReactNode;
};

export default function AuthGuard({ children }: AuthGuardProps) {
  const { isAuthenticated, isInitialized } = useAuthContext();

  const { pathname } = useLocation();

  const [requestedLocation, setRequestedLocation] = useState<string | null>(null);

  // First, we wait for the AuthProvider to initialize (check localStorage)
  if (!isInitialized) {
    return <LoadingScreen />;
  }

  // If the user is not authenticated, redirect them to the login page
  if (!isAuthenticated) {
    if (pathname !== requestedLocation) {
      setRequestedLocation(pathname);
    }
    return <Navigate to="/login" />;
  }

  // If the user was trying to access a specific page before login,
  // redirect them back after they are authenticated.
  if (requestedLocation && pathname !== requestedLocation) {
    setRequestedLocation(null);
    return <Navigate to={requestedLocation} />;
  }

  // If everything is fine, render the requested page
  return <>{children}</>;
}
