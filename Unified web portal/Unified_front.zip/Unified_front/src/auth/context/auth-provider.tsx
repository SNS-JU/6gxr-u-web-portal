/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import React, { useReducer, useEffect, useCallback } from 'react';

import axiosInstance from 'src/utils/axios';
import { AuthContext } from './auth-context';
import { AuthState, User } from '../types';
import { STORAGE_KEY } from './jwt/constant';
import { signInWithPassword } from './jwt/utils';

type Action =
  | { type: 'INITIALIZE'; payload: { isAuthenticated: boolean; user: User | null } }
  | { type: 'LOGIN'; payload: { user: User } }
  | { type: 'LOGOUT' }
  | { type: 'SET_LOADING'; payload: boolean };

const initialState: AuthState = {
  user: null,
  isInitialized: false,
  isAuthenticated: false,
};

const reducer = (state: AuthState, action: Action): AuthState => {
  switch (action.type) {
    case 'INITIALIZE':
      return {
        ...state,
        isInitialized: true,
        isAuthenticated: action.payload.isAuthenticated,
        user: action.payload.user,
      };
    case 'LOGIN':
      return {
        ...state,
        isAuthenticated: true,
        user: action.payload.user,
      };
    case 'LOGOUT':
      return {
        ...state,
        isAuthenticated: false,
        user: null,
      };
    default:
      return state;
  }
};

// ----------------------------------------------------------------------

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const checkUserSession = useCallback(async () => {
    try {
      const accessToken = sessionStorage.getItem(STORAGE_KEY);

      if (accessToken) {
        const response = await axiosInstance.post('/users/api/users/profile/', { token: accessToken });

        const user = response.data;

        if (user && user.username) {
          sessionStorage.setItem('userId', user.id);
          dispatch({ type: 'INITIALIZE', payload: { isAuthenticated: true, user } });
        } else {
          dispatch({ type: 'INITIALIZE', payload: { isAuthenticated: false, user: null } });
        }
      } else {
        dispatch({ type: 'INITIALIZE', payload: { isAuthenticated: false, user: null } });
      }
    } catch (error) {
      console.error(error);
      dispatch({ type: 'INITIALIZE', payload: { isAuthenticated: false, user: null } });
    }
  }, []);

  useEffect(() => {
    checkUserSession();
  }, [checkUserSession]);

  // --- ACTIONS ---

  const login = async (username: string, password: string) => {
    try {
      const user = await signInWithPassword({ username, password });
      dispatch({ type: 'LOGIN', payload: { user } });
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    sessionStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem('userId'); 
    dispatch({ type: 'LOGOUT' });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout }}>{children}</AuthContext.Provider>
  );
}
