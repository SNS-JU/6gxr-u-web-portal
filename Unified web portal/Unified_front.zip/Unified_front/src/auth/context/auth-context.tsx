/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import { createContext } from 'react';
import { AuthContextType } from '../types';

export const AuthContext = createContext<AuthContextType | null>(null);