/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import axios from 'src/utils/axios';
import { STORAGE_KEY } from './constant';

// login + fetch profile
export const signInWithPassword = async ({ username, password }: Record<string, string>) => {
  const tokenRes = await axios.post('/users/api/token/', { username, password });
  const access = tokenRes.data?.access ?? tokenRes.data?.accessToken;
  const refresh = tokenRes.data?.refresh ?? tokenRes.data?.refreshToken;

  if (!access) {
    throw new Error('Token missing in response');
  }

  sessionStorage.setItem(STORAGE_KEY, access);
  if (refresh) sessionStorage.setItem(`${STORAGE_KEY}.refresh`, refresh);

  const profileRes = await axios.post('/users/api/users/profile/', { token: access });
  const user = profileRes.data;

  if (!user || !user.id) {
    throw new Error('Profile response is invalid');
  }

  sessionStorage.setItem('userId', user.id);
  return user;
};

export const signUp = async (data: Record<string, string>) => {
  const response = await axios.post('/api/auth/register', data);
  return response.data;
};
