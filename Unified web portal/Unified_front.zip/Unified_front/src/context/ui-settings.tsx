/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';

type NavLayout = 'rail' | 'sidebar' | 'top';
type NavColor = 'integrate' | 'apparent';

type UiSettings = {
  rtl: boolean;
  compact: boolean;
  navLayout: NavLayout;
  navColor: NavColor;
};

type Ctx = {
  settings: UiSettings;
  setSettings: React.Dispatch<React.SetStateAction<UiSettings>>;
  toggleRtl: () => void;
  toggleCompact: () => void;
  setNavLayout: (v: NavLayout) => void;
  setNavColor: (v: NavColor) => void;
};

const STORAGE_KEY = 'ui-settings:v1';

const DEFAULT: UiSettings = {
  rtl: false,
  compact: false,
  navLayout: 'sidebar',
  navColor: 'integrate',
};

const UiSettingsContext = createContext<Ctx | null>(null);

export function UiSettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<UiSettings>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as UiSettings) : DEFAULT;
    } catch {
      return DEFAULT;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    } catch {}
    document.documentElement.dir = settings.rtl ? 'rtl' : 'ltr';
  }, [settings]);

  const value = useMemo<Ctx>(
    () => ({
      settings,
      setSettings,
      toggleRtl: () => setSettings((s) => ({ ...s, rtl: !s.rtl })),
      toggleCompact: () => setSettings((s) => ({ ...s, compact: !s.compact })),
      setNavLayout: (v) => setSettings((s) => ({ ...s, navLayout: v })),
      setNavColor: (v) => setSettings((s) => ({ ...s, navColor: v })),
    }),
    [settings]
  );

  return <UiSettingsContext.Provider value={value}>{children}</UiSettingsContext.Provider>;
}

export function useUiSettings() {
  const ctx = useContext(UiSettingsContext);
  if (!ctx) throw new Error('useUiSettings must be used within UiSettingsProvider');
  return ctx;
}
