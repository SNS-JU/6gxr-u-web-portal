export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://193.166.32.46:8000';
// export const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:8000';
export const ENDPOINTS = {
  token: '/users/api/token/',
  refresh: '/users/api/token/refresh/',
  register: '/users/api/users/register/',
  profile: '/users/api/users/profile/',
  profileUpdate: '/users/api/users/edit/',
  home: {
    nst: '/home/api/trials/',
    newNstUpdate: `/home/api/trials/`,
    newDeleteNst: `/home/api/trials/`,
  },
  auth: {
    changeReq: '/users/api/passresreq/',
    verifCode: '/users/api/codeverification/',
    changePass: '/users/api/Passresetconfirmtion/',
  },
};
