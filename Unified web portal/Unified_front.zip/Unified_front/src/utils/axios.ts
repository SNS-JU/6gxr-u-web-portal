/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import axios from 'axios';
import { STORAGE_KEY } from 'src/auth/context/jwt/constant';

const axiosInstance = axios.create({
  baseURL: 'http://193.166.32.46:8000', 
  // baseURL: 'http://127.0.0.1:8000', 
});

axiosInstance.interceptors.request.use((config) => {
  const accessToken = sessionStorage.getItem(STORAGE_KEY);
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`;
  }
  return config;
});

export default axiosInstance;
