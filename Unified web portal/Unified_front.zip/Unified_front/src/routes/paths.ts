export const paths = {
  dashboard: {
    nstList: '/dashboard/nst-list',
    addNst: '/dashboard/nst-add',
    editNst: (id: string) => `/dashboard/nst/${id}/edit`,
    about: '/dashboard/about',
    profile: '/dashboard/profile',
  },
  auth: {
    login: '/login',
    register: '/register',
    profile: '/users/api/users/profile/',
    forgot: '/forgot-password',
  },
};
