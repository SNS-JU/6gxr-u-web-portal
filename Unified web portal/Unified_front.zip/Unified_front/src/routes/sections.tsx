/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import type { RouteObject } from 'react-router';

import { lazy, Suspense } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { varAlpha } from 'minimal-shared/utils';

import Box from '@mui/material/Box';
import LinearProgress, { linearProgressClasses } from '@mui/material/LinearProgress';

import { DashboardLayout } from 'src/layouts/dashboard';
import AuthGuard from 'src/auth/guard/auth-guard';
import NstListPage from 'src/pages/nst-list';
import NstAddPage from 'src/pages/nst-add';
import NstEditPage from 'src/pages/nst-edit';
import SignUpPage from 'src/pages/sign-up';
import AboutPage from 'src/pages/about';
import Privacy from 'src/pages/terms';
import ForgotPasswordView from 'src/sections/auth/forgot-password-view';
import { paths } from './paths';

// ----------------------------------------------------------------------

export const SignInPage = lazy(() => import('src/pages/sign-in'));
export const Page404 = lazy(() => import('src/pages/page-not-found'));
export const ProfilePage = lazy(() => import('src/pages/profile'));

const renderFallback = () => (
  <Box
    sx={{
      display: 'flex',
      flex: '1 1 auto',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    <LinearProgress
      sx={{
        width: 1,
        maxWidth: 320,
        bgcolor: (theme) => varAlpha(theme.vars.palette.text.primaryChannel, 0.16),
        [`& .${linearProgressClasses.bar}`]: { bgcolor: 'text.primary' },
      }}
    />
  </Box>
);

export const routesSection: RouteObject[] = [
  { index: true, element: <Navigate to="/login" replace /> },
  {
    path: 'dashboard',
    element: (
      <AuthGuard>
        <DashboardLayout>
          <Suspense fallback={renderFallback()}>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      </AuthGuard>
    ),
    children: [
      { path: 'nst-list', element: <NstListPage /> },
      { path: 'nst-add', element: <NstAddPage /> },
      { path: 'nst/:id/edit', element: <NstEditPage /> },
      { path: 'about', element: <AboutPage /> },
      {
        path: 'profile',
        element: <ProfilePage />,
      },
    ],
  },
  {
    path: 'login',
    element: <SignInPage />,
  },
  {
    path: 'register',
    element: <SignUpPage />,
  },
  {
    path: '404',
    element: <Page404 />,
  },
  {
    path: 'terms',
    element: <Privacy />,
  },
  { path: '*', element: <Page404 /> },
  {
    path: paths.auth.forgot,
    element: <ForgotPasswordView />,
  },
];
