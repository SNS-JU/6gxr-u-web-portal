/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import Lottie from 'lottie-react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';

import Box from '@mui/material/Box';
import { Grid } from '@mui/material';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import InputAdornment from '@mui/material/InputAdornment';
import { Visibility, VisibilityOff } from '@mui/icons-material';

// eslint-disable-next-line import/no-unresolved
import animationData from 'src/lotties/manboot-register.json';
import { useNotification } from 'src/context/notification-context';

import { useAuthContext } from '../../auth/hooks/use-auth-context';
import { useThemeMode } from 'src/theme';
import { useTheme } from '@mui/material';

export default function SignInPage() {
  const theme = useTheme();
  const navigate = useNavigate();
  const { isAuthenticated, logout, login } = useAuthContext();
  const { showNotification } = useNotification();

  const [values, setValues] = React.useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const isLight = theme.palette.mode === 'light';

  React.useEffect(() => {
    if (isAuthenticated) navigate('/dashboard/nst-list', { replace: true });
  }, [isAuthenticated, navigate]);

  const onChange = (field: 'username' | 'password') => (e: React.ChangeEvent<HTMLInputElement>) =>
    setValues((s) => ({ ...s, [field]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!values.username || values.password.length === 0) {
      showNotification('Username And Password Required!', 'warning');
      return;
    }
    try {
      setLoading(true);
      await login(values.username, values.password);
      showNotification('Welcome back!', 'success');
      navigate('/dashboard/nst-list', { replace: true });
    } catch (err: any) {
      if (err?.status === 401) {
        showNotification(
          err?.response?.data?.detail || 'No Active User With Given Credentials',
          'error'
        );
      } else {
        showNotification(err?.response?.data?.detail || 'Failed To Login', 'error');
      }
      // showNotification(err?.message || 'Login failed', 'error');
    } finally {
      setLoading(false);
    }
  };

  const leftLogoSrc = '/logo22.png';

  return (
    <>
      <Box
        sx={{
          position: 'fixed',
          top: { xs: 12, md: 16 },
          left: { xs: 12, md: 16 },
          zIndex: (t) => t.zIndex.appBar + 1,
        }}
      >
        <Box
          component={RouterLink}
          to="/"
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 1,
            px: 1.25,
            py: 0.75,
            borderRadius: 2,
            textDecoration: 'none',
            border: '1px solid',
            borderColor: 'divider',
            backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.7 : 0.5})`,
            backdropFilter: 'saturate(120%) blur(6px)',
            boxShadow: isLight ? '0 6px 18px rgba(15,23,42,0.08)' : '0 8px 24px rgba(0,0,0,0.36)',
          }}
        >
          <Box
            component="img"
            src={leftLogoSrc}
            alt="Company"
            sx={{ height: 28, display: 'block' }}
          />
        </Box>
      </Box>

      <Box
        sx={{
          position: 'fixed',
          top: { xs: 12, md: 16 },
          right: { xs: 12, md: 16 },
          zIndex: (t) => t.zIndex.appBar + 1,
        }}
      >
        <Box
          component="a"
          href="https://6g-xr.eu/"
          target="_blank"
          rel="noopener"
          sx={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 1,
            px: 1.25,
            py: 0.75,
            borderRadius: 1,
            textDecoration: 'none',
            border: '1px solid',
            borderColor: 'divider',
            backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.7 : 0.5})`,
            backdropFilter: 'saturate(120%) blur(6px)',
            boxShadow: isLight ? '0 6px 18px rgba(15,23,42,0.08)' : '0 8px 24px rgba(0,0,0,0.36)',
          }}
        >
          <Box
            alt="Partner"
            sx={{ fontSize: 15, color: 'black', height: 28, display: 'block', fontWeight: 'bold' }}
          >
            6G-XR Home Page
          </Box>
        </Box>
      </Box>
      <Grid display={'flex'} flexDirection={'row'} sx={{ minHeight: '100vh' }}>
        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            px: { xs: 3, md: 6 },
            background: (t) =>
              t.palette.mode === 'light'
                ? 'linear-gradient(180deg,#F4F7FF, #e4e4e4ff)'
                : 'linear-gradient(180deg,#0B1220, #e9e3dbff)',
          }}
        >
          <Box sx={{ width: '100%', maxWidth: 520 }}>
            <Typography variant="h3" fontWeight={700} gutterBottom textAlign="center">
              Welcome to Unified Portal
            </Typography>
            <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }} textAlign="center">
              Trial Management
            </Typography>
            <Box sx={{ mx: 'auto' }}>
              <Lottie animationData={animationData as any} loop style={{ maxWidth: 420 }} />
            </Box>
          </Box>
        </Grid>

        <Grid
          item
          xs={12}
          md={6}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: {
              xs: 'center',
              md: 'center',
            },

            minWidth: '78%',
            p: { xs: 3, md: 8 },
          }}
        >
          <Box
            component={Paper}
            elevation={0}
            sx={{
              p: { xs: 2, md: 4 },
              width: '100%',
              maxWidth: 480,
              border: '1px solid',
              borderColor: 'divider',
              borderRadius: 2,
            }}
          >
            <Typography variant="h5" fontWeight={700} sx={{ mb: 3 }}>
              Sign in to your account
            </Typography>

            <Box component="form" noValidate onSubmit={onSubmit}>
              <TextField
                label="Username"
                fullWidth
                margin="normal"
                value={values.username}
                onChange={onChange('username')}
              />

              <TextField
                label="Password"
                type={showPassword ? 'text' : 'password'}
                fullWidth
                margin="normal"
                value={values.password}
                onChange={onChange('password')}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setShowPassword((s) => !s)}
                        edge="end"
                        aria-label="toggle password"
                      >
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />

              <Box sx={{ mt: 1.5 }}>
                <Typography
                  component={RouterLink}
                  to="/forgot-password"
                  sx={{ textDecoration: 'underline', fontWeight: 'bold' }}
                >
                  Forgot password?
                </Typography>
              </Box>

              <Button type="submit" variant="contained" fullWidth sx={{ mt: 3 }} disabled={loading}>
                {loading ? 'Signing in…' : 'Sign In'}
              </Button>

              <Box sx={{ mt: 2 }}>
                <Typography variant="body2">
                  Don’t Have an Account?{' '}
                  <Typography
                    component={RouterLink}
                    to="/register"
                    sx={{ textDecoration: 'underline', fontWeight: 'bold', fontSize: '0.875rem' }}
                  >
                    Sign Up Now
                  </Typography>
                </Typography>
              </Box>
            </Box>
          </Box>
        </Grid>
      </Grid>
    </>
  );
}
