/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import { useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';

import {
  Box,
  Stack,
  Alert,
  Card,
  CardContent,
  CardHeader,
  Typography,
  TextField,
  InputAdornment,
  IconButton,
  Grid,
} from '@mui/material';
import { LoadingButton } from '@mui/lab';
import { Link as RouterLink, useNavigate } from 'react-router-dom';

import { Iconify } from 'src/components/iconify';
import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';
import { paths } from 'src/routes/paths';
import { useNotification } from 'src/context/notification-context';
import Lottie from 'lottie-react';
import animationData from 'src/lotties/manboot-register.json';
import { PASSWORD_HINT, validatePasswordComplexity } from 'src/utils/validators';

// ---------- types
type FormValues = {
  email: string;
  username: string;
  code: string;
  password: string;
};

const schema = yup.object({
  email: yup.string().email('Invalid email').required('Email is required'),
  username: yup.string().required('Username is required'),
  code: yup.string().default(''),
  password: yup.string().default(''),
});

export default function ForgotPasswordView() {
  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const [step, setStep] = useState<0 | 1 | 2>(0);
  const [showPass, setShowPass] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const methods = useForm<FormValues>({
    resolver: yupResolver(schema),
    mode: 'onBlur',
    defaultValues: {
      email: '',
      username: '',
      code: '',
      password: '',
    },
  });

  const {
    control,
    handleSubmit,
    getValues,
    formState: { isSubmitting },
  } = methods;

  const onSubmit = handleSubmit(async () => {
    try {
      if (step === 0) {
        const { email, username } = getValues();
        await axiosInstance.post(
          ENDPOINTS.auth.changeReq,
          { email, username },
          { headers: { Authorization: null } }
        );
        showNotification('Verification code sent to your email', 'success');
        setStep(1);
        setErrorMsg('');
        return;
      }

      if (step === 1) {
        const { email, code } = getValues();
        await axiosInstance.post(
          ENDPOINTS.auth.verifCode,
          { email, code },
          { headers: { Authorization: null } }
        );
        showNotification('Code verified. Please set a new password.', 'success');
        setStep(2);
        setErrorMsg('');
        return;
      }

      if (step === 2) {
        const { email, code, password } = getValues();
        if (!validatePasswordComplexity(password)) {
          showNotification(PASSWORD_HINT, 'warning');
          return;
        }
        await axiosInstance.post(
          ENDPOINTS.auth.changePass,
          { email, code, new_password: password },
          { headers: { Authorization: null } }
        );
        showNotification('Password changed successfully', 'success');
        navigate(paths.auth.login, { replace: true });
      }
    } catch (err: any) {
      const msg =
        err?.response?.data?.detail ||
        err?.response?.data?.message ||
        err?.message ||
        'Something went wrong';
      setErrorMsg(msg);
      showNotification(msg, 'error');
    }
  });

  const renderHead = (
    <Stack spacing={1} sx={{ mb: 3 }}>
      <Typography variant="h4" fontWeight={800}>
        {step === 0 && 'Forgot Password'}
        {step === 1 && 'Verify Code'}
        {step === 2 && 'Set New Password'}
      </Typography>
      <Typography variant="body2" color="text.secondary">
        {step === 0 && 'Enter your email and username to receive the code.'}
        {step === 1 && 'Enter the verification code sent to your email.'}
        {step === 2 && 'Choose a new password for your account.'}
      </Typography>
    </Stack>
  );

  return (
    <Grid display={'flex'} flexDirection={'row'} sx={{ minHeight: '100vh' }}>
      <Grid
        item
        xs={12}
        md={6}
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          px: { xs: 3, md: 6 },
          background: (t) =>
            t.palette.mode === 'light'
              ? 'linear-gradient(180deg,#F4F7FF, #e4e4e4ff)'
              : 'linear-gradient(180deg,#0B1220, #e9e3dbff)',
        }}
      >
        <Box sx={{ width: '100%', maxWidth: 520 }}>
          <Typography variant="h3" fontWeight={700} gutterBottom textAlign="center">
            Welcome to Unified Portal
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }} textAlign="center">
            Trial Management
          </Typography>
          <Box sx={{ mx: 'auto' }}>
            <Lottie animationData={animationData as any} loop style={{ maxWidth: 420 }} />
          </Box>
        </Box>
      </Grid>

      <Box
        sx={{
          maxWidth: '100%',
          mx: 'auto',
          py: 6,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          textAlign: 'center',
          justifyContent:'center'
        }}
      >
        {renderHead}

        {!!errorMsg && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {errorMsg}
          </Alert>
        )}

        <Card
          variant="outlined"
          sx={{
            borderRadius: 3,
            width: '480px',
            display: 'flex',
            flexDirection: 'column',
            textAlign: 'center',
          }}
        >
          <CardHeader
            title={step === 0 ? 'Step 1 of 3' : step === 1 ? 'Step 2 of 3' : 'Step 3 of 3'}
            sx={{ pb: 0, '& .MuiCardHeader-title': { fontWeight: 800 } }}
          />
          <CardContent sx={{ pt: 2 }}>
            <Stack component="form" spacing={2.5} onSubmit={onSubmit} noValidate>
              {step === 0 && (
                <>
                  <Controller
                    name="email"
                    control={control}
                    render={({ field, fieldState }) => (
                      <TextField
                        {...field}
                        type="email"
                        label="Email"
                        fullWidth
                        error={!!fieldState.error}
                        helperText={fieldState.error?.message}
                      />
                    )}
                  />
                  <Controller
                    name="username"
                    control={control}
                    render={({ field, fieldState }) => (
                      <TextField
                        {...field}
                        label="Username"
                        fullWidth
                        error={!!fieldState.error}
                        helperText={fieldState.error?.message}
                      />
                    )}
                  />
                </>
              )}

              {step === 1 && (
                <Controller
                  name="code"
                  control={control}
                  rules={{ required: 'Code is required' }}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      label="Verification Code"
                      fullWidth
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                    />
                  )}
                />
              )}

              {step === 2 && (
                <Controller
                  name="password"
                  control={control}
                  rules={{ required: 'Password is required', minLength: 6 }}
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      label="New Password"
                      type={showPass ? 'text' : 'password'}
                      fullWidth
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message || '6+ characters'}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowPass((s) => !s)} edge="end">
                              <Iconify
                                icon={showPass ? 'solar:eye-bold' : 'solar:eye-closed-bold'}
                              />
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  )}
                />
              )}

              <LoadingButton
                fullWidth
                size="large"
                type="submit"
                variant="contained"
                loading={isSubmitting}
              >
                {step === 0 && 'Get Verification Code'}
                {step === 1 && 'Verify Code'}
                {step === 2 && 'Submit New Password'}
              </LoadingButton>

              <Typography variant="body2" sx={{ textAlign: 'center' }}>
                Don’t have an account?{' '}
                <Box
                  component={RouterLink}
                  to={paths.auth.register}
                  sx={{ textDecoration: 'none', fontWeight: 700 }}
                >
                  Sign up
                </Box>
              </Typography>
            </Stack>
          </CardContent>
        </Card>
      </Box>
    </Grid>
  );
}
