/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import { Controller, useForm } from 'react-hook-form';
import * as yup from 'yup';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigate } from 'react-router-dom';
import dayjs, { Dayjs } from 'dayjs';

import {
  Container,
  Card,
  CardHeader,
  CardContent,
  TextField,
  MenuItem,
  Divider,
  Typography,
  Box,
  Stack,
  IconButton,
  InputAdornment,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import EventIcon from '@mui/icons-material/Event';
import { LoadingButton } from '@mui/lab';

import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { MobileDatePicker } from '@mui/x-date-pickers/MobileDatePicker';
import { MobileTimePicker } from '@mui/x-date-pickers/MobileTimePicker';
import ClearIcon from '@mui/icons-material/Clear';

import axiosInstance from 'src/utils/axios';
import { useNotification } from 'src/context/notification-context';
import { useUiSettings } from 'src/context/ui-settings';
import { paths } from 'src/routes/paths';
import { ENDPOINTS } from 'src/config';

// ---------------- Types & helpers ----------------
type FormValues = {
  name: string;
  start_date: Dayjs | null;
  end_date: Dayjs | null;
  facility: string;
  description: string;
};

const schema: yup.Schema<FormValues> = yup.object({
  name: yup.string().required('Name is required'),
  facility: yup.string().required('Facility is required'),
  start_date: yup
    .mixed<Dayjs | null>()
    .required('Start time is required')
    .test('valid-start', 'Invalid start time', (v) => !!v && dayjs.isDayjs(v) && v.isValid()),
  end_date: yup
    .mixed<Dayjs | null>()
    .required('End time is required')
    .test('valid-end', 'Invalid end time', (v) => !!v && dayjs.isDayjs(v) && v.isValid())
    .test('after-start', 'End time must be after start time', function (val) {
      const s = this.parent.start_date as Dayjs | null;
      return !!val && !!s && val.isAfter(s);
    }),
  description: yup.string().required('Description is required').default(''),
});

const FACILITY_OPTIONS = [
  { value: 'Oulu', label: 'Oulu' },
  { value: 'South', label: 'South' },
];

const toApi = (d: Dayjs | null) => (d ? d.format('YYYY-MM-DDTHH:mm:ss') + '.000000' : '');
const displayFmt = (d: Dayjs | null) => (d ? d.format('M/D/YYYY h:mm A') : '');

// ---------- Two-step DateTime (Calendar → Analog clock) ----------
function TwoStepDateTimeField({
  label,
  value,
  onChange,
  size = 'medium',
  error,
  helperText,
  minDateTime,
  sx,
}: {
  label: string;
  value: Dayjs | null;
  onChange: (v: Dayjs | null) => void;
  size?: 'small' | 'medium';
  error?: boolean;
  helperText?: React.ReactNode;
  minDateTime?: Dayjs | null;
  sx?: any;
}) {
  const [openDate, setOpenDate] = React.useState(false);
  const [openTime, setOpenTime] = React.useState(false);
  const [dateDraft, setDateDraft] = React.useState<Dayjs | null>(null);
  const [timeDraft, setTimeDraft] = React.useState<Dayjs | null>(null);

  const startFlow = () => {
    setDateDraft(value ?? dayjs());
    setOpenDate(true);
  };

  const acceptDate = () => {
    if (!dateDraft) {
      setOpenDate(false);
      return;
    }
    setOpenDate(false);
    setOpenTime(true);
  };

  const acceptTime = () => {
    if (!dateDraft && !timeDraft) {
      setOpenTime(false);
      return;
    }
    const baseDate = dateDraft ?? value ?? dayjs();
    const srcTime = timeDraft ?? value ?? dayjs();

    const final = baseDate.hour(srcTime.hour()).minute(srcTime.minute()).second(0).millisecond(0);

    onChange(final);
    setOpenTime(false);
    setDateDraft(null);
    setTimeDraft(null);
  };

  const sameDayAsMin = !!minDateTime && !!dateDraft && dateDraft.isSame(minDateTime, 'day');

  return (
    <>
      <TextField
        fullWidth
        size={size}
        label={label}
        value={displayFmt(value)}
        onClick={startFlow}
        InputProps={{
          readOnly: true,
          endAdornment: (
            <InputAdornment position="end">
              {value && (
                <IconButton
                  size={size}
                  onClick={(e) => {
                    e.stopPropagation();
                    onChange(null);
                  }}
                >
                  <ClearIcon />
                </IconButton>
              )}
              <IconButton size={size} onClick={startFlow}>
                <EventIcon />
              </IconButton>
            </InputAdornment>
          ),
        }}
        error={!!error}
        helperText={helperText}
        sx={sx}
      />

      <MobileDatePicker
        open={openDate}
        onClose={() => setOpenDate(false)}
        value={dateDraft}
        onChange={(d) => setDateDraft(d)}
        onAccept={acceptDate}
        minDate={minDateTime ?? undefined}
        slotProps={{
          textField: { sx: { display: 'none' } },
          actionBar: { actions: ['cancel', 'accept'] },
        }}
      />

      <MobileTimePicker
        open={openTime}
        onClose={() => setOpenTime(false)}
        value={timeDraft ?? value ?? dayjs()}
        onChange={(t) => setTimeDraft(t)}
        onAccept={acceptTime}
        ampm
        ampmInClock
        minutesStep={1}
        views={['hours', 'minutes']}
        minTime={sameDayAsMin ? minDateTime : undefined}
        slotProps={{
          textField: { sx: { display: 'none' } },
          actionBar: { actions: ['cancel', 'accept'] },
        }}
      />
    </>
  );
}

// ---------------- Component ----------------
export default function NstAddView() {
  const { settings } = useUiSettings();
  const size = settings.compact ? 'small' : 'medium';

  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const methods = useForm<FormValues>({
    resolver: yupResolver(schema),
    mode: 'onBlur',
    defaultValues: {
      name: '',
      start_date: null,
      end_date: null,
      facility: '',
      description: '',
    },
  });

  const {
    control,
    handleSubmit,
    watch,
    formState: { isSubmitting },
  } = methods;

  const startVal = watch('start_date');

  const fieldSx = {
    '& .MuiOutlinedInput-root': { height: 56 },
  };

  const now = dayjs();
  const minEndDateTime = startVal && startVal.isAfter(now) ? startVal : now;

  const onSubmit = handleSubmit(async (values) => {
    const payload = {
      name: values.name,
      start_date: toApi(values.start_date),
      end_date: toApi(values.end_date),
      facility: values.facility,
      description: values.description,
      user: Number(sessionStorage.getItem('userId')),
      timezone: 'Europe/Helsinki',
    };

    try {
      await axiosInstance.post(ENDPOINTS.home.nst, payload);
      showNotification('Trial created successfully', 'success');
      navigate(paths.dashboard.nstList, {
        replace: true,
        state: { refresh: Date.now() },
      });
    } catch (err: any) {
      showNotification(err?.response?.data?.message || 'Failed to create trial', 'error');
    }
  });

  return (
    <Container maxWidth="lg" sx={{ pb: 6 }}>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h4" fontWeight={700}>
          Add Trial
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Create a new trial with time window and facility.
        </Typography>
      </Box>

      <Card
        sx={{
          p: 4,
          borderRadius: 1,
          overflow: 'hidden',
          border: '1px solid',
          borderColor: 'divider',
          boxShadow: (t) => t.shadows[settings.navColor === 'apparent' ? 2 : 1],
        }}
      >
        <CardHeader
          avatar={
            <Box
              sx={{
                width: 40,
                height: 40,
                borderRadius: '50%',
                display: 'grid',
                placeItems: 'center',
                bgcolor: (t) => t.palette.primary.light,
                color: (t) => t.palette.primary.contrastText,
              }}
            >
              <AddCircleOutlineIcon fontSize="small" />
            </Box>
          }
          title="New Trial"
          subheader="Fill the required fields and submit"
          sx={{
            '& .MuiCardHeader-title': { fontWeight: 700 },
            '& .MuiCardHeader-subheader': { color: 'text.secondary' },
            py: 2,
          }}
        />

        <Divider />

        <CardContent sx={{ p: { xs: 2, md: 3 } }}>
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Box component="form" noValidate onSubmit={onSubmit}>
              <Box
                sx={{
                  display: 'grid',
                  gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
                  gap: { xs: 2, md: 2.5 },
                  alignItems: 'center',
                }}
              >
                <Controller
                  control={control}
                  name="name"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      size={size}
                      label="Trial Name"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="start_date"
                  render={({ field, fieldState }) => (
                    <TwoStepDateTimeField
                      label="Start Time"
                      value={field.value}
                      onChange={field.onChange}
                      size={size}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      minDateTime={now}
                      sx={fieldSx}
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="end_date"
                  render={({ field, fieldState }) => (
                    <TwoStepDateTimeField
                      label="End Time"
                      value={field.value}
                      onChange={field.onChange}
                      size={size}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      minDateTime={minEndDateTime}
                      sx={fieldSx}
                    />
                  )}
                />

                <Controller
                  control={control}
                  name="facility"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      fullWidth
                      select
                      size={size}
                      label="Facility Option"
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      sx={fieldSx}
                    >
                      {FACILITY_OPTIONS.map((opt) => (
                        <MenuItem key={opt.value} value={opt.value}>
                          {opt.label}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />

                <Controller
                  control={control}
                  name="description"
                  render={({ field, fieldState }) => (
                    <TextField
                      {...field}
                      label="Description"
                      size={size}
                      fullWidth
                      sx={{ ...fieldSx, gridColumn: '1 / -1' }}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                    />
                  )}
                />
              </Box>
              <Stack alignItems="flex-end" sx={{ mt: 3 }}>
                <LoadingButton type="submit" variant="contained" loading={isSubmitting} size={size}>
                  Create Trial
                </LoadingButton>
              </Stack>
            </Box>
          </LocalizationProvider>
        </CardContent>
      </Card>
    </Container>
  );
}
