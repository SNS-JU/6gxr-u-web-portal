/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import { Theme } from '@mui/material/styles';

import {
  Container,
  Card,
  Alert,
  Tooltip,
  IconButton,
  Stack,
  Typography,
  Box,
  LinearProgress,
  Button,
  Link,
  Chip,
  Divider,
} from '@mui/material';
import { ArrowLeftRounded, ArrowRightRounded } from '@mui/icons-material';
import { DataGrid, GridColDef } from '@mui/x-data-grid';

import { paths } from 'src/routes/paths';
import { NstList } from 'src/types/nst-list';
import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';

import { Iconify } from 'src/components/iconify';
import { useNotification } from 'src/context/notification-context';
import ConfirmDialog from 'src/layouts/components/confirm-dialog/ConfirmDialog';
import HeaderListPages from './components/HeaderListPages';
import ViewDrawerForm from './components/ViewDrawerForm';
import { useUiSettings } from 'src/context/ui-settings';
import { useLocation } from 'react-router-dom';

type TrialsResponse = {
  previous?: string | null;
  next?: string | null;
  count: number;
  results: NstList[];
  unified_end_time?: string;
  unified_start_time?: string;
};

export default function NstListView() {
  const location = useLocation();
  const { settings } = useUiSettings();
  const navigate = useNavigate();
  const { showNotification } = useNotification();

  const [page, setPage] = useState(1);

  const [data, setData] = useState<TrialsResponse>({
    previous: null,
    next: null,
    count: 0,
    results: [],
  });
  const [messageBox, setMessageBox] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerData, setDrawerData] = useState<NstList | null>(null);

  const [openConfirm, setOpenConfirm] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<NstList | null>(null);

  const [isDeleting, setIsDeleting] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await axiosInstance.post(`/home/api/gettrials/?page=${page}`, {
        trial_id: '',
      });
      const payload: TrialsResponse = res?.data ?? { count: 0, results: [] };

      const results = (payload.results ?? []).map((r: any) => ({
        ...r,
        core_id: r.trial_id ?? r.id,
      }));

      setData({
        previous: payload.previous ?? null,
        next: payload.next ?? null,
        count: payload.count ?? 0,
        results,
        unified_end_time: payload.unified_end_time,
        unified_start_time: payload.unified_start_time,
      });

      if (payload.unified_end_time) sessionStorage.setItem('uni_end', payload.unified_end_time);
      if (payload.unified_start_time) sessionStorage.setItem('uni_str', payload.unified_start_time);
    } catch (err: any) {
      showNotification(err?.message || 'Failed to fetch list', 'error');
      setData({ previous: null, next: null, count: 0, results: [] });
    } finally {
      setLoading(false);
    }
  }, [page, showNotification]);

  useEffect(() => {
    if ((location.state as any)?.refresh) {
      fetchData();
      navigate(location.pathname, { replace: true, state: {} });
    }
    console.log('\n before \n');
    fetchData();
    console.log('\n after \n');
    axiosInstance
      .get<{ message: string }>('/home/api/runningnstmessage/')
      .then((r) => setMessageBox(r?.data?.message))
      .catch(() => {});
  }, [location.state, navigate, location.pathname, fetchData]);

  const handleOpenConfirm = (row: NstList) => {
    setDeleteTarget(row);
    setOpenConfirm(true);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setIsDeleting(true);
    try {
      const res = await axiosInstance.delete(ENDPOINTS.home?.newDeleteNst, {
        data: {
          trial_id: Number(deleteTarget.core_id),
          user: Number(sessionStorage.getItem('userId')),
        },
      });
      showNotification(res?.data?.message || 'Deleted', 'success');

      setData((prev) => ({
        ...prev,
        results: prev.results.filter((it) => it.trial_id !== deleteTarget.trial_id),
        count: Math.max(0, (prev.count ?? 0) - 1),
      }));
    } catch (err: any) {
      showNotification(err?.message || 'Failed to delete', 'error');
    } finally {
      setIsDeleting(false);   // ⬅️ added (end locking and loading)
      setOpenConfirm(false);
      setDeleteTarget(null);
    }
  };

  const columns = useMemo<GridColDef<NstList>[]>(() => {
    const facilityCell = (row: NstList) => {
      const facility = row.facility;
      let linkText = '';
      let linkUrl = '';

      const trialId = row.core_id ?? row.trial_id;

      if (facility === 'Oulu') {
        linkText = 'Oulu';
        linkUrl = `http://193.166.32.46:8086/login?trial=${encodeURIComponent(String(trialId))}&facility=oulu`;
        // linkUrl = `http://127.0.0.1:3040/login?trial=${encodeURIComponent(String(trialId))}&facility=oulu`;
      } else if (facility === 'South') {
        linkText = 'South';
        linkUrl = `http://193.166.32.46:4040/login?trial=${row.trial_id}`;
      }

      const endTime = new Date(row.end_date as any);
      const isExpired = new Date() > endTime;

      const handleClick = (e: React.MouseEvent) => {
        e.preventDefault();
        if (isExpired) {
          showNotification('The time is over.', 'error');
        } else if (linkUrl) {
          window.open(linkUrl, '_blank');
        }
      };

      return (
        <Tooltip
          title={
            isExpired
              ? 'The link is expired'
              : `Redirect to ${linkText === 'Oulu' ? 'North' : 'South'} web portal`
          }
          componentsProps={{
            tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
            arrow: { sx: { color: '#292929ff' } },
          }}
          arrow
        >
          <span>
            <Link
              href={isExpired ? '#' : linkUrl}
              onClick={handleClick}
              sx={{
                color: isExpired ? 'text.disabled' : 'primary.main',
                pointerEvents: linkUrl ? 'auto' : 'none',
                cursor: linkUrl ? 'pointer' : 'default',
                fontWeight: 600,
              }}
              underline="hover"
            >
              {linkText || '-'}
            </Link>
          </span>
        </Tooltip>
      );
    };

    const actionButtons = (row: NstList) => {
      const endTime = new Date(row.end_date as any);
      const disabled = new Date() > endTime;
      const size = settings.compact ? 'small' : 'medium';

      return (
        <Stack direction="row" spacing={0.5} justifyContent="center">
          <Tooltip
            title={disabled ? 'Edit is expired' : 'Edit the trial'}
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <IconButton
              size={size}
              onClick={() => navigate(paths.dashboard.editNst(row.trial_id))}
              disabled={disabled}
            >
              <Iconify icon="solar:pen-bold" />
            </IconButton>
          </Tooltip>

          <Tooltip
            title={disabled ? 'View is expired' : 'View'}
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <IconButton
              size={size}
              onClick={() => {
                setDrawerData({ ...row, core_id: row.core_id ?? row.trial_id });
                setDrawerOpen(true);
              }}
              disabled={disabled}
            >
              <Iconify icon="hugeicons:view" />
            </IconButton>
          </Tooltip>

          <Tooltip
            title="Delete the trial"
            componentsProps={{
              tooltip: { sx: { bgcolor: '#292929ff', color: '#FFFFFF', fontWeight: 600 } },
              arrow: { sx: { color: '#292929ff' } },
            }}
            arrow
          >
            <IconButton size={size} onClick={() => handleOpenConfirm(row)}>
              <Iconify icon="ic:round-delete" />
            </IconButton>
          </Tooltip>
        </Stack>
      );
    };

    return [
      {
        field: 'trial_id',
        headerName: 'Trial ID',
        minWidth: 110,
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'name',
        headerName: 'Name',
        flex: 1,
        minWidth: 160,
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'start_date',
        headerName: 'Start Time',
        width: 200,
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'end_date',
        headerName: 'End Time',
        width: 200,
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'facility',
        headerName: 'Facility',
        width: 140,
        align: 'center',
        headerAlign: 'center',
        renderCell: ({ row }) => facilityCell(row),
        sortable: false,
        filterable: false,
      },
      {
        field: 'description',
        headerName: 'Description',
        flex: 1,
        minWidth: 160,
        align: 'center',
        headerAlign: 'center',
      },
      {
        field: 'action',
        headerName: 'Action',
        width: 220,
        align: 'center',
        headerAlign: 'center',
        sortable: false,
        filterable: false,
        renderCell: ({ row }) => actionButtons(row),
      },
    ];
  }, [navigate, settings.compact, showNotification]);

  const gridSx = (theme: Theme) => {
    const isLight = theme.palette.mode === 'light';

    return {
      '--DataGrid-rowBorderColor': 'transparent',
      '--DataGrid-hoveredRowBackground': `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.1})`,
      '--DataGrid-selectedRowBackground': `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.12 : 0.2})`,
      '--DataGrid-headerColor': theme.vars
        ? theme.vars.palette.text.primary
        : theme.palette.text.primary,

      border: '1px solid',
      borderColor: 'divider',
      borderRadius: 2,
      overflow: 'hidden',

      '& .MuiDataGrid-columnHeaders': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.14})`,
        color: theme.vars ? theme.vars.palette.text.primary : theme.palette.text.primary,
        fontWeight: 700,
        borderBottom: '1px solid',
        borderColor: 'divider',
        backdropFilter: 'saturate(120%) blur(6px)',
      },

      '& .MuiDataGrid-columnHeader, & .MuiDataGrid-columnHeaderTitle, & .MuiDataGrid-columnHeaderTitleContainer':
        {
          color: theme.vars ? theme.vars.palette.text.primary : theme.palette.text.primary,
          fontWeight: 700,
        },

      '& .MuiDataGrid-columnSeparator': { display: 'none' },

      '& .MuiDataGrid-cell': {
        outline: 'none !important',
        borderBottom: '1px solid',
        borderColor: 'divider',
      },

      '& .MuiDataGrid-row:hover': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.06 : 0.1})`,
      },

      '& .MuiDataGrid-row.Mui-selected': {
        backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.12 : 0.2})`,
        '&:hover': {
          backgroundColor: `rgba(${theme.vars.palette.primary.mainChannel} / ${isLight ? 0.14 : 0.24})`,
        },
      },

      '& .MuiDataGrid-virtualScroller': {
        backgroundColor: theme.vars.palette.background.paper,
      },

      '& .MuiDataGrid-footerContainer': {
        borderTop: '1px solid',
        borderColor: 'divider',
        backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / 0.72)`,
        backdropFilter: 'saturate(120%) blur(6px)',
      },

      '& .MuiDataGrid-sortIcon, & .MuiDataGrid-iconSeparator, & .MuiDataGrid-menuIcon': {
        color: theme.vars ? theme.vars.palette.text.secondary : theme.palette.text.secondary,
      },
    };
  };

  return (
    <>
      <Container maxWidth="xl">
        <HeaderListPages title="Trial List" addRoute={paths.dashboard.addNst} />

        {messageBox && (
          <Alert sx={{ mb: 3 }} severity="info">
            {messageBox}
          </Alert>
        )}

        <Card>
          {loading && <LinearProgress />}
          <Box sx={{ p: settings.compact ? 1 : 2 }}>
            <DataGrid
              rows={data.results}
              getRowId={(r) => (r as any).trial_id ?? (r as any).core_id}
              columns={columns}
              autoHeight
              loading={loading}
              disableRowSelectionOnClick
              disableColumnMenu
              density={settings.compact ? 'compact' : 'standard'}
              rowHeight={settings.compact ? 40 : 48}
              columnHeaderHeight={settings.compact ? 44 : 56}
              sx={gridSx}
              hideFooter
            />
          </Box>

          <Divider />
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
            sx={{ px: 2, py: 1.5 }}
          >
            <Button
              startIcon={<ArrowLeftRounded />}
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={!data.previous || isDeleting}
              size={settings.compact ? 'small' : 'medium'}
            >
              previous
            </Button>

            <Chip
              size="small"
              label={`page: ${page} | ${data.results?.length ?? 0} - ${data.count ?? 0}`}
              variant="outlined"
            />

            <Button
              endIcon={<ArrowRightRounded />}
              onClick={() => setPage((p) => p + 1)}
              disabled={!data.next}
              size={settings.compact ? 'small' : 'medium'}
            >
              next
            </Button>
          </Stack>
        </Card>
      </Container>

      <ConfirmDialog
        open={openConfirm}
        loading={isDeleting} 
        onClose={() => {
          if (isDeleting) return; 
          setOpenConfirm(false);
        }}
        onConfirm={handleDelete}
        title="Delete Trial"
        content="Are you sure you want to delete this trial?"
      />

      <ViewDrawerForm item={drawerData} open={drawerOpen} onClose={() => setDrawerOpen(false)} />
    </>
  );
}
