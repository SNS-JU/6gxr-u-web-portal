/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function StatusTx({ id }: { id: number }) {
  const [realtimeMessage, setRealtimeMessage] = useState(null);
  const [initialStatus, setInitialStatus] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchInitialStatus = async () => {
      try {
        const response = await axios.post(`/home/api/NstStatus/`, {
          nst_id: id,
          user: Number(sessionStorage.getItem('userId')),
        });
        setInitialStatus(response.data?.data);
      } catch (error) {
        console.error('Failed to fetch initial status', error);
        setInitialStatus('Error');
      } finally {
        setLoading(false);
      }
    };

    fetchInitialStatus();

    const socket = new WebSocket('ws://193.166.32.46:6060/ws/status/');
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      setRealtimeMessage(data.message.state);
    };

    return () => {
      socket.close();
    };
  }, [id]);

  if (loading) {
    return <span>loading...</span>;
  }

  return <span>{realtimeMessage || initialStatus}</span>;
}
