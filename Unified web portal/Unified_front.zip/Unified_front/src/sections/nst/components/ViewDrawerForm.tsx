/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Stack,
  Drawer,
  Button,
  Tooltip,
  IconButton,
  Typography,
  DrawerProps,
} from '@mui/material';
import { Iconify } from 'src/components/iconify';
import { useFetch } from 'src/hooks/use-fetch';
import { NstList } from 'src/types/nst-list';

type Props = DrawerProps & {
  onClose: () => void;
  item: NstList | null;
};

export default function ViewDrawerForm({ open, onClose, item, ...other }: Props) {
  const { data: checkRun } = useFetch<any>('/home/api/checkrunning/');
  const navigate = useNavigate();

  if (!item) return null;

  const keysToShow = [
    { title: 'Trial Name', value: item.name },
    { title: 'Trial ID', value: item.trial_id },
    { title: 'Start Time', value: item.start_date },
    { title: 'End Time', value: item.end_date },
    { title: 'Facility', value: item.facility },
    { title: 'Description', value: item.description },
  ];

  const handleAnalyze = () => {
    alert(`Navigating to analyze page for item ${item.core_id}`);
    // navigate(`/dashboard/nst-analyze/${item.core_id}`);
  };

  return (
    <Drawer
      open={open}
      onClose={onClose}
      anchor="right"
      ModalProps={{
        BackdropProps: {
          sx: {
            backgroundColor: 'rgba(255,255,255,0.02)',
            backdropFilter: 'blur(10px) saturate(120%)',
            WebkitBackdropFilter: 'blur(10px) saturate(120%)',
          },
        },
      }}
      PaperProps={{
        sx: (t) => ({
          width: 375,
          maxWidth: '100vw',
          boxSizing: 'border-box',
          flexShrink: 0,

          borderLeft: '1px solid',
          borderColor: 'divider',

          backgroundColor: `rgba(${t.vars.palette.background.paperChannel} / ${
            t.palette.mode === 'light' ? 0.32 : 0.24
          })`,
          backdropFilter: 'saturate(130%) blur(10px)',
          WebkitBackdropFilter: 'saturate(130%) blur(10px)',
          boxShadow: 'none',
        }),
      }}
      {...other}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={{ p: 2.5, borderBottom: '1px dashed' }}
        borderColor="divider"
      >
        <Typography variant="h6">Trial Info</Typography>
        <IconButton onClick={onClose}>
          <Iconify icon="mingcute:close-line" />
        </IconButton>
      </Stack>

      <Stack spacing={2} sx={{ p: 2.5 }}>
        {keysToShow.map((el) => (
          <Box key={el.title}>
            <Typography variant="caption" sx={{ color: 'text.secondary' }}>
              {el.title}
            </Typography>
            <Typography variant="body2">{el.value || 'N/A'}</Typography>
          </Box>
        ))}
      </Stack>

      {/* <Box sx={{ p: 2.5, mt: 'auto' }}>
      <Tooltip title="Go to the experiment analysis">
        <Button onClick={handleAnalyze} fullWidth variant="contained" color="primary">
          Analyze Results
        </Button>
      </Tooltip>
    </Box> */}
    </Drawer>
  );
}
