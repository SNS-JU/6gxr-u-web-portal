/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import React, { useState } from 'react';

import {
  Box,
  Container,
  Typography,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

const AboutContent: React.FC = () => {
  const [expanded, setExpanded] = useState<string | false>(false);

  const handleChange = (panel: string) => (_event: React.SyntheticEvent, isExpanded: boolean) => {
    setExpanded(isExpanded ? panel : false);
  };

  const renderBullets = (items: string[]) => (
    <List>
      {items.map((item, index) => (
        <ListItem key={index} alignItems="flex-start">
          <ListItemIcon>
            <CheckCircleIcon color="primary" />
          </ListItemIcon>
          <ListItemText primary={<span>{item}</span>} />
        </ListItem>
      ))}
    </List>
  );

  return (
    <Container maxWidth="md" sx={{ paddingY: 4 }}>
      <Box sx={{ marginTop: 4 }}>
        <Typography variant="h4" gutterBottom>
          How to Handle a Trial?
        </Typography>

        <Accordion
          expanded={expanded === 'panel1'}
          onChange={handleChange('panel1')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Introduction</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1">
              This guide is intended for experimenters who wish to execute their experiments and
              view the results through the designated North and South portals. It provides a
              detailed overview of the Unified web portal, where experimenters can log in, create
              new trials, and then proceed to the corresponding North and South portals to launch
              experiments and monitor results based on each specific trial.{' '}
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel2'}
          onChange={handleChange('panel2')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">System Overview</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              The system is a web-based application that, along with its database and graphical
              front-end interface, allows experimenters to create and manage their trials. The
              application consists of several components, including:
            </Typography>
            {renderBullets([
              'Tabs for “Trials” and “About Unified”',
              'User authentication features such as Login, Logout, Registration, and Password Recovery',
              'User management: View, Edit, and Delete user accounts',
              'Trial management: Create, Edit, and Delete trials',
              'Redirection of experimenters to the appropriate North or South portal based on the selected trial.',
            ])}
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel3'}
          onChange={handleChange('panel3')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">User Functionality</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              <strong>User Registration:</strong>
            </Typography>
            {renderBullets([
              'The experimenter is required to provide their personal information, including full name, phone number, email address, username, and a password.',
              'The password must meet complexity requirements to ensure account security.',
              'All credentials and experimenter information are securely stored in the database using encryption.',
            ])}
            <Typography variant="body1" paragraph>
              <strong>Password Recovery:</strong>
            </Typography>
            {renderBullets([
              'If an experimenter forgets their password, they can enter their registered email address to receive a verification code.',
              'This code allows them to reset their password securely.',
            ])}
            <Typography variant="body1" paragraph>
              <strong>User Deletion:</strong>
            </Typography>
            {renderBullets([
              'Experimenters have the ability to delete their accounts.',
              'Once an account is deleted, all associated data is permanently removed from the database and the application.',
            ])}
            <Typography variant="body1" paragraph>
              <strong>Post-Registration:</strong> After successful registration, the experimenter is
              redirected to the unified portal dashboard.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel4'}
          onChange={handleChange('panel4')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Creating a Trial</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              Upon logging into the unified portal dashboard, the experimenter is presented with a
              list of existing trials and also has the option to create a new one.
            </Typography>
            <List>
              {[
                'All fields are mandatory; if any field is left empty, the trial will not be created.',
                'After successfully creating a trial, the experimenter is redirected to the trial list page, where they can view and manage all their created trials.',
                "If the trial's end time is set to a time earlier than the current system time, the trial will appear as inactive in the trial list page.",
                'To create a trial, the experimenter must fill in all required fields, including:',
              ].map((text, index) => (
                <ListItem key={index}>
                  <ListItemIcon>
                    <CheckCircleIcon color="primary" />
                  </ListItemIcon>
                  <ListItemText primary={<span>{text}</span>} />
                </ListItem>
              ))}
              <List sx={{ pl: 4 }}>
                {['Trial Name', 'Start Time', 'End Time', 'Facility', 'Description'].map(
                  (item, idx) => (
                    <ListItem key={idx}>
                      <ListItemIcon>
                        <CheckCircleIcon color="action" />
                      </ListItemIcon>
                      <ListItemText primary={<span>{item}</span>} />
                    </ListItem>
                  )
                )}
              </List>
            </List>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel5'}
          onChange={handleChange('panel5')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Trial List</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1">
              On this page, you can view a list of all created trials, including both active and
              inactive ones. If a trial has not yet expired, you can click on the desired facility
              to be redirected to either the North or South portal. Additionally, this page allows
              experimenters to manage their trials, including options to edit, view, and delete each
              trial.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel6'}
          onChange={handleChange('panel6')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Additional Interface Components</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1" paragraph>
              In the top-left corner of the application, the experimenter can find the main
              navigation tabs. One of these tabs is the "About Unified" section, which provides
              general information and guidance on how to use the system. In the top-right corner,
              there is an experimenter menu. By clicking on it, experimenter can view and edit their
              personal information.
              <br />
              Note: The email field is not editable.
            </Typography>
            <Typography variant="body1" paragraph>
              From this same experimenter menu, experimenters also have the option to delete their
              accounts. Next to the profile icon is a settings gear icon that allows experimenters
              to customize the interface's appearance. Options include:
            </Typography>
            {renderBullets([
              'Switching between light and dark themes',
              'Adjusting page layout sizes',
              'Aligning the interface left-to-right or right-to-left',
            ])}
            <Typography variant="body1">
              Finally, at the bottom left of the interface, experimenters can log out of the system
              or access external links related to the 6G-XR project.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel7'}
          onChange={handleChange('panel7')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Data Deletion Notes</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <List>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary={
                    <span>
                      When an experimenter's account is deleted, all associated data will be
                      permanently removed. This includes:
                    </span>
                  }
                />
              </ListItem>
              <List sx={{ pl: 4 }}>
                {[
                  'The experimenter’s personal information',
                  'All trials created by the experimenter',
                  'All experiments related to those trials in both the North and South portals',
                ].map((text, index) => (
                  <ListItem key={index}>
                    <ListItemIcon>
                      <CheckCircleIcon color="action" />
                    </ListItemIcon>
                    <ListItemText primary={<span>{text}</span>} />
                  </ListItem>
                ))}
              </List>
              <ListItem>
                <ListItemIcon>
                  <CheckCircleIcon color="primary" />
                </ListItemIcon>
                <ListItemText
                  primary={
                    <span>
                      When a trial is deleted, all experiments linked to that trial in both the
                      North and South portals will also be permanently deleted.
                    </span>
                  }
                />
              </ListItem>
            </List>
          </AccordionDetails>
        </Accordion>

        <Accordion
          expanded={expanded === 'panel8'}
          onChange={handleChange('panel8')}
          sx={{ backgroundColor: '#ccffe6', border: '1px solid #66ffb5', marginBottom: 2 }}
        >
          <AccordionSummary expandIcon={<ExpandMoreIcon />}>
            <Typography variant="h6">Contact Info / Support</Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography variant="body1">
              If you encounter any issues or conflicts while using the system, please contact Mahdi
              Salmani, the person responsible for the Unified and North portals:
              <br />
              mohammad.salmani@oulu.fi
            </Typography>
          </AccordionDetails>
        </Accordion>
      </Box>
    </Container>
  );
};

export { AboutContent };
