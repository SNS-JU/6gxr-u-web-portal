/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import { Visibility, VisibilityOff } from '@mui/icons-material';
import { validatePasswordComplexity, PASSWORD_HINT } from 'src/utils/validators';

import {
  Container,
  Grid,
  Card,
  CardContent,
  CardHeader,
  Stack,
  Typography,
  Avatar,
  Chip,
  Button,
  Paper,
  Box,
  Alert,
  LinearProgress,
  TextField,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';

import { z as zod } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import axiosInstance from 'src/utils/axios';
import { ENDPOINTS } from 'src/config';

import { useAuthContext } from 'src/auth/hooks/use-auth-context';

// RHF helpers of your project
import FormProvider from 'src/components/hook-form/form-provider';
import RHFTextField from 'src/components/hook-form/rhf-text-field';

// Optional loading screen you have
import LoadingScreen from 'src/components/loading/loading-screen';

// ---------------- Types & Schema ----------------

type ProfileFormValues = {
  first_name: string;
  last_name: string;
  phone: string;
  current_password?: string;
  new_password?: string;
};

const ProfileSchema = zod
  .object({
    first_name: zod.string().min(1, { message: 'please fulfill the input' }),
    last_name: zod.string().min(1, { message: 'please fulfill the input' }),
    phone: zod.string().min(1, { message: 'please fulfill the input' }),
    current_password: zod.string().optional(),
    new_password: zod.string().optional(),
  })
  .refine(
    (data) =>
      (!data.current_password && !data.new_password) ||
      (data.current_password && data.new_password),
    {
      message: 'Both current and new password must be filled',
      path: ['new_password'],
    }
  );

export default function ProfilePage() {
  // --- Change Password local state ---
  const [pwOld, setPwOld] = React.useState('');
  const [pwNew, setPwNew] = React.useState('');
  const [pwConfirm, setPwConfirm] = React.useState('');
  const [showOld, setShowOld] = React.useState(false);
  const [showNew, setShowNew] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const [pwLoading, setPwLoading] = React.useState(false);
  const [pwError, setPwError] = React.useState<string | null>(null);
  const [pwSuccess, setPwSuccess] = React.useState<string | null>(null);

  const handleChangePassword = () => {
    setPwError(null);
    setPwSuccess(null);

    if (!pwOld || !pwNew || !pwConfirm) {
      setPwError('Please fill all password fields');
      return;
    }
    if (!validatePasswordComplexity(pwNew)) {
      setPwError(PASSWORD_HINT);
      return;
    }
    if (pwNew !== pwConfirm) {
      setPwError('New password and confirmation do not match');
      return;
    }
  };

  const theme = useTheme();
  const isLight = theme.palette.mode === 'light';
  const { user } = useAuthContext();

  const name = user?.username || 'User';
  const email = user?.email || '-';
  const role = (user as any)?.role || 'Member';
  const joinedAt = (user as any)?.joinedAt || '-';

  const PROFILE_GET_URL = (ENDPOINTS as any)?.profile;
  const PROFILE_UPDATE_URL = (ENDPOINTS as any)?.profileUpdate;

  const methods = useForm<ProfileFormValues>({
    mode: 'all',
    resolver: zodResolver(ProfileSchema),
    defaultValues: {
      first_name: '',
      last_name: '',
      phone: '',
      current_password: '',
      new_password: '',
    },
  });

  const {
    handleSubmit,
    reset,
    formState: { isSubmitting },
  } = methods;

  const [loading, setLoading] = React.useState(true);
  const [loadError, setLoadError] = React.useState<string | null>(null);
  const [successMsg, setSuccessMsg] = React.useState<string | null>(null);
  const [errorMsg, setErrorMsg] = React.useState<string | null>(null);

  // const token = sessionStorage.getItem('accessToken');

  React.useEffect(() => {
    let mounted = true;
    (async () => {
      setLoading(true);
      setLoadError(null);
      try {
        const res = await axiosInstance.post(PROFILE_GET_URL, {
          token: sessionStorage.getItem('accessToken'),
        });
        const data = res?.data || {};
        const first_name = data.first_name ?? data.firstname ?? '';
        const last_name = data.last_name ?? data.lastname ?? '';
        const phone = data.phone ?? data.phone_number ?? data.mobile ?? '';
        if (mounted) {
          reset({
            first_name,
            last_name,
            phone,
            current_password: '',
            new_password: '',
          });
        }
      } catch (err: any) {
        if (mounted) setLoadError(err?.message || 'Failed to load profile');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [PROFILE_GET_URL, reset]);

  const onSubmit = handleSubmit(async (form: ProfileFormValues) => {
    setSuccessMsg(null);
    setErrorMsg(null);
    setPwError(null);
    setPwSuccess(null);

    const firstT = form.first_name?.trim() ?? '';
    const lastT = form.last_name?.trim() ?? '';
    const phoneT = form.phone?.trim() ?? '';
    const oldT = pwOld?.trim() ?? '';
    const newT = pwNew?.trim() ?? '';
    const confT = pwConfirm?.trim() ?? '';

    const payload: any = {
      first_name: firstT,
      last_name: lastT,
      phone: phoneT,
      current_password: oldT,
      new_password: newT,
    };

    const wantPasswordChange = Boolean(oldT) || Boolean(newT) || Boolean(confT);

    if (wantPasswordChange) {
      if (!oldT || !newT || !confT) {
        setErrorMsg('Please fill all password fields');
        setPwError('Please fill all password fields');
        return;
      }
      if (!validatePasswordComplexity(newT)) {
        setErrorMsg(PASSWORD_HINT);
        setPwError(PASSWORD_HINT);
        return;
      }
      if (newT !== confT) {
        setErrorMsg('New password and confirmation do not match');
        setPwError('New password and confirmation do not match');
        return;
      }
      setPwLoading(true);
    }

    try {
      await axiosInstance.put(PROFILE_UPDATE_URL, payload);

      const msg = wantPasswordChange
        ? 'Update was successful (password updated)'
        : 'Update was successful';

      setSuccessMsg(msg);
      if (wantPasswordChange) {
        setPwSuccess('Password updated successfully');
      }

      setPwOld('');
      setPwNew('');
      setPwConfirm('');

      window.location.reload();
    } catch (err: any) {
      const msg =
        err?.response?.data?.error ||
        err?.response?.data?.message ||
        err?.response?.data?.detail ||
        (typeof err?.response?.data === 'string' ? err.response.data : '') ||
        err?.message ||
        'An error occurred';
      setErrorMsg(msg);
      if (wantPasswordChange) setPwError(msg);
    } finally {
      if (wantPasswordChange) setPwLoading(false);
    }
  });

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <Container maxWidth="lg" sx={{ py: 3 }}>
      {loadError && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {loadError}
        </Alert>
      )}

      {/* Hero */}
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Paper
            variant="outlined"
            sx={{
              p: { xs: 2, md: 3 },
              borderRadius: 1,
              borderColor: 'divider',
              backgroundColor: `rgba(${theme.vars.palette.background.paperChannel} / ${isLight ? 0.72 : 0.5})`,
              backdropFilter: 'saturate(120%) blur(10px)',
            }}
          >
            <Stack direction="row" spacing={2} alignItems="center">
              <Avatar
                sx={(t) => ({
                  width: 72,
                  height: 72,
                  fontWeight: 800,
                  color: isLight ? '#fff' : '#0B1220',
                  backgroundImage: `linear-gradient(135deg, rgba(${t.vars.palette.primary.mainChannel} / 0.95), rgba(${t.vars.palette.secondary.mainChannel} / 0.95))`,
                })}
              >
                {name?.[0]?.toUpperCase() || 'U'}
              </Avatar>

              <Box sx={{ minWidth: 0, flex: 1 }}>
                <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 0.25 }}>
                  <Typography variant="h5" fontWeight={800} noWrap>
                    {name}
                  </Typography>
                  <Chip size="small" label={role} sx={{ height: 22 }} />
                </Stack>
                <Typography variant="body2" color="text.secondary" noWrap title={email}>
                  {email}
                </Typography>
              </Box>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12}>
          <Card variant="outlined" sx={{ borderRadius: 1 }}>
            <CardHeader titleTypographyProps={{ fontWeight: 800 }} title="Edit Profile" />
            <CardContent>
              <FormProvider methods={methods} onSubmit={onSubmit}>
                <Grid
                  display="flex"
                  flexDirection="row"
                  justifyContent="start"
                  alignItems="start"
                  flexWrap="wrap"
                  gap={2}
                >
                  <Grid width={300}>
                    <RHFTextField name="first_name" label="First Name" />
                  </Grid>

                  <Grid width={300}>
                    <RHFTextField name="last_name" label="Last Name" />
                  </Grid>

                  <Grid width={300}>
                    <RHFTextField name="phone" label="Phone" />
                  </Grid>

                  <Grid width={300}>
                    <TextField
                      label="Current password"
                      type={showOld ? 'text' : 'password'}
                      value={pwOld}
                      onChange={(e) => setPwOld(e.target.value)}
                      fullWidth
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowOld((s) => !s)} edge="end">
                              {showOld ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>

                  <Grid width={300}>
                    <TextField
                      label="New password"
                      type={showNew ? 'text' : 'password'}
                      value={pwNew}
                      onChange={(e) => setPwNew(e.target.value)}
                      fullWidth
                      helperText={PASSWORD_HINT}
                      error={Boolean(pwNew) && !validatePasswordComplexity(pwNew)}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowNew((s) => !s)} edge="end">
                              {showNew ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>

                  <Grid width={300}>
                    <TextField
                      label="Confirm new password"
                      type={showConfirm ? 'text' : 'password'}
                      value={pwConfirm}
                      onChange={(e) => setPwConfirm(e.target.value)}
                      fullWidth
                      error={Boolean(pwConfirm) && pwNew !== pwConfirm}
                      helperText={pwConfirm && pwNew !== pwConfirm ? 'Does not match' : ''}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <IconButton onClick={() => setShowConfirm((s) => !s)} edge="end">
                              {showConfirm ? <VisibilityOff /> : <Visibility />}
                            </IconButton>
                          </InputAdornment>
                        ),
                      }}
                    />
                  </Grid>

                  {/* {pwSuccess && <Alert severity="success">{pwSuccess}</Alert>} */}
                  {/* {pwError && <Alert severity="error">{pwError}</Alert>} */}
                </Grid>
                  <Stack direction="row" spacing={2} alignItems="center">
                    <Button
                      type="submit"
                      variant="contained"
                      disabled={isSubmitting || pwLoading}
                    >
                      {isSubmitting || pwLoading ? 'Please wait…' : 'Save changes'}
                    </Button>
                  </Stack>
                {isSubmitting && (
                  <Grid item xs={12}>
                    <LinearProgress />
                  </Grid>
                )}

                {successMsg && (
                  <Grid item xs={12}>
                    <Alert severity="success">{successMsg}</Alert>
                  </Grid>
                )}

                {errorMsg && (
                  <Grid item xs={12}>
                    <Alert severity="error">{errorMsg}</Alert>
                  </Grid>
                )}

                <Grid item xs={12} />
              </FormProvider>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Container>
  );
}
