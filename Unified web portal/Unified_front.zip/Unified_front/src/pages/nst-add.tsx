import NstAddView from '../sections/nst/nst-add-view';

export default function NstAddPage() {
  return <NstAddView />;
}
