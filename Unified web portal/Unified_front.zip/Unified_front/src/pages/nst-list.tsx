import NstListView from '../sections/nst/nst-list-view';

export default function NstListPage() {
  return <NstListView />;
}
