import React from 'react';
import { useNavigate } from 'react-router';

import { Box, Stack, Button, Container, Typography } from '@mui/material';

const Privacy: React.FC = () => {
  const navigate = useNavigate();
  return (
    <Container maxWidth="md" sx={{ paddingY: 4 }}>
      <Stack direction="row" justifyContent="space-between" mb={6}>
        <Button variant="contained" onClick={() => navigate('/login')}>
          Back
        </Button>
        <Typography variant="h4" gutterBottom>
          Privacy Policy
        </Typography>
        <div />
      </Stack>

      <Typography variant="body1" paragraph>
        Welcome to <strong>Unified Web Portal</strong>. Your privacy is important to us. This
        Privacy Policy explains how we collect, use, and protect your information when you use our
        platform.
      </Typography>

      <Box>
        <Typography variant="h6" gutterBottom>
          1. Information We Collect
        </Typography>
        <Typography variant="body1" paragraph>
          ✔️ Full name
          <br />
          ✔️ Phone number
          <br />
          ✔️ Email address
          <br />
          ✔️ Password
          <br />
          ✔️ Information related to trial usage and internal system operations
          <br />
          <br />
          We do <strong>not</strong> collect cookies or use any tracking technologies.
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>
          2. Purpose of Data Collection
        </Typography>
        <Typography variant="body1" paragraph>
          We collect and use your personal information for the following purposes:
          <br />
          <br />
          ✔️ To register and authenticate user accounts
          <br />
          ✔️ To enable login and password recovery
          <br />
          ✔️ To operate the platform and its services (including trial and experiment management)
          <br />
          ✔️ To maintain secure communication with the connected subsystems (North Node and South
          Node)
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>
          3. Data Sharing
        </Typography>
        <Typography variant="body1" paragraph>
          We do <strong>not</strong> share your information with third-party companies. Your data is
          only exchanged securely with our internal systems (North Node and South Node), which are
          also maintained by our development team.
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>
          4. Data Control and Deletion
        </Typography>
        <Typography variant="body1" paragraph>
          You have full control over your data. You can:
          <br />
          <br />
          ✔️ View your account information
          <br />
          ✔️ Edit your profile details
          <br />
          ✔️ Delete your account and all associated data at any time via the platform
          <br />
          <br />
          If you need assistance, you may contact the data protection officer directly.
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>
          5. Data Location and Legal Basis
        </Typography>
        <Typography variant="body1" paragraph>
          Our platform is hosted in <strong>Finland</strong>, and our services are available in both{' '}
          <strong>Finland</strong> and <strong>Spain</strong>. We comply with applicable data
          protection laws, including the{' '}
          <strong>EU General Data Protection Regulation (GDPR)</strong>.
        </Typography>
      </Box>

      <Box>
        <Typography variant="h6" gutterBottom>
          6. Contact
        </Typography>
        <Typography variant="body1" paragraph>
          For questions or data-related requests, please contact:
          <br />
          <strong>Data Controller & Developer</strong>
          <br />
          Mohammad Salmani
          <br />
          📧 <strong>mohammad.salmani@oulu.fi</strong>
        </Typography>
      </Box>
    </Container>
  );
};

export default Privacy;
