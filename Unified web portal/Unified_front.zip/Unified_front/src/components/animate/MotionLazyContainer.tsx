import { m } from 'framer-motion';

import Box, { BoxProps } from '@mui/material/Box';

import { varFade } from './variants/fade';

// ----------------------------------------------------------------------

export default function MotionLazyContainer({ children, ...other }: BoxProps) {
  return (
    <Box
      component={m.div}
      initial="initial"
      animate="animate"
      exit="exit"
      variants={varFade().inUp}
      {...other}
    >
      {children}
    </Box>
  );
}
