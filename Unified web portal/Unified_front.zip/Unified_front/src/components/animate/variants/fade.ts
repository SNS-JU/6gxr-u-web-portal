import { varTranEnter, varTranExit } from "./transition";

// ----------------------------------------------------------------------

export const varFade = (props?: { distance?: number; durationIn?: number; durationOut?: number }) => {
  const distance = props?.distance || 120;
  const durationIn = props?.durationIn;
  const durationOut = props?.durationOut;

  return {
    // IN
    in: {
      initial: { opacity: 0 },
      animate: { opacity: 1, transition: varTranEnter({ durationIn }) },
      exit: { opacity: 0, transition: varTranExit({ durationOut }) },
    },
    inUp: {
      initial: { y: distance, opacity: 0 },
      animate: { y: 0, opacity: 1, transition: varTranEnter({ durationIn }) },
      exit: { y: distance, opacity: 0, transition: varTranExit({ durationOut }) },
    },
  };
};