/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import * as React from 'react';
import { Box, Paper, Stack, useTheme } from '@mui/material';
import Masonry from '@mui/lab/Masonry';
import { useLayoutStyle } from 'src/context/layout-style';

/**
 * Generic container that renders items in Grid/List/Masonry based on the global layout style.
 * - items: array
 * - renderItem: (item, index) => ReactNode (should return the INSIDE of a card)
 * - keyExtractor?: (item, index) => key
 */
export default function LayoutContainer<T>({
  items,
  renderItem,
  keyExtractor,
  emptyLabel = 'No items',
}: {
  items: T[];
  renderItem: (item: T, index: number) => React.ReactNode;
  keyExtractor?: (item: T, index: number) => string | number;
  emptyLabel?: string;
}) {
  const { style } = useLayoutStyle();
  const theme = useTheme();

  if (!items || items.length === 0)
    return <Box sx={{ py: 6, color: 'text.secondary', textAlign: 'center' }}>{emptyLabel}</Box>;

  const padding = style.dense ? 1.5 : 2.5; // theme.spacing units
  const radius = style.radius; // px

  const CardWrap: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <Paper variant="outlined" sx={{ p: padding, borderRadius: radius }}>
      {children}
    </Paper>
  );

  if (style.mode === 'list') {
    return (
      <Stack spacing={style.gap}>
        {items.map((it, i) => (
          <CardWrap key={keyExtractor?.(it, i) ?? i}>{renderItem(it, i)}</CardWrap>
        ))}
      </Stack>
    );
  }

  if (style.mode === 'masonry') {
    // Masonry's spacing is px; convert theme spacing unit -> px number
    const spacingPx = Number(theme.spacing(style.gap).replace('px', ''));
    return (
      <Masonry columns={style.columns} spacing={spacingPx}>
        {items.map((it, i) => (
          <CardWrap key={keyExtractor?.(it, i) ?? i}>{renderItem(it, i)}</CardWrap>
        ))}
      </Masonry>
    );
  }

  // Grid (CSS grid for equal heights)
  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: `repeat(${style.columns}, minmax(0, 1fr))`,
        gap: theme.spacing(style.gap),
      }}
    >
      {items.map((it, i) => (
        <CardWrap key={keyExtractor?.(it, i) ?? i}>{renderItem(it, i)}</CardWrap>
      ))}
    </Box>
  );
}
