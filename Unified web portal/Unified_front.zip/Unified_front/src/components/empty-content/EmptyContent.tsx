/* eslint-disable @typescript-eslint/ban-ts-comment */
// @ts-nocheck
/* eslint-disable */
import { Link as RouterLink } from 'react-router-dom';
import { Box, Button, Typography, Stack } from '@mui/material';
import { Iconify } from 'src/components/iconify';

// ----------------------------------------------------------------------

type Props = {
  title?: string;
  description?: string;
  imgUrl?: string;
  action?: React.ReactNode;
};

export default function EmptyContent({ title, description, action, imgUrl, ...other }: Props) {
  return (
    <Stack
      flexGrow={1}
      alignItems="center"
      justifyContent="center"
      sx={{
        px: 3,
        height: 1,
        textAlign: 'center',
        py: { xs: 5, md: 10 },
      }}
      {...other}
    >
      <Box
        component="img"
        src={imgUrl || '/assets/icons/empty/ic-folder-empty.svg'}
        sx={{ width: 1, maxWidth: 160, mb: 3 }}
      />

      <Typography variant="h5" gutterBottom>
        {title || 'No Data Found'}
      </Typography>

      {description && (
        <Typography variant="body2" sx={{ color: 'text.secondary', mb: 3 }}>
          {description}
        </Typography>
      )}

      {action && action}
    </Stack>
  );
}
