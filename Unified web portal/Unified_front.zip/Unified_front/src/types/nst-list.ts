export type NstList = {
  core_id: number;
  id: number;
  trial_id: number;
  name: string;
  start_date: string;
  end_date: string;
  facility: string;
  description: string;
};
