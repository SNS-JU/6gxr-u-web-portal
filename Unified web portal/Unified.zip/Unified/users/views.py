import random,requests
from home.models import Trial
from rest_framework import status
from django.core.mail import send_mail
from rest_framework.views import APIView
from django.contrib.auth.models import User
from rest_framework.response import Response
from .models import myuser, Passwrordresetcode
from django.shortcuts import get_object_or_404
from django.contrib.auth.hashers import check_password
from rest_framework.exceptions import PermissionDenied
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import authenticate, login,get_user_model
from .serializer import AlluserSerializer,MyUserSerializer,CustomTokenObtainPairSerializer


class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class = CustomTokenObtainPairSerializer

User = get_user_model()
class RegisterUserApiView(APIView):
  def post(self, request):
    request.body
    serializer = MyUserSerializer(data=request.data)
    if serializer.is_valid():
      serializer.create(request.data)
      try:
        response=requests.post("http://127.0.0.1:9090/users/api/users/register/",request.data)
      except:
        return Response({"error": "Connection error !"}, status=status.HTTP_400_BAD_REQUEST)
      try:
        data = {
          'username': serializer.validated_data.get('username'),
          'password': serializer.validated_data.get('password'),
        }
        tokenresponse = CustomTokenObtainPairView.as_view()(request._request, data=data)
        return tokenresponse
      except:
        return Response(["error while creating user"], status=status.HTTP_400_BAD_REQUEST)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class LoginUserApiView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return Response({"message": "Logged in successfully."}, status=status.HTTP_200_OK)
        return Response({"message": "Invalid credentials."}, status=status.HTTP_401_UNAUTHORIZED)

class LogoutUserApiView(APIView):
    def post(self, request):
        try:
            refreshtoken = request.data['refresh_token']
            token = RefreshToken(refreshtoken)
            token.blacklist()
            return Response({"message": "Logged out successfully."}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

class EditUserApiView(APIView):
    permission_classes = [IsAuthenticated]  # Only authenticated users can access this endpoint
    def get(self, request):
        user = get_object_or_404(myuser, id=request.user.id)
        # Check if the requesting user has permission
        if request.user.id != request.user.id and not request.user.is_staff: 
            raise PermissionDenied("You are not allowed to view this user.")
        serializer = MyUserSerializer(user)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request):
        token_str = request.auth.token.decode("utf-8")
        user = request.user  # Get the currently authenticated user
        data = request.data
        try:
            new_first_name = data["first_name"]
            new_last_name = data["last_name"]
            current_password = data["current_password"]
            new_password = data["new_password"]
            phone_number = data["phone"]
        except KeyError as e:
            return Response({"message": f"Missing key {e}"}, status=status.HTTP_400_BAD_REQUEST)
        # Validate that both passwords are provided
        if  current_password !="" and  new_password != "":
            if not user.check_password(current_password):
                return Response({"error": "Current password is incorrect."},status=status.HTTP_400_BAD_REQUEST,)
            else:
                user.set_password(new_password)
        if new_first_name:
            user.first_name = new_first_name
        if new_last_name:
            user.last_name = new_last_name
        if phone_number:
            user.phone_number = phone_number
        try:
            res_north=requests.put("http://127.0.0.1:9090/users/api/users/edit/", data={"token": token_str,"first_name":new_first_name,
                    "last_name":new_last_name,
                    "current_password":current_password,
                    "new_password":new_password,
                    "phone":phone_number })

            if res_north.status_code == 200:
                user.save()
                return Response({"message": "User profile updated successfully!"}, status=status.HTTP_200_OK)
            else:
                return Response({"error": "Remote service error", "details": res_north.text}, status=status.HTTP_400_BAD_REQUEST)
        except :
            return Response("error", status=status.HTTP_400_BAD_REQUEST)

'''class DeleteUserApiView(APIView):
    permission_classes = [IsAuthenticated]
    def delete(self, request):
        if request.user.id != request.data['user_id']:
            return Response({"error":'You can not delete the user.'},status=status.HTTP_401_UNAUTHORIZED)
        else:
            try:
                token_str = request.auth.token.decode("utf-8")
                trials = Trial.objects.filter(user=request.user.id)
                for trial in trials:
                    delete_slices_response = requests.post("http://127.0.0.1:9090/home/api/delete_related_slices/",json={"trial_id": trial.trial_id})
                    #delete_slices_response_south = requests.delete(f"http://127.0.0.1:9090/experiment/endTrial/{int(trial_id)}")
                t = requests.post("http://127.0.0.1:9090/users/api/users/delete/", data={"token": token_str})
                if t.status_code == 200:
                    user = get_object_or_404(myuser, id=request.data['user_id'])
                    user.delete()
            except Exception as e:
                return Response (e)

            return Response({"message": "User deleted successfully."}, status=status.HTTP_204_NO_CONTENT)'''


class DeleteUserApiView(APIView):
    permission_classes = [IsAuthenticated]

    def delete(self, request):
        if request.user.id != request.data['user_id']:
            return Response({"error": 'You cannot delete this user.'}, status=status.HTTP_401_UNAUTHORIZED)

        try:
            token_str = request.auth.token.decode("utf-8")
            user_trials = Trial.objects.filter(user=request.user)

            oulu_trials = user_trials.filter(facility='Oulu')
            south_trials = user_trials.filter(facility='South')

            if oulu_trials.exists():
                for trial in oulu_trials:
                    requests.post("http://127.0.0.1:9090/home/api/delete_related_slices/",json={"trial_id": trial.trial_id})
            requests.post("http://127.0.0.1:9090/users/api/users/delete/",json={"token": token_str})
            if south_trials.exists():
                for trial in south_trials:
                    requests.delete(f"http://193.166.32.46:4040/south-node-adapter/v3/experiment/endTrial/{int(trial_id)}",timeout=10)
            user = get_object_or_404(myuser, id=request.data['user_id'])
            user.delete()

        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)

        return Response({"message": "User deleted successfully."}, status=status.HTTP_204_NO_CONTENT)

import jwt
from django.conf import settings
class Userprofile(APIView):
    def post(self, request):
        token = request.data.get("token")  # Get token from request body
        if not token:
            return Response({"error": "Token is missing"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            # Decode the JWT manually
            decoded_token = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
            username = decoded_token.get("username")
            founduser=myuser.objects.filter(username=username).first()
            if founduser:
                ser_data=AlluserSerializer(founduser)
                return Response(ser_data.data, status=status.HTTP_200_OK)
            else:
                return Response({
                    "error": "No profile",
                }, status=status.HTTP_404_NOT_FOUND)
        except jwt.ExpiredSignatureError:
            return Response({"error": "Token has expired"}, status=status.HTTP_401_UNAUTHORIZED)
        except jwt.InvalidTokenError:
            return Response({"error": "Invalid token"}, status=status.HTTP_401_UNAUTHORIZED)

class passwordresetrequestview(APIView):
    def post(self, request):
        email=request.data['email']
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({"message": "User does not exist."}, status=status.HTTP_404_NOT_FOUND)
        username=request.data['username']
        if user.username != username:
            return Response({"message": "Email or Username does not exist."}, status=status.HTTP_400_BAD_REQUEST)
        else:
            code=f'{random.randint(100000,999999)}'
            from .models import Passwrordresetcode
            Passwrordresetcode.objects.update_or_create(user=user, code=code)
            send_mail("Password Reset Request",f'Your password reset code is {code}.','no-reply@6g-xr.eu',[email],fail_silently=False)
            return Response({"message": "Password reset email sent."}, status=status.HTTP_200_OK)
class codeverification(APIView):
    def post(self, request):
        email=request.data['email']
        code=request.data["code"]
        try:
            user=User.objects.get(email=email)
            reset_code=Passwrordresetcode.objects.get(user=user, code=code)
        except(User.DoesNotExist, Passwrordresetcode.DoesNotExist):
            return Response({"message": "User does not exist."}, status=status.HTTP_404_NOT_FOUND)
        if not reset_code.is_valid():
            return Response({"message": "Invalid code."}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"message": "Code is valid."}, status=status.HTTP_200_OK)

class Passresetconfirmtion(APIView):
    def post(self, request):
        email = request.data.get('email')
        code = request.data.get("code")
        new_password = request.data.get("new_password")
        # Ensure all necessary fields are provided
        if not email or not code or not new_password:
            return Response({"message": "Missing required fields."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user = User.objects.get(email=email)
            reset_code = Passwrordresetcode.objects.get(user=user, code=code)
        except (User.DoesNotExist, Passwrordresetcode.DoesNotExist):
            return Response({"message": "User or reset code does not exist."}, status=status.HTTP_404_NOT_FOUND)
        if not reset_code.is_valid():
            return Response({"message": "Invalid reset code."}, status=status.HTTP_400_BAD_REQUEST)
        try:
            user.set_password(new_password)
            north_reset = requests.post("http://127.0.0.1:9090/users/api/Passresetconfirmtion/", data={"email": email, "new_password": new_password})
            if north_reset.status_code == 200:
                user.save()
                reset_code.delete()
                return Response({"message": "Password has been changed successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"message": "Failed to reset password in the external system."}, status=status.HTTP_400_BAD_REQUEST)

        except Exception as e:
            # Log the exception for debugging purposes
            return Response({"message": f"Password change failed! Error: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

