from django.urls import path
from django.contrib import admin
from .views import codeverification,RegisterUserApiView,LoginUserApiView,passwordresetrequestview,LogoutUserApiView,EditUserApiView,DeleteUserApiView,Userprofile,Passresetconfirmtion,DeleteUserApiView,CustomTokenObtainPairView

app_name = 'users'
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/users/register/', RegisterUserApiView.as_view(), name='register_user'),
    path('api/users/login/', LoginUserApiView.as_view(), name='login_user'),
    path('api/users/logout/', LogoutUserApiView.as_view(), name='logout_user'),
    path('api/users/edit/', EditUserApiView.as_view(), name='edit_user'),
    path('api/users/delete/', DeleteUserApiView.as_view(), name='DeleteUserApiView'),
    path('api/users/profile/', Userprofile.as_view(), name='Userprofile'),
    path('api/passresreq/', passwordresetrequestview.as_view(), name='passwordresetrequestview'),
    path('api/codeverification/', codeverification.as_view(), name='codeverification'),
    path('api/Passresetconfirmtion/', Passresetconfirmtion.as_view(), name='Passresetconfirmtion'),
    path('api/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
]