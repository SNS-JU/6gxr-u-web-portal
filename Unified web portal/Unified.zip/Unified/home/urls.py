
from .views import trialapi
from django.urls import path
from .views import checknstid,gettrials,gettrialfornst,GetTrialForSouth,trialapi, gettrialtimesfornst

app_name = 'home'
urlpatterns = [

    path('api/trials/', trialapi.as_view(), name='trials'),
    path('api/checknstid/', checknstid.as_view(), name='checknstid'),
    path('api/gettrials/', gettrials.as_view(), name='gettrials'),
    path('api/gettrialfornst/', gettrialfornst.as_view(), name='gettrialfornst'),
    path('api/trials/<int:trial_id>/', GetTrialForSouth.as_view(), name='get_trial_for_south'),
    path('api/gettrialstimefornst/', gettrialtimesfornst.as_view())

]
    
    
    


