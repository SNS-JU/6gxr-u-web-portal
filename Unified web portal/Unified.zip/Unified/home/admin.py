from  .models import Trial
from django.contrib import admin

class TrialAdmin(admin.ModelAdmin):
    def get_readonly_fields(self, request, obj=None):
        if obj:
            return self.readonly_fields + ('trial_id','facility')
        return self.readonly_fields

admin.site.register(Trial, TrialAdmin)