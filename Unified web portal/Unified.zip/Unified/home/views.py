import requests, datetime
from .models import Trial
from zoneinfo import ZoneInfo
from rest_framework import status
from datetime import timezone, datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from rest_framework.permissions import IsAuthenticated
from django.utils.timezone import make_aware, is_naive
from rest_framework.pagination import PageNumberPagination
from .serializers import TrialSerializer, TrialsouthSerializer


class trialapi(APIView):
    permission_classes = (IsAuthenticated,)
    def post(self, request):
        if request.user.id != request.data['user']:
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)
        else:
            request_data = request.data
            # Extract start_date, end_date, and timezone from request data
            initial_start_date = request_data.get("start_date")
            initial_end_date = request_data.get("end_date")
            user_timezone = request_data.get("timezone")

            if not initial_start_date or not initial_end_date or not user_timezone:
                return Response(
                    {"error": "start_date, end_date, and timezone are required fields."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            if initial_start_date >= initial_end_date:
                return Response(
                    {"error": "end time must not be before the start time."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            try:
                from datetime import datetime, timezone
                from django.utils.timezone import make_aware
                from zoneinfo import ZoneInfo

                # Parse dates and convert to UTC
                start_datetime = datetime.fromisoformat(initial_start_date)
                end_datetime = datetime.fromisoformat(initial_end_date)
                timezone_creation = ZoneInfo(user_timezone)

                localtime_start = make_aware(start_datetime, timezone=timezone_creation)
                localtime_end = make_aware(end_datetime, timezone=timezone_creation)

                utc = timezone.utc
                start_to_utc_time = localtime_start.astimezone(utc)
                end_to_utc_time = localtime_end.astimezone(utc)

                # Update request data with UTC time
                request_data["start_date"] = start_to_utc_time.isoformat()
                request_data["end_date"] = end_to_utc_time.isoformat()
            except Exception as e:
                return Response(
                    {"error": f"Invalid date/time or timezone: {str(e)}"},
                    status=status.HTTP_400_BAD_REQUEST,
                )

            serializer_trialdata = TrialSerializer(data=request.data)
            if serializer_trialdata.is_valid():
                serializer_trialdata.save()
                return Response(serializer_trialdata.data, status=status.HTTP_201_CREATED)
            return Response(serializer_trialdata.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request):
        if request.user.id != request.data.get('user'):
            return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)

        trial_id = request.data.get('trial_id')
        if not trial_id:
            return Response({"error": "trial_id is required"}, status=status.HTTP_400_BAD_REQUEST)
        try:
            # Retrieve data from the request
            initial_start_date = request.data.get("start_date")
            initial_end_date = request.data.get("end_date")
            usertimezone = request.data.get("timezone")
            if initial_start_date and initial_end_date and initial_start_date >= initial_end_date:
                return Response(
                    {"error": "end time must not be before the start time."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            utc = timezone.utc

            # Process start_date if provided
            if initial_start_date:
                start_datetime = datetime.fromisoformat(initial_start_date)
                if not usertimezone:
                    return Response({"error": "Invalid or missing timezone"}, status=status.HTTP_400_BAD_REQUEST)
                timezonecreation = ZoneInfo(usertimezone)
                localtime_start = make_aware(start_datetime, timezone=timezonecreation) if is_naive(start_datetime) else start_datetime.astimezone(timezonecreation)
                starttoutctime = localtime_start.astimezone(utc)
                request.data["start_date"] = starttoutctime.isoformat()

            # Process end_date if provided
            if initial_end_date:
                end_datetime = datetime.fromisoformat(initial_end_date)
                if not usertimezone:
                    return Response({"error": "Invalid or missing timezone"}, status=status.HTTP_400_BAD_REQUEST)

                timezonecreation = ZoneInfo(usertimezone)
                localtime_end = make_aware(end_datetime, timezone=timezonecreation) if is_naive(end_datetime) else end_datetime.astimezone(timezonecreation)
                endtoutctime = localtime_end.astimezone(utc)
                request.data["end_date"] = endtoutctime.isoformat()

            # Get the trial instance
            trial = Trial.objects.get(trial_id=trial_id, user=request.user.id)
            previous_facility = trial.facility
            new_facility = request.data.get('facility')

            if new_facility is not None and previous_facility == 'Oulu' and new_facility == 'South':
                try:
                    delete_slices_response = requests.post("http://127.0.0.1:9090/home/api/delete_related_slices/",json={"trial_id": trial_id})
                except:
                    return Response({"error": "To switch between portals, the North portal must first respond, which is currently unavailable."},status=status.HTTP_400_BAD_REQUEST)
            elif new_facility is not None and previous_facility == 'South' and new_facility == 'Oulu':
                    try:
                        delete_slices_response_south = requests.delete(f"http://193.166.32.46:4040/south-node-adapter/v3/experiment/endTrial/{int(trial_id)}",timeout=10)
                    except:
                        return Response({"error": "To switch between portals, the South portal must first respond, which is currently unavailable."},status=status.HTTP_400_BAD_REQUEST)
            else:
                pass
                
            # Serialize and update
            serializer = TrialSerializer(trial, data=request.data, partial=True)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        except Trial.DoesNotExist:
            return Response("Trial does not exist", status=status.HTTP_404_NOT_FOUND)
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def delete(self, request):    
        try:
            user_id = int(request.data.get('user'))
            trial_id = request.data.get('trial_id')
            if int(request.user.id) != user_id:
                return Response("You are not allowed to use this API", status=status.HTTP_403_FORBIDDEN)

            trial = Trial.objects.get(trial_id=trial_id, user=request.user)
            facility = trial.facility
            south_deleted = False
            oulu_deleted = False
            if facility == 'Oulu':
                response = requests.post("http://127.0.0.1:9090/home/api/delete_related_slices/",json={"trial_id": trial_id})
                if response.status_code in [200, 404, 500]:
                    oulu_deleted = True
                else:
                    print(">>> Oulu returned unexpected status, continuing with deletion")
            else:
                try:
                    response = requests.delete(f"http://193.166.32.46:4040/south-node-adapter/v3/experiment/endTrial/{int(trial_id)}",timeout=10)

                    if 200 <= response.status_code < 300:
                        south_deleted = True
                        print(response.status_code)
                    elif 400 <= response.status_code <= 500:
                        print(">>> South returned 4xx/5xx – continuing with DB deletion")
                except Exception as e:
                    return Response({"error": "South portal is not available."}, status=status.HTTP_400_BAD_REQUEST)
            trial.delete()
            if oulu_deleted:
                return Response({"message": "Trial has been deleted successfully."}, status=status.HTTP_200_OK)
            elif south_deleted:
                return Response({"message": "Trial has been deleted successfully."}, status=status.HTTP_200_OK)
            else:
                return Response({"message": "Trial deleted locally but remote portal deletion failed or not applicable."}, status=status.HTTP_200_OK)
        except Trial.DoesNotExist:
            return Response({"error": "Trial not found."}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return Response({"error": "Unexpected error occurred."}, status=status.HTTP_409_CONFLICT)



from home.serializers import (
    GETTrialSerializer,
)

class TrialPagination(PageNumberPagination):
    page_size = 10 

class gettrials(APIView):
    permission_classes = (IsAuthenticated,)
    pagination_class = PageNumberPagination
    page_size = 10

    def paginate_queryset(self, queryset):
        paginator = self.pagination_class()
        paginator.page_size = self.page_size 
        return paginator.paginate_queryset(queryset, self.request)

    def post(self, request, format=None):
        trial_id = request.data.get("trial_id")
        if trial_id == '':
            trials = Trial.objects.filter(user=request.user.id)
    
            # Apply pagination
            paginator = TrialPagination()
            page = paginator.paginate_queryset(trials, request)
            
            if page is not None:
                # Return paginated response
                serializer = GETTrialSerializer(page, many=True)
                return paginator.get_paginated_response(serializer.data)
            
            # If pagination is not applied, return all data
            serializer = GETTrialSerializer(trials, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            trial = Trial.objects.get(user=request.user.id, trial_id=trial_id)
            ser_trial = GETTrialSerializer(trial)
            return Response(ser_trial.data, status=status.HTTP_200_OK)

    
class GetTrialForSouth(APIView):
    """
    This view is just for South service:
    """
    def get(self, request, trial_id, *args, **kwargs):
        target_trial = get_object_or_404(Trial, trial_id=trial_id)
        serialize_trial = TrialsouthSerializer(target_trial)
        return Response(serialize_trial.data, status=status.HTTP_200_OK)
        
        
class checknstid(APIView):
    def post(self, request):
        trial = get_object_or_404(Trial, trial_id=request.data["trial_id"])
        if trial:
            if trial.end_date.replace(tzinfo=None) < datetime.now():
                return Response({"error": "trial is not valid anymore"}, status=status.HTTP_423_LOCKED)
            return Response("ok", status=status.HTTP_200_OK)
        else:
            return Response("Not ok", status=status.HTTP_400_BAD_REQUEST)


class gettrialfornst(APIView):
    def post(self, request):
        trials = request.data['trial_direction']

        if trials == 'Oulu':
            trial = Trial.objects.filter(facility=trials, end_date__gte=datetime.now())
            serializer = TrialSerializer(trial, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        elif trials == 'South':
            trials = Trial.objects.filter(facility=trials, end_date__gte=datetime.now())
            serializer = TrialsouthSerializer(trials, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response("No Trial ", status=status.HTTP_400_BAD_REQUEST)

class gettrialtimesfornst(APIView):
    def post(self, request, *args, **kwargs):
        trial_id = request.data.get('trial_id', None)

        trials = Trial.objects.filter(
            trial_id=trial_id
        )

        ser_trials = TrialSerializer(trials, many=True)

        return Response(ser_trials.data, status=status.HTTP_200_OK)