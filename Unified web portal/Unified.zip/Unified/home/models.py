import datetime
from time import *
from django.db import models
from users.models import myuser
from django.utils.timezone import is_naive, make_aware

class Trial(models.Model):
    FACILITY_CHOICES = [('Oulu', 'Oulu'),('South', 'South'),]
    trial_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=100)
    start_date = models.DateTimeField(default=datetime.datetime.now, blank=False)
    end_date = models.DateTimeField(default=datetime.datetime.now, blank=False)
    description = models.TextField()
    facility = models.CharField(max_length=255,choices=FACILITY_CHOICES, default='None')
    user = models.ForeignKey(myuser,on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        if is_naive(self.start_date):
            self.start_date = make_aware(self.start_date)
        if is_naive(self.end_date):
            self.end_date = make_aware(self.end_date)
        super(Trial, self).save(*args, **kwargs)

    @property
    def start_date_iso(self):
        return self.start_date.strftime('%Y-%m-%dT%H:%M:%SZ')

    @property
    def end_date_iso(self):
        return self.end_date.strftime('%Y-%m-%dT%H:%M:%SZ')

    def __str__(self):
        return f'Trial ID:{self.trial_id} - Facility: {self.facility}'