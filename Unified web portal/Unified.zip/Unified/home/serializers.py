import pytz
from .models import Trial
from rest_framework import serializers

class TrialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trial
        fields = ("trial_id","name","start_date","end_date","description","facility","user")
        read_only_fields = ("trial_id",)


class GETTrialSerializer(serializers.ModelSerializer):
    start_date = serializers.SerializerMethodField()
    end_date = serializers.SerializerMethodField()

    class Meta:
        model = Trial
        fields = ("trial_id","name","start_date","end_date","description","facility","user")
        read_only_fields = ("trial_id",)

    def get_start_date(self, obj):
        return self.convert_to_timezone(obj.start_date, "Europe/Helsinki")

    def get_end_date(self, obj):
        return self.convert_to_timezone(obj.end_date, "Europe/Helsinki")

    def convert_to_timezone(self, field, timezone_str):
        if field:
            helsinki_tz = pytz.timezone(timezone_str)
            localized_date = field.astimezone(helsinki_tz)
            return localized_date.strftime('%Y-%m-%d %H:%M:%S') 
        return None
        
        
class TrialsouthSerializer(serializers.ModelSerializer):
    class Meta:
        model = Trial
        fields = ("trial_id","name","start_date","end_date","description","facility","user")
        read_only_fields = ("trial_id",)